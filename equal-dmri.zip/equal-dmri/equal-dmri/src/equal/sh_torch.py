"""Differentiable real even spherical harmonics for torch.

``r^l Y_lm`` is a homogeneous harmonic polynomial of degree ``l``, so on the
unit sphere every real SH is exactly a homogeneous polynomial in ``(x, y, z)``.
We recover those polynomial coefficients **once**, by an exact least-squares fit
against :func:`equal.sh.real_sh`, and evaluate them in torch.

Doing it this way means the torch basis cannot drift away from the numpy basis
under a change of convention: there is one definition of the basis in the
repository, in ``equal.sh``, and this module is a derived artefact of it.  The
fit residual is asserted at import and in the tests.

The result is differentiable in the direction, which the FOD readout (27) needs
because its arguments are the principal eigenvectors of the decoded tensors.
"""

from __future__ import annotations

from functools import lru_cache
from itertools import combinations_with_replacement

import numpy as np
import torch

from .sh import even_degrees, n_coeff, real_sh

__all__ = ["real_sh_torch", "monomial_table", "fit_residual"]

_MAX_FIT_RESIDUAL = 1e-9


def _monomials(degree: int) -> list[tuple[int, int, int]]:
    """Exponent triples of the monomials of total degree exactly ``degree``."""
    out = []
    for combo in combinations_with_replacement(range(3), degree):
        e = [0, 0, 0]
        for c in combo:
            e[c] += 1
        out.append(tuple(e))
    return sorted(set(out))


@lru_cache(maxsize=8)
def monomial_table(l_max: int) -> tuple[np.ndarray, np.ndarray, float]:
    """Return ``(exponents, coefficients, residual)`` for degrees up to ``l_max``.

    ``exponents`` is (M, 3) and ``coefficients`` is (M, n_coeff(l_max)), so that
    ``Y(g) = sum_m coeff[m] * x^e0 y^e1 z^e2``.
    """
    exps: list[tuple[int, int, int]] = []
    blocks: list[tuple[int, int, int]] = []    # (degree, start col, n cols)
    col = 0
    for ell in even_degrees(l_max):
        mono = _monomials(ell)
        blocks.append((ell, col, 2 * ell + 1))
        col += 2 * ell + 1
        exps.extend(mono)
    exps_arr = np.array(sorted(set(exps)), dtype=np.int64)

    rng = np.random.default_rng(12345)
    g = rng.normal(size=(4000, 3))
    g /= np.linalg.norm(g, axis=1, keepdims=True)
    # Design matrix of all monomials.
    A = np.prod(g[:, None, :] ** exps_arr[None, :, :], axis=2)   # (P, M)
    Y = real_sh(l_max, g)                                        # (P, n_coeff)
    C, *_ = np.linalg.lstsq(A, Y, rcond=None)                    # (M, n_coeff)
    resid = float(np.max(np.abs(A @ C - Y)))
    if resid > _MAX_FIT_RESIDUAL:
        raise RuntimeError(
            f"polynomial fit to the real SH basis failed: residual {resid:.3e}. "
            f"The torch basis must reproduce equal.sh.real_sh exactly."
        )
    return exps_arr, C, resid


def fit_residual(l_max: int = 8) -> float:
    return monomial_table(l_max)[2]


def real_sh_torch(l_max: int, g: torch.Tensor) -> torch.Tensor:
    """Evaluate the real even SH basis on ``g`` of shape (..., 3).

    ``g`` is normalised internally.  Returns (..., n_coeff(l_max)).
    """
    exps, C, _ = monomial_table(l_max)
    g = g / (g.norm(dim=-1, keepdim=True) + 1e-12)
    e = torch.as_tensor(exps, device=g.device)                   # (M, 3)
    coeff = torch.as_tensor(C, device=g.device, dtype=g.dtype)   # (M, n_coeff)
    # (..., 1, 3) ** (M, 3) -> (..., M, 3) -> prod -> (..., M)
    powers = g.unsqueeze(-2) ** e.to(g.dtype)
    mono = powers.prod(dim=-1)
    return mono @ coeff


def _self_check() -> None:
    r = fit_residual(8)
    assert r <= _MAX_FIT_RESIDUAL, r


_self_check()
