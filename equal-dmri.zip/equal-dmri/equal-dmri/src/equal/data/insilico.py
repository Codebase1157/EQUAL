"""In-silico fields: the generator of Section VI-A.4.

Tissue distributions are mixtures of dispersed sticks, zeppelins and isotropic
components with parameters drawn from physiological ranges.  Signals follow (2)
exactly and noise follows (3), so these are the only data in the repository with
a **known** ``mu``, which is what makes them the ground truth for the
identifiability experiments of RQ4 and the oracle control of RQ1.

Two cautions the manuscript itself states, repeated here because this file is
where they bite:

* Section X-A: the generator is written by the same authors as the model, so the
  identifiability results **inherit its assumptions**; the real-data checks
  carry the weight.
* Section X-B: the false-confident rates measured on these fields bound the
  error due to the *acquisition*, not the error due to the *tissue*, because the
  generative model here is the one the decoder assumes.  Use
  :func:`violating_field` to build data that deliberately leaves the model
  class.

In training these fields enter only through the self-supervised losses, never
through their readout labels (Table IV).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..signal_model import D_FREE_WATER, TensorDistribution, sample_rician
from .protocols import Protocol

__all__ = [
    "TissueParameters",
    "PHYSIOLOGICAL_RANGES",
    "sample_tissue",
    "build_measure",
    "simulate_signals",
    "InSilicoField",
    "generate_field",
    "violating_field",
]

#: Physiological ranges used for drawing tissue parameters.  Held-out ranges for
#: the RQ4 tests are produced by :func:`held_out_ranges`, so those tests are not
#: in-distribution (Section VI-A.4).
PHYSIOLOGICAL_RANGES: dict[str, tuple[float, float]] = {
    "f_free_water": (0.0, 0.6),
    "d_parallel": (1.2e-3, 2.4e-3),      # axial diffusivity of a stick/zeppelin
    "d_perp": (0.0, 0.8e-3),             # radial diffusivity of a zeppelin
    "d_iso": (0.4e-3, 1.4e-3),           # isotropic tissue compartment
    "dispersion_kappa": (2.0, 64.0),     # Watson concentration; large = coherent
    "n_fibres": (1, 3),
}


@dataclass
class TissueParameters:
    """One voxel's tissue, before it becomes a measure."""

    f_free_water: float
    fibre_fractions: np.ndarray          # (n_fibres,)
    fibre_directions: np.ndarray         # (n_fibres, 3)
    d_parallel: np.ndarray               # (n_fibres,)
    d_perp: np.ndarray                   # (n_fibres,)
    f_iso: float
    d_iso: float
    kappa: np.ndarray                    # (n_fibres,)
    n_dispersion_samples: int = 16

    def __post_init__(self) -> None:
        total = self.f_free_water + float(self.fibre_fractions.sum()) + self.f_iso
        if not np.isclose(total, 1.0, atol=1e-6):
            raise ValueError(f"compartment fractions must sum to 1, got {total}")


def held_out_ranges(base: dict | None = None) -> dict[str, tuple[float, float]]:
    """Ranges excluded from training, for the RQ4 tests.

    Section VI-A.4: "tissue parameters and protocol families are drawn from
    ranges held out from training, so these tests are not in-distribution".  We
    implement that by shifting each interval to its upper complement, which
    keeps the values physiological while making them disjoint from training.
    """
    base = base or PHYSIOLOGICAL_RANGES
    out = {}
    for k, (lo, hi) in base.items():
        if k == "n_fibres":
            out[k] = (lo, hi)
            continue
        mid = lo + 0.7 * (hi - lo)
        out[k] = (mid, hi)
    return out


def _watson_directions(
    mu: np.ndarray, kappa: float, n: int, rng: np.random.Generator
) -> np.ndarray:
    """Sample ``n`` axes from a Watson distribution about ``mu``.

    Sampling the cosine by rejection on the Watson density
    ``p(t) ~ exp(kappa t^2)``, then placing the azimuth uniformly.  The axis is
    antipodally symmetric, as a fibre orientation must be.
    """
    mu = mu / np.linalg.norm(mu)
    t = np.empty(n)
    filled = 0
    while filled < n:
        prop = rng.uniform(-1.0, 1.0, size=n)
        acc = rng.uniform(0.0, 1.0, size=n) < np.exp(kappa * (prop**2 - 1.0))
        take = prop[acc][: n - filled]
        t[filled : filled + take.size] = take
        filled += take.size
    phi = rng.uniform(0.0, 2.0 * np.pi, size=n)
    s = np.sqrt(np.maximum(1.0 - t**2, 0.0))
    local = np.stack([s * np.cos(phi), s * np.sin(phi), t], axis=1)
    # Rotate the local frame so that +z maps onto mu.
    z = np.array([0.0, 0.0, 1.0])
    v = np.cross(z, mu)
    c = float(np.dot(z, mu))
    if np.linalg.norm(v) < 1e-12:
        R = np.eye(3) if c > 0 else np.diag([1.0, -1.0, -1.0])
    else:
        vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
        R = np.eye(3) + vx + vx @ vx * (1.0 / (1.0 + c))
    return local @ R.T


def sample_tissue(
    rng: np.random.Generator, ranges: dict | None = None
) -> TissueParameters:
    """Draw one voxel's tissue parameters."""
    r = ranges or PHYSIOLOGICAL_RANGES
    n_fib = int(rng.integers(r["n_fibres"][0], r["n_fibres"][1] + 1))
    f_fw = float(rng.uniform(*r["f_free_water"]))
    f_iso = float(rng.uniform(0.0, max(1.0 - f_fw, 0.0) * 0.4))
    rest = 1.0 - f_fw - f_iso
    raw = rng.dirichlet(np.ones(n_fib))
    dirs = rng.normal(size=(n_fib, 3))
    dirs /= np.linalg.norm(dirs, axis=1, keepdims=True)
    dpar = rng.uniform(*r["d_parallel"], size=n_fib)
    dperp = rng.uniform(*r["d_perp"], size=n_fib)
    dperp = np.minimum(dperp, dpar * 0.95)
    return TissueParameters(
        f_free_water=f_fw,
        fibre_fractions=raw * rest,
        fibre_directions=dirs,
        d_parallel=dpar,
        d_perp=dperp,
        f_iso=f_iso,
        d_iso=float(rng.uniform(*r["d_iso"])),
        kappa=rng.uniform(*r["dispersion_kappa"], size=n_fib),
    )


def build_measure(
    params: TissueParameters, rng: np.random.Generator
) -> TensorDistribution:
    """Turn tissue parameters into the measure ``mu`` of (2).

    Dispersion is represented by sampling ``n_dispersion_samples`` axes per
    fibre population, so a dispersed stick becomes a cluster of atoms rather
    than a single tensor -- which is what makes muFA well defined and
    independent of orientation dispersion, as (26) requires.
    """
    weights: list[float] = []
    tensors: list[np.ndarray] = []

    if params.f_free_water > 0:
        weights.append(params.f_free_water)
        tensors.append(np.eye(3) * D_FREE_WATER)
    if params.f_iso > 0:
        weights.append(params.f_iso)
        tensors.append(np.eye(3) * params.d_iso)

    m = params.n_dispersion_samples
    for k, f in enumerate(params.fibre_fractions):
        if f <= 0:
            continue
        axes = _watson_directions(params.fibre_directions[k], params.kappa[k], m, rng)
        for a in axes:
            D = params.d_perp[k] * np.eye(3) + (
                params.d_parallel[k] - params.d_perp[k]
            ) * np.outer(a, a)
            weights.append(f / m)
            tensors.append(D)

    w = np.asarray(weights)
    w = w / w.sum()
    return TensorDistribution(w, np.stack(tensors))


def simulate_signals(
    measure: TensorDistribution,
    protocol: Protocol,
    snr: float | None = 30.0,
    rng: np.random.Generator | None = None,
) -> tuple[np.ndarray, float]:
    """Signals for one voxel under ``protocol``.

    Returns ``(signals, sigma)`` with signals normalised by ``S_0``.  ``snr`` is
    the signal-to-noise ratio at b = 0, so ``sigma = 1 / snr`` on the normalised
    scale; ``snr=None`` gives the noise-free signal used for the RQ1 oracle and
    the RQ2 checks.
    """
    B = protocol.b_tensors()
    clean = measure.signal(B)
    if snr is None:
        return clean, 0.0
    if rng is None:
        raise ValueError("an rng is required when adding noise")
    sigma = 1.0 / float(snr)
    return sample_rician(clean, sigma, rng), sigma


@dataclass
class InSilicoField:
    """A patch of voxels with known measures, plus their signals.

    ``measures`` is the ground truth -- available here and nowhere else.
    """

    positions: np.ndarray                # (V, 3) mm
    measures: list[TensorDistribution]
    signals: np.ndarray                  # (V, N) normalised
    sigma: float
    protocol: Protocol
    params: list[TissueParameters] = field(default_factory=list)
    snr: float | None = None

    @property
    def n_voxels(self) -> int:
        return len(self.measures)


def generate_field(
    protocol: Protocol,
    shape: tuple[int, int, int] = (5, 5, 5),
    voxel_size: float = 1.25,
    snr: float | None = 30.0,
    seed: int = 0,
    ranges: dict | None = None,
    coherent: bool = True,
) -> InSilicoField:
    """Generate one in-silico patch.

    ``coherent`` makes neighbouring voxels share a slowly varying fibre
    orientation, so the patch has the spatial structure the backbone exists to
    exploit; setting it False gives independent voxels, which is the control for
    the patch-size ablation.
    """
    rng = np.random.default_rng(seed)
    grid = np.stack(
        np.meshgrid(*[np.arange(n) * voxel_size for n in shape], indexing="ij"), axis=-1
    ).reshape(-1, 3)
    V = grid.shape[0]

    base_dir = rng.normal(size=3)
    base_dir /= np.linalg.norm(base_dir)

    measures, params, sigs = [], [], []
    sigma = 0.0
    for j in range(V):
        p = sample_tissue(rng, ranges)
        if coherent:
            # Rotate each voxel's primary fibre slightly towards a common axis.
            w = 0.75
            d = w * base_dir + (1 - w) * p.fibre_directions[0]
            p.fibre_directions[0] = d / np.linalg.norm(d)
        mu = build_measure(p, rng)
        s, sigma = simulate_signals(mu, protocol, snr=snr, rng=rng)
        measures.append(mu)
        params.append(p)
        sigs.append(s)
    return InSilicoField(
        positions=grid,
        measures=measures,
        signals=np.stack(sigs),
        sigma=sigma,
        protocol=protocol,
        params=params,
        snr=snr,
    )


def violating_field(
    protocol: Protocol,
    assumption: str,
    shape: tuple[int, int, int] = (5, 5, 5),
    voxel_size: float = 1.25,
    snr: float | None = 30.0,
    seed: int = 0,
) -> InSilicoField:
    """Data that deliberately leaves the model class of (2).

    Table XXI measures what each assumption costs "on in silico data built to
    violate one assumption at a time, with every other assumption held".  This
    builds those data.  ``assumption`` is one of:

    ``exchange``
        Compartments exchange, so the signal is not a fixed mixture: we apply a
        Karger-style two-site correction at a finite exchange rate.
    ``kurtosis``
        Non-Gaussian diffusion at high b, added as a positive kurtosis term.
    ``diffusion_time``
        The signal depends on diffusion time, which (2) has no parameter for.

    These are the regimes where the output stays physically admissible, the
    identifiability flag still reads ``identified``, and the readout is
    nonetheless wrong -- the failure mode Section X-B says is hardest to notice.
    """
    valid = {"exchange", "kurtosis", "diffusion_time"}
    if assumption not in valid:
        raise ValueError(f"assumption must be one of {sorted(valid)}")
    base = generate_field(protocol, shape, voxel_size, snr=None, seed=seed)
    B = protocol.b_tensors()
    b_vals = np.einsum("nii->n", B)
    rng = np.random.default_rng(seed + 7919)

    out = []
    for j, mu in enumerate(base.measures):
        clean = mu.signal(B)
        if assumption == "kurtosis":
            # S = S_0 exp(-b D + (b D)^2 K / 6) with K drawn per voxel
            K = rng.uniform(0.6, 1.4)
            md = float(np.trace(mu.mean_tensor()) / 3.0)
            clean = clean * np.exp((b_vals * md) ** 2 * K / 6.0)
        elif assumption == "exchange":
            k_ex = rng.uniform(5.0, 25.0)          # s^-1
            t_d = 0.03                              # s
            mix = 1.0 - np.exp(-k_ex * t_d)
            powder = float(np.mean(clean))
            clean = (1.0 - mix) * clean + mix * powder
        else:
            drift = rng.uniform(0.05, 0.15)
            clean = clean ** (1.0 + drift * b_vals / max(b_vals.max(), 1.0))
        clean = np.clip(clean, 1e-8, 1.0)
        if snr is None:
            out.append(clean)
        else:
            out.append(sample_rician(clean, 1.0 / snr, rng))
    return InSilicoField(
        positions=base.positions,
        measures=base.measures,
        signals=np.stack(out),
        sigma=0.0 if snr is None else 1.0 / snr,
        protocol=protocol,
        params=base.params,
        snr=snr,
    )
