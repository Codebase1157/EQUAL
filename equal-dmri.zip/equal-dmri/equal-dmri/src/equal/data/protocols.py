"""Protocols, shells and b-tensors: equations (1) and (5).

A :class:`Protocol` is the object ``A = {B_i}`` of Section III-D together with
its grouping into shells ``I_1, ..., I_{P(A)}`` (Section III-D: measurements
sharing a shape ``b_Delta`` and a b-value to within 50 s/mm^2).

Nothing here fixes N, the b-values, the shapes, the directions or the voxel
spacing -- that is the whole point of (5), and the identifiability rule of
Section IV-G reads only this object, never any image data.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Literal

import numpy as np

__all__ = [
    "farthest_point_subset",
    "EncodingShape",
    "B_DELTA",
    "Shell",
    "Protocol",
    "b_tensor",
    "electrostatic_directions",
    "shell_tolerance",
    "hcp_ya_protocol",
    "single_shell_protocol",
    "tensor_valued_protocol",
]

EncodingShape = Literal["LTE", "PTE", "STE"]

#: b_Delta of equation (1) for the three axisymmetric encodings.
B_DELTA: dict[str, float] = {"LTE": 1.0, "PTE": -0.5, "STE": 0.0}

#: Section III-D: measurements are grouped into a shell when their b-values
#: agree to within this tolerance (s/mm^2).
SHELL_TOLERANCE = 50.0


def shell_tolerance() -> float:
    return SHELL_TOLERANCE


def b_tensor(b: float, g: np.ndarray, b_delta: float) -> np.ndarray:
    """Equation (1): ``B = b [ (1 - b_D)/3 I + b_D g g^T ]``.

    Returns a symmetric 3x3 array with ``tr B = b``.  For STE (``b_delta = 0``)
    the direction drops out, as it must.
    """
    g = np.asarray(g, dtype=float)
    ng = np.linalg.norm(g)
    if ng > 0:
        g = g / ng
    else:
        g = np.array([0.0, 0.0, 1.0])
    return b * ((1.0 - b_delta) / 3.0 * np.eye(3) + b_delta * np.outer(g, g))


def electrostatic_directions(
    n: int, seed: int = 0, iters: int = 4000, lr: float = 0.02
) -> np.ndarray:
    """``n`` directions spread by antipodally-aware electrostatic repulsion.

    This is the standard construction for a diffusion gradient table (Jones et
    al.): each direction repels every other direction *and* every other
    direction's antipode, because ``g`` and ``-g`` carry the same information by
    (1).  A point does not repel its own antipode.

    Used to build realistic synthetic protocols; real acquisitions supply their
    own tables and never go through this function.
    """
    if n < 1:
        raise ValueError("n must be >= 1")
    rng = np.random.default_rng(seed)
    g = rng.normal(size=(n, 3))
    g /= np.linalg.norm(g, axis=1, keepdims=True)
    if n == 1:
        return g

    eye = np.eye(n, dtype=bool)
    for step in range(iters):
        F = np.zeros_like(g)
        for s in (1.0, -1.0):
            d = g[:, None, :] - s * g[None, :, :]          # (n, n, 3)
            r2 = (d * d).sum(-1)
            r2[eye] = np.inf                               # skip self and own antipode
            F += (d / (r2[:, :, None] ** 1.5)).sum(axis=1)
        # project the force onto the tangent plane, then renormalise
        F -= (F * g).sum(1, keepdims=True) * g
        g = g + lr * F / max(n, 1)
        g /= np.linalg.norm(g, axis=1, keepdims=True)
    return g


def farthest_point_subset(directions: np.ndarray, n: int, seed: int = 0) -> np.ndarray:
    """Indices of a well-spread subset of ``n`` directions.

    Greedy farthest-point selection under the **antipodal** distance
    ``1 - |g . g'|``, because ``g`` and ``-g`` carry the same information by (1).

    Section VIII-C compares estimates from direction subsets "which span L_p
    from its largest value down to 2".  Taking an arbitrary slice of a gradient
    table does not do that: a slice can be clustered, in which case the
    quadrature program is infeasible beyond l = 0 and the subset's degree is
    *lower* than that of a smaller but better-spread one.  That is Section
    VII-C's point that feasibility is a property of the geometry, not the count,
    and it is why a subset experiment has to select for spread.
    """
    d = np.atleast_2d(np.asarray(directions, dtype=float))
    d = d / np.linalg.norm(d, axis=1, keepdims=True)
    N = d.shape[0]
    if not 1 <= n <= N:
        raise ValueError(f"cannot take {n} of {N} directions")
    rng = np.random.default_rng(seed)
    chosen = [int(rng.integers(N))]
    cos = np.abs(d @ d.T)
    far = 1.0 - cos[chosen[0]]
    while len(chosen) < n:
        nxt = int(np.argmax(far))
        chosen.append(nxt)
        far = np.minimum(far, 1.0 - cos[nxt])
        far[chosen] = -np.inf
    return np.array(sorted(chosen), dtype=int)


@dataclass(frozen=True)
class Shell:
    """One shell ``I_p``: a b-value, an encoding shape and its directions."""

    b: float
    shape: EncodingShape
    directions: np.ndarray            # (n_p, 3), unit

    def __post_init__(self) -> None:
        d = np.atleast_2d(np.asarray(self.directions, dtype=float))
        norms = np.linalg.norm(d, axis=1, keepdims=True)
        if np.any(norms == 0):
            raise ValueError("zero direction vector in shell")
        object.__setattr__(self, "directions", d / norms)

    @property
    def n_directions(self) -> int:
        return int(self.directions.shape[0])

    @property
    def b_delta(self) -> float:
        return B_DELTA[self.shape]

    @property
    def is_b0(self) -> bool:
        """b = 0 images are used only for normalisation and noise (Sec. III-D)."""
        return self.b <= SHELL_TOLERANCE

    def b_tensors(self) -> np.ndarray:
        """(n_p, 3, 3) stack of equation (1)."""
        return np.stack([b_tensor(self.b, g, self.b_delta) for g in self.directions])


@dataclass(frozen=True)
class Protocol:
    """The acquisition ``A`` of Section III-D, as a list of shells."""

    shells: tuple[Shell, ...]
    name: str = "unnamed"

    def __init__(self, shells: Iterable[Shell], name: str = "unnamed") -> None:
        object.__setattr__(self, "shells", tuple(shells))
        object.__setattr__(self, "name", name)

    # -- basic structure ----------------------------------------------------
    @property
    def n_shells(self) -> int:
        """``P(A)``, counting nonzero-b shells only."""
        return sum(1 for s in self.shells if not s.is_b0)

    @property
    def n_measurements(self) -> int:
        return sum(s.n_directions for s in self.shells)

    def nonzero_shells(self) -> list[Shell]:
        return [s for s in self.shells if not s.is_b0]

    def shapes_present(self) -> set[str]:
        return {s.shape for s in self.nonzero_shells()}

    def distinct_b_values(self, shape: str | None = None) -> list[float]:
        """Distinct nonzero b-values, optionally restricted to one shape.

        Two b-values count as one when they agree to within the shell tolerance.
        """
        bs = sorted(
            s.b for s in self.nonzero_shells() if shape is None or s.shape == shape
        )
        out: list[float] = []
        for b in bs:
            if not out or abs(b - out[-1]) > SHELL_TOLERANCE:
                out.append(b)
        return out

    @property
    def b_max(self) -> float:
        bs = self.distinct_b_values()
        return float(max(bs)) if bs else 0.0

    def b_tensors(self) -> np.ndarray:
        """(N, 3, 3) stack over every measurement, b=0 included."""
        blocks = [s.b_tensors() for s in self.shells]
        return np.concatenate(blocks, axis=0) if blocks else np.zeros((0, 3, 3))

    def shell_index(self) -> np.ndarray:
        """(N,) array giving, for each measurement, the index of its shell."""
        idx = []
        for p, s in enumerate(self.shells):
            idx.extend([p] * s.n_directions)
        return np.asarray(idx, dtype=int)

    def rotated(self, R: np.ndarray) -> "Protocol":
        """Apply a rigid rotation to the gradient table, as in (7)."""
        R = np.asarray(R, dtype=float)
        return Protocol(
            [Shell(s.b, s.shape, s.directions @ R.T) for s in self.shells],
            name=f"{self.name}@R",
        )


# -- Protocol constructors used by the in-silico generator and the tests -----

def single_shell_protocol(
    b: float = 1000.0, n_dir: int = 30, shape: EncodingShape = "LTE", seed: int = 0
) -> Protocol:
    """A routine clinical-style acquisition: one nonzero shell plus b=0."""
    return Protocol(
        [
            Shell(0.0, "LTE", np.array([[0.0, 0.0, 1.0]])),
            Shell(b, shape, electrostatic_directions(n_dir, seed=seed)),
        ],
        name=f"single-shell-b{int(b)}-{n_dir}dir",
    )


def hcp_ya_protocol(n_dir: int = 90, seed: int = 0) -> Protocol:
    """The HCP-YA three-shell protocol of Table IV: b = 1000/2000/3000, 90 dir.

    Built from a repulsion table rather than the released HCP gradient table;
    real runs read the acquired table from the data.
    """
    shells = [Shell(0.0, "LTE", np.array([[0.0, 0.0, 1.0]]))]
    for k, b in enumerate((1000.0, 2000.0, 3000.0)):
        shells.append(Shell(b, "LTE", electrostatic_directions(n_dir, seed=seed + k)))
    return Protocol(shells, name=f"HCP-YA-{n_dir}dir")


def tensor_valued_protocol(
    b_values: tuple[float, ...] = (100.0, 700.0, 1400.0, 2000.0),
    n_lte: int = 23,
    n_pte: int = 23,
    n_ste: int = 10,
    seed: int = 0,
) -> Protocol:
    """An LTE + PTE + STE acquisition in the spirit of the tensor-valued source [29].

    The released dataset has 377 volumes (86 LTE, 86 PTE, 205 STE) over
    b = 0, 100, 700, 1400, 2000 s/mm^2; this constructor reproduces its
    *structure* for tests and simulation, not its exact table.
    """
    shells = [Shell(0.0, "LTE", np.array([[0.0, 0.0, 1.0]]))]
    for k, b in enumerate(b_values):
        shells.append(Shell(b, "LTE", electrostatic_directions(n_lte, seed=seed + k)))
        shells.append(Shell(b, "PTE", electrostatic_directions(n_pte, seed=seed + 50 + k)))
        shells.append(Shell(b, "STE", electrostatic_directions(n_ste, seed=seed + 90 + k)))
    return Protocol(shells, name="tensor-valued-LTE+PTE+STE")
