"""Subject-level split manifests with an overlap check.

Audit Section 3 ("Data splits and overlap", P0, **Fail**) records: *no
subject-level split manifests; the HCP-YA exclusion count is a placeholder*.
This module is the fix for the first half and makes the second half impossible
to leave as a placeholder unnoticed.

Three guarantees:

* Splits are made **at subject level**, never at scan level, so the 46 HCP-YA
  retest subjects cannot contribute one scan to training and one to test.
* :func:`check_overlap` is run on every manifest at write time and at load time,
  and raises rather than warns.
* The HCP-YA eligibility chain is recorded as an explicit arithmetic identity
  (``1206 -> 1065 -> 940 -> 752/94/94``) that :func:`verify_hcp_accounting`
  checks.  A placeholder count cannot pass it, because the numbers have to add
  up, and the test suite asserts the identity independently.

Section VIII-A, which this implements: of the 1206 subjects in the S1200
release, 1065 have the complete 3 T diffusion acquisition, and 125 of those are
excluded for a quality-control flag or incomplete minimal-preprocessing output,
leaving 940 eligible.  The 80/10/10 split gives 752/94/94, and the 46 retest
subjects are **constrained to fall inside** the 94 test subjects rather than
added to them, so the test set holds 140 scans.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np

__all__ = [
    "SplitManifest",
    "HCPAccounting",
    "HCP_YA_ACCOUNTING",
    "verify_hcp_accounting",
    "check_overlap",
    "make_subject_split",
    "write_manifest",
    "load_manifest",
]


@dataclass(frozen=True)
class HCPAccounting:
    """The eligibility chain for HCP-YA, as an arithmetic identity.

    Every field is a count of **subjects**.  ``verify`` checks that the chain is
    consistent; any placeholder left in it will fail, which is the point.
    """

    release_total: int
    with_complete_dwi: int
    excluded_qc_or_preproc: int
    eligible: int
    n_train: int
    n_val: int
    n_test: int
    n_retest_subjects: int
    source_note: str = (
        "Counts follow Section VIII-A. They describe the S1200 release and must "
        "be re-derived from the released quality-control tables before submission."
    )
    verified_against_release: bool = False

    def verify(self) -> None:
        if self.with_complete_dwi > self.release_total:
            raise ValueError("more subjects with complete DWI than in the release")
        if self.with_complete_dwi - self.excluded_qc_or_preproc != self.eligible:
            raise ValueError(
                f"eligibility chain does not close: {self.with_complete_dwi} - "
                f"{self.excluded_qc_or_preproc} != {self.eligible}"
            )
        if self.n_train + self.n_val + self.n_test != self.eligible:
            raise ValueError(
                f"split does not partition the eligible population: "
                f"{self.n_train}+{self.n_val}+{self.n_test} != {self.eligible}"
            )
        if self.n_retest_subjects > self.n_test:
            raise ValueError(
                f"{self.n_retest_subjects} retest subjects cannot fit inside "
                f"{self.n_test} test subjects; they are constrained to fall "
                f"within the test set, not added to it"
            )

    @property
    def n_test_scans(self) -> int:
        """Test scans: one per test subject plus one extra per retest subject."""
        return self.n_test + self.n_retest_subjects


#: The accounting of Section VIII-A.  ``verified_against_release`` is False until
#: someone re-derives it from the released quality-control tables; audit.py
#: reports it as unverified rather than letting it pass silently.
HCP_YA_ACCOUNTING = HCPAccounting(
    release_total=1206,
    with_complete_dwi=1065,
    excluded_qc_or_preproc=125,
    eligible=940,
    n_train=752,
    n_val=94,
    n_test=94,
    n_retest_subjects=46,
)


def verify_hcp_accounting(acc: HCPAccounting = HCP_YA_ACCOUNTING) -> dict[str, int]:
    """Check the chain and return the derived quantities."""
    acc.verify()
    return {
        "eligible": acc.eligible,
        "n_test_scans": acc.n_test_scans,
        "train_fraction_pct": round(100 * acc.n_train / acc.eligible, 2),
    }


@dataclass
class SplitManifest:
    """A subject-level split for one data source."""

    dataset: str
    train: list[str] = field(default_factory=list)
    val: list[str] = field(default_factory=list)
    test: list[str] = field(default_factory=list)
    unit: str = "subject"
    seed: int | None = None
    notes: str = ""
    constrained_to_test: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        check_overlap(self)

    @property
    def n_subjects(self) -> int:
        return len(self.train) + len(self.val) + len(self.test)

    def fingerprint(self) -> str:
        """A stable hash of the split, so a change cannot pass unnoticed."""
        payload = json.dumps(
            {"d": self.dataset, "tr": sorted(self.train),
             "va": sorted(self.val), "te": sorted(self.test)},
            sort_keys=True,
        )
        return hashlib.sha256(payload.encode()).hexdigest()[:16]


def check_overlap(manifest: SplitManifest) -> None:
    """Raise if any subject appears in more than one split, or twice in one.

    This is a hard failure, not a warning: a subject leaking between train and
    test is exactly the defect the manifest exists to rule out, and a warning
    would be lost in a training log.
    """
    parts = {"train": manifest.train, "val": manifest.val, "test": manifest.test}
    for name, ids in parts.items():
        if len(ids) != len(set(ids)):
            dup = sorted({x for x in ids if ids.count(x) > 1})
            raise ValueError(f"{manifest.dataset}: duplicate subjects in {name}: {dup}")
    names = list(parts)
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            inter = set(parts[names[i]]) & set(parts[names[j]])
            if inter:
                raise ValueError(
                    f"{manifest.dataset}: {len(inter)} subject(s) appear in both "
                    f"{names[i]} and {names[j]}: {sorted(inter)[:5]}"
                )
    missing = set(manifest.constrained_to_test) - set(manifest.test)
    if missing:
        raise ValueError(
            f"{manifest.dataset}: {len(missing)} subject(s) are declared constrained "
            f"to the test set but are not in it: {sorted(missing)[:5]}"
        )


def make_subject_split(
    subject_ids: list[str],
    fractions: tuple[float, float, float] = (0.8, 0.1, 0.1),
    seed: int = 0,
    constrain_to_test: list[str] | None = None,
    dataset: str = "unnamed",
    notes: str = "",
) -> SplitManifest:
    """Split subjects, optionally forcing some into the test set.

    ``constrain_to_test`` is how the 46 HCP-YA retest subjects are placed: they
    are taken into the test set **first** and the remaining test slots are
    filled from the rest, so they fall inside the 94 rather than adding to them.
    """
    ids = sorted(set(subject_ids))
    if len(ids) != len(subject_ids):
        raise ValueError("subject_ids contains duplicates")
    if not np.isclose(sum(fractions), 1.0):
        raise ValueError(f"fractions must sum to 1, got {sum(fractions)}")

    forced = sorted(set(constrain_to_test or []))
    unknown = set(forced) - set(ids)
    if unknown:
        raise ValueError(f"constrained subjects not in the population: {sorted(unknown)}")

    n = len(ids)
    n_train = int(round(fractions[0] * n))
    n_val = int(round(fractions[1] * n))
    n_test = n - n_train - n_val
    if len(forced) > n_test:
        raise ValueError(
            f"{len(forced)} subjects are constrained to a test set of size {n_test}"
        )

    rng = np.random.default_rng(seed)
    rest = [i for i in ids if i not in set(forced)]
    rng.shuffle(rest)
    test = forced + rest[: n_test - len(forced)]
    remaining = rest[n_test - len(forced) :]
    train = remaining[:n_train]
    val = remaining[n_train : n_train + n_val]

    return SplitManifest(
        dataset=dataset,
        train=sorted(train),
        val=sorted(val),
        test=sorted(test),
        seed=seed,
        notes=notes,
        constrained_to_test=forced,
    )


def write_manifest(manifest: SplitManifest, path: str | Path) -> Path:
    """Write a manifest as JSON, after re-checking it."""
    check_overlap(manifest)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = asdict(manifest)
    payload["fingerprint"] = manifest.fingerprint()
    payload["n_subjects"] = manifest.n_subjects
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    return path


def load_manifest(path: str | Path) -> SplitManifest:
    """Load a manifest and re-check it, including its fingerprint."""
    path = Path(path)
    data = json.loads(path.read_text())
    stored = data.pop("fingerprint", None)
    data.pop("n_subjects", None)
    m = SplitManifest(**data)
    if stored is not None and stored != m.fingerprint():
        raise ValueError(
            f"{path}: fingerprint mismatch. The manifest has been edited since it "
            f"was written ({stored} != {m.fingerprint()}), so results produced "
            f"with it cannot be matched to it."
        )
    return m
