"""Readouts from a single measure: equations (25), (26) and (27).

Every microstructure readout is a functional of the one decoded measure
``mu_j`` -- there is no second head and no separately tuned network.  That is
what lets one set of weights answer all four research questions, and it is also
why each readout inherits the identifiability limits of ``mu_j`` rather than
having its own.

Because the atoms of (21) can be relabelled without changing ``mu_j``, every
quantity here is invariant to their order, and no claim is made about any
individual atom (Section X-D).
"""

from __future__ import annotations

import numpy as np
import torch

from .decoder import DecodedMeasure
from .sh_torch import real_sh_torch
from .signal_model import D_FREE_WATER

__all__ = [
    "free_water_fraction",
    "mean_diffusivity",
    "micro_fa",
    "fod_coefficients",
    "fod_apodization",
    "angular_correlation",
    "all_readouts",
]


def free_water_fraction(mu: DecodedMeasure) -> torch.Tensor:
    """``f^FW_j = pi_{j,0}`` of equation (25).

    Reported as a **model parameter, not a tissue volume fraction**: Section
    X-B shows exchange biases it upward by 0.07 to 0.12 in grey matter at short
    diffusion times, and that bias is invisible at a single diffusion time.
    """
    return mu.weights[:, 0]


def mean_diffusivity(mu: DecodedMeasure) -> torch.Tensor:
    """``MD_j = pi_{j,0} d_fw + (1/3) sum_k pi_{j,k} tr D_{j,k}`` of (25)."""
    tr = torch.einsum("vkii->vk", mu.tensors)
    return torch.einsum("vk,vk->v", mu.weights, tr) / 3.0


def micro_fa(mu: DecodedMeasure, tissue_only: bool = False) -> torch.Tensor:
    """Equation (26): microscopic fractional anisotropy.

    ``muFA^2 = (3/2) E_mu || D - (1/3) tr D I ||_F^2 / E_mu || D ||_F^2``

    Equals one for any population of identical sticks whatever their dispersion,
    and zero for any mixture of isotropic tensors -- which is exactly why
    Theorem 5(ii) says it cannot be recovered from linear encoding at any
    angular resolution.

    ``tissue_only`` omits the free-water atom, the variant mentioned in
    Section IV-E.
    """
    w = mu.weights
    D = mu.tensors
    if tissue_only:
        w = w[:, 1:]
        w = w / (w.sum(dim=1, keepdim=True) + 1e-12)
        D = D[:, 1:]
    eye = torch.eye(3, device=D.device, dtype=D.dtype)
    tr = torch.einsum("vkii->vk", D)
    dev = D - tr[..., None, None] / 3.0 * eye
    num = torch.einsum("vk,vkij,vkij->v", w, dev, dev)
    den = torch.einsum("vk,vkij,vkij->v", w, D, D)
    return torch.sqrt(torch.clamp(1.5 * num / (den + 1e-20), min=0.0, max=1.0))


def fod_apodization(l_max: int = 8, scale_at_lmax: float = 0.25) -> np.ndarray:
    """Fixed Gaussian apodization, one factor per coefficient.

    Section IV-E: "a fixed Gaussian apodization that scales degree 8 by 0.25".
    We use ``a(l) = exp(-s l(l+1)/2)`` with ``s`` fixed by ``a(l_max) = 0.25``,
    so ``a(0) = 1`` and the factor is deterministic rather than tuned.
    """
    if not 0 < scale_at_lmax < 1:
        raise ValueError("scale_at_lmax must be in (0, 1)")
    s = -2.0 * np.log(scale_at_lmax) / (l_max * (l_max + 1))
    out = []
    for ell in range(0, l_max + 1, 2):
        a = float(np.exp(-s * ell * (ell + 1) / 2.0))
        out.extend([a] * (2 * ell + 1))
    return np.asarray(out)


def fod_coefficients(
    mu: DecodedMeasure, l_max: int = 8, apodize: bool = True, eps: float = 1e-8
) -> torch.Tensor:
    """Equation (27): the fibre orientation distribution.

    ``o_{j,lm} = sum_k pi_{j,k} A_{j,k} Y_lm(n_{j,k})``,
    ``A_{j,k} = (lambda_1 - lambda_2) / lambda_1``

    with ``n_{j,k}`` the principal eigenvector and ``lambda_1 >= lambda_2`` its
    two largest eigenvalues.  The sign of ``n`` is irrelevant for even ``l``,
    and where ``lambda_1 = lambda_2`` the weight ``A`` vanishes, so (27) is
    continuous in ``mu_j``.

    The free-water atom is isotropic, hence ``A = 0``, and drops out on its own.
    """
    D = mu.tensors                                       # (V, K+1, 3, 3)
    evals, evecs = torch.linalg.eigh(D)                  # ascending
    lam1 = evals[..., 2]
    lam2 = evals[..., 1]
    n = evecs[..., :, 2]                                 # (V, K+1, 3)
    A = (lam1 - lam2) / (lam1 + eps)
    A = torch.clamp(A, min=0.0)
    Y = real_sh_torch(l_max, n)                          # (V, K+1, n_coeff)
    o = torch.einsum("vk,vk,vkc->vc", mu.weights, A, Y)
    if apodize:
        a = torch.as_tensor(fod_apodization(l_max), device=o.device, dtype=o.dtype)
        o = o * a
    return o


def angular_correlation(o1: torch.Tensor, o2: torch.Tensor, l_max: int = 8) -> torch.Tensor:
    """The angular correlation coefficient of equation (31), over degrees l >= 2.

    ``ACC(o, o~) = sum_{l>=2,m} o_lm o~_lm / (||o_{l>=2}|| ||o~_{l>=2}||)``

    Both coefficient sets must already be apodized the same way.
    """
    start = 1                                            # skip the single l=0 coefficient
    a = o1[..., start:]
    b = o2[..., start:]
    num = (a * b).sum(-1)
    den = a.norm(dim=-1) * b.norm(dim=-1)
    return num / (den + 1e-12)


def all_readouts(mu: DecodedMeasure, l_max: int = 8) -> dict[str, torch.Tensor]:
    """Every readout of Table III, from the one measure."""
    return {
        "FW": free_water_fraction(mu),
        "MD": mean_diffusivity(mu),
        "muFA": micro_fa(mu),
        "FOD": fod_coefficients(mu, l_max=l_max),
    }
