"""Laplace-measure decoder: equations (21) to (24).

The decoder returns a probability measure with one free-water atom and ``K``
tissue atoms,

    mu_j = pi_{j,0} delta_{d_fw I} + sum_k pi_{j,k} delta_{D_{j,k}},     (21)

whose Laplace transform is the predicted signal (24).  Because (24) is a convex
combination of exponentials ``exp(-b <B, D>)`` with nonnegative rates, **no
setting of the parameters** can produce a signal that rises with b or exceeds
the unweighted signal.  That is Theorem 4, and it holds by construction rather
than by training -- the violation rate (39) is identically zero for EQUAL and is
measured only to confirm that the implementation matches the theory.

The ``U_m`` basis
-----------------
Equation (23) builds each tissue tensor from one invariant and one degree-2
feature:

    M = u I + sum_m v_m U_m = Q Lambda Q^T,    D = d_t Q sig(Lambda) Q^T.

``U_{-2..2}`` is the orthonormal basis of symmetric traceless 3x3 matrices
corresponding to the real l=2 harmonics, so that ``v -> sum_m v_m U_m``
intertwines ``D_2(R)`` with conjugation by ``R``.  Rather than hard-code the
five matrices against an assumed SH sign convention, we *derive* them from the
same ``real_sh`` used everywhere else, by matching the quadratic form
``g^T U_m g`` to ``Y_{2m}(g)``.  The intertwining relation is then asserted in
the tests, so a change of SH convention cannot silently break equivariance.

Since matrix functions commute with conjugation, ``sig`` applied to the
eigenvalues leaves ``D_{j,k} -> R D_{j,k} R^T`` whenever the features rotate,
and the eigenvalues lie in ``(0, d_t)`` by construction.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn

from .signal_model import D_FREE_WATER, D_TISSUE_MAX
from .sh import real_sh

__all__ = ["u_basis", "LaplaceMeasureDecoder", "DecodedMeasure", "signal_from_measure"]

_U_BASIS_CACHE: np.ndarray | None = None


def u_basis() -> np.ndarray:
    """The five matrices ``U_{-2}, ..., U_{2}`` as a (5, 3, 3) array.

    Derived by least squares from ``real_sh`` so the convention always matches.
    Each is symmetric, traceless and of unit Frobenius norm.
    """
    global _U_BASIS_CACHE
    if _U_BASIS_CACHE is not None:
        return _U_BASIS_CACHE

    rng = np.random.default_rng(0)
    g = rng.normal(size=(600, 3))
    g /= np.linalg.norm(g, axis=1, keepdims=True)
    Y = real_sh(2, g)[:, 1:6]                      # the five l=2 columns

    # Basis of symmetric traceless matrices, as quadratic-form features.
    sym_basis = [
        np.array([[1.0, 0, 0], [0, -1.0, 0], [0, 0, 0]]),
        np.array([[0, 0, 0], [0, 1.0, 0], [0, 0, -1.0]]),
        np.array([[0, 1.0, 0], [1.0, 0, 0], [0, 0, 0]]),
        np.array([[0, 0, 1.0], [0, 0, 0], [1.0, 0, 0]]),
        np.array([[0, 0, 0], [0, 0, 1.0], [0, 1.0, 0]]),
    ]
    # Feature matrix: quadratic form of each basis element at each direction.
    F = np.stack([np.einsum("ni,ij,nj->n", g, Bk, g) for Bk in sym_basis], axis=1)
    # Solve F c_m = Y[:, m] for the coefficients of U_m in sym_basis.
    C, *_ = np.linalg.lstsq(F, Y, rcond=None)      # (5 basis, 5 harmonics)
    U = np.einsum("km,kij->mij", C, np.stack(sym_basis))
    # Normalise to unit Frobenius norm.
    U /= np.linalg.norm(U, axis=(1, 2), keepdims=True)
    _U_BASIS_CACHE = U
    return U


class DecodedMeasure:
    """The measure ``mu_j`` of (21) for a whole patch.

    ``weights`` is (V, K+1) with column 0 the free-water atom; ``tensors`` is
    (V, K+1, 3, 3) with ``tensors[:, 0] = d_fw I``.
    """

    __slots__ = ("weights", "tensors")

    def __init__(self, weights: torch.Tensor, tensors: torch.Tensor):
        self.weights = weights
        self.tensors = tensors

    @property
    def n_voxels(self) -> int:
        return int(self.weights.shape[0])

    @property
    def n_atoms(self) -> int:
        return int(self.weights.shape[1])

    def signal(self, B: torch.Tensor) -> torch.Tensor:
        """Equation (24).  ``B`` is (N, 3, 3); returns (V, N)."""
        return signal_from_measure(self.weights, self.tensors, B)

    def mix(self, other: "DecodedMeasure", w_self: float = 0.5) -> "DecodedMeasure":
        """Mix two measures with given weights, staying inside ``P(T)``.

        Section VI-A.5: overlapping patch predictions are combined by mixing
        their measures with equal weights, which keeps every combined estimate a
        probability measure -- averaging *signals* would not.
        """
        w = torch.cat([self.weights * w_self, other.weights * (1.0 - w_self)], dim=1)
        D = torch.cat([self.tensors, other.tensors], dim=1)
        return DecodedMeasure(w, D)


def signal_from_measure(
    weights: torch.Tensor, tensors: torch.Tensor, B: torch.Tensor
) -> torch.Tensor:
    """Equation (24): ``E_j(B) = sum_k pi_{j,k} exp(-<B, D_{j,k}>)``.

    ``weights`` (V, K), ``tensors`` (V, K, 3, 3), ``B`` (N, 3, 3) -> (V, N).
    """
    rates = torch.einsum("nij,vkij->vkn", B, tensors)
    return torch.einsum("vk,vkn->vn", weights, torch.exp(-rates))


class LaplaceMeasureDecoder(nn.Module):
    """``K_psi`` of equation (11).

    Parameters
    ----------
    n_atoms : int
        ``K``, the number of tissue atoms (8 by default).
    c_invariant, c_degree2 : int
        Channel counts of the ``l = 0`` and ``l = 2`` feature blocks.
    eig_gap_clamp : float
        Eigenvalue gaps are clamped at this value before the backward pass, as
        Section VI-F specifies, to stay stable for near-degenerate tensors.
    """

    def __init__(
        self,
        n_atoms: int = 8,
        c_invariant: int = 128,
        c_degree2: int = 64,
        eig_gap_clamp: float = 1e-6,
        free_water_atom: bool = True,
    ):
        super().__init__()
        self.K = n_atoms
        self.free_water_atom = free_water_atom
        self.eig_gap_clamp = eig_gap_clamp
        n_out = n_atoms + (1 if free_water_atom else 0)
        self.to_weights = nn.Linear(c_invariant, n_out)         # (22)
        self.to_u = nn.Linear(c_invariant, n_atoms)             # invariant part of (23)
        # Degree-2 part of (23): a channel mixing map, which commutes with D_2.
        self.to_v = nn.Parameter(torch.randn(n_atoms, c_degree2) / np.sqrt(c_degree2))
        U = torch.as_tensor(u_basis(), dtype=torch.float32)
        self.register_buffer("U", U)                            # (5, 3, 3)

    def forward(self, h: list[torch.Tensor]) -> DecodedMeasure:
        """``h`` is the backbone output; uses the l=0 and l=2 blocks only."""
        inv = h[0][..., 0]                                      # (V, C_0)
        deg2 = h[1]                                             # (V, C_2, 5)
        V = inv.shape[0]

        # -- (22) atom weights ----------------------------------------------
        pi = torch.softmax(self.to_weights(inv), dim=-1)        # (V, K+1)

        # -- (23) tissue tensors --------------------------------------------
        u = self.to_u(inv)                                      # (V, K)
        v = torch.einsum("kc,vcm->vkm", self.to_v, deg2)        # (V, K, 5)
        M = u[..., None, None] * torch.eye(3, device=inv.device, dtype=inv.dtype)
        M = M + torch.einsum("vkm,mij->vkij", v, self.U.to(inv.dtype))
        M = 0.5 * (M + M.transpose(-1, -2))                     # enforce exact symmetry

        evals, evecs = torch.linalg.eigh(M)
        lam = D_TISSUE_MAX * torch.sigmoid(evals)               # in (0, d_t)
        D_tissue = torch.einsum("vkia,vka,vkja->vkij", evecs, lam, evecs)

        if self.free_water_atom:
            fw = torch.eye(3, device=inv.device, dtype=inv.dtype) * D_FREE_WATER
            fw = fw.expand(V, 1, 3, 3)
            D = torch.cat([fw, D_tissue], dim=1)
        else:
            D = D_tissue
        return DecodedMeasure(pi, D)
