"""Steerable-feature plumbing shared by the lifting and the backbone.

This module holds the pieces that make equation (8) hold *by construction*
rather than by augmentation or penalty:

* :class:`SteerableSpec` -- the layout of ``h_j = (+)_l h_j^l``.
* :class:`WignerCache`   -- real Wigner blocks ``D_l(R)`` of (4), cached by
  direction, because a voxel lattice produces very few distinct edge directions.
* :func:`edge_frame_rotation` -- the rotation ``R_{jj'}`` of equation (18) that
  carries an edge onto the z-axis.
* :class:`SO2Linear` -- the map ``W^{SO(2)}`` of (18).
* :class:`GatedNonlinearity`, :class:`EquivariantLayerNorm` -- the gated
  nonlinearity [16] and normalisation that follow the update (20).

Why ``SO2Linear`` has the structure it has
------------------------------------------
Equation (18) rotates a neighbour's features into the edge frame, applies a map
"that mixes only components of equal m", and rotates back.  The edge frame is
fixed only up to a rotation *about* the z-axis: the manuscript's ``R_{jj'}`` is
"a rotation that maps r/||r|| to the z-axis", and there is a one-parameter
family of those.  Equivariance therefore requires the inner map to commute with
every rotation about z, otherwise the gauge choice would leak into the output
and the identity ``F(R.X) = R * F(X)`` would fail at the level of the arbitrary
gauge rather than at round-off.

A rotation about z by ``psi`` acts on the real SH pair ``(Y_{l,+m}, Y_{l,-m})``
as a planar rotation by ``m psi``.  The linear maps commuting with every such
rotation, for all l at fixed m, are exactly the complex-linear ones: writing
``z_l = x_{l,+m} + i x_{l,-m}``, the map must be ``z' = C z`` with ``C``
complex.  We store ``C`` as a real pair ``(A, B)`` and apply

    out_{+m} = A x_{+m} - B x_{-m},
    out_{-m} = B x_{+m} + A x_{-m},

with a single real matrix for ``m = 0``.  This is the SO(2) reduction of [14];
it is also what drops the cost of the tensor product from O(L^6) to O(L^3) and
is what makes ``L = 8`` practical.

Only **even** degrees are carried.  By (1) the b-tensor sees ``g`` only through
``g g^T``, so every signal of the form (2) is antipodally symmetric and odd
degrees vanish identically; the edge direction enters the message solely through
``D(R_{jj'})`` and the invariant radial basis, so no odd degree is needed to
represent it.  See docs/EQUATION_TO_CODE.md, row (18).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
import torch.nn as nn

from .sh import even_degrees, wigner_D

__all__ = [
    "SteerableSpec",
    "WignerCache",
    "edge_frame_rotation",
    "SO2Linear",
    "GatedNonlinearity",
    "EquivariantLayerNorm",
]


@dataclass(frozen=True)
class SteerableSpec:
    """Layout of a steerable feature ``h = (+)_l h^l`` with ``h^l`` of shape
    ``(C_l, 2l+1)``.

    ``channels[l]`` gives ``C_l``.  Degrees are even and ascending.
    """

    l_max: int
    channels: tuple[int, ...]          # one entry per even degree, in order

    def __post_init__(self) -> None:
        if len(self.channels) != len(self.degrees):
            raise ValueError(
                f"channels has {len(self.channels)} entries but there are "
                f"{len(self.degrees)} even degrees up to l_max={self.l_max}"
            )

    @property
    def degrees(self) -> list[int]:
        return even_degrees(self.l_max)

    def channels_of(self, ell: int) -> int:
        return self.channels[self.degrees.index(ell)]

    @property
    def dim(self) -> int:
        """Flattened size of one voxel's feature."""
        return sum(c * (2 * ell + 1) for c, ell in zip(self.channels, self.degrees))


class WignerCache:
    """Cache of real Wigner blocks ``D_l(R)``, keyed by quantised direction.

    A patch drawn from a voxel lattice contains only a handful of distinct edge
    directions, so caching on the rounded unit vector turns a per-edge
    computation into a per-direction one.  Blocks are constants with respect to
    the parameters, so they are built in numpy and held as buffers.
    """

    def __init__(self, l_max: int, decimals: int = 6, dtype: torch.dtype = torch.float32):
        self.l_max = l_max
        self.decimals = decimals
        self.dtype = dtype
        self._cache: dict[tuple, list[torch.Tensor]] = {}

    def blocks(self, R: np.ndarray) -> list[torch.Tensor]:
        """Return ``[D_0(R), D_2(R), ...]`` as torch tensors."""
        key = tuple(np.round(np.asarray(R, dtype=float), self.decimals).ravel())
        hit = self._cache.get(key)
        if hit is None:
            hit = [
                torch.as_tensor(wigner_D(ell, R), dtype=self.dtype)
                for ell in even_degrees(self.l_max)
            ]
            self._cache[key] = hit
        return hit

    def __len__(self) -> int:
        return len(self._cache)


def edge_frame_rotation(r: np.ndarray) -> np.ndarray:
    """A rotation ``R`` with ``R @ (r/||r||) = e_z``  (equation (18)).

    Built by Rodrigues' formula about ``rhat x e_z``.  The residual rotation
    about z is left unspecified on purpose -- :class:`SO2Linear` is invariant to
    it, which is what lets the message be written in the edge frame at all.
    """
    r = np.asarray(r, dtype=float)
    n = np.linalg.norm(r)
    if n == 0:
        return np.eye(3)
    rhat = r / n
    z = np.array([0.0, 0.0, 1.0])
    v = np.cross(rhat, z)
    c = float(np.dot(rhat, z))
    s = float(np.linalg.norm(v))
    if s < 1e-12:
        # rhat is parallel or antiparallel to z
        return np.eye(3) if c > 0 else np.diag([1.0, -1.0, -1.0])
    vx = np.array([[0.0, -v[2], v[1]], [v[2], 0.0, -v[0]], [-v[1], v[0], 0.0]])
    return np.eye(3) + vx + vx @ vx * ((1.0 - c) / s**2)


def _m_index(ell: int, m: int) -> int:
    """Position of component ``m`` within a degree-``l`` block of size 2l+1."""
    return m + ell


class SO2Linear(nn.Module):
    """``W^{SO(2)}(beta(||r||))`` of equation (18).

    Mixes components of equal ``m`` across degrees and channels, conditioned on
    a radial basis, with the complex structure described in the module
    docstring.  Equivariant to the residual gauge rotation about the edge axis
    by construction.

    Parameters
    ----------
    spec_in, spec_out : SteerableSpec
        Input and output layouts.
    n_radial : int
        Width of the Gaussian radial basis ``beta``.
    """

    def __init__(
        self,
        spec_in: SteerableSpec,
        spec_out: SteerableSpec,
        n_radial: int,
        radial_rank: int | None = 4,
    ):
        super().__init__()
        if spec_in.l_max != spec_out.l_max:
            raise ValueError("SO2Linear requires matching l_max")
        self.spec_in = spec_in
        self.spec_out = spec_out
        self.l_max = spec_in.l_max
        self.n_radial = n_radial

        # Low-rank factorisation of the radial dependence.  A full weight bank
        # holds one (fan_out, fan_in) matrix per radial basis function per |m|,
        # which dominates the parameter count; projecting the basis to
        # ``radial_rank`` first keeps the same functional form -- the weights
        # are still a learned function of the distance -- at a fraction of the
        # parameters.  Set ``radial_rank=None`` for the unfactorised bank.
        self.radial_rank = n_radial if radial_rank is None else int(radial_rank)
        self.radial_proj = (
            None if radial_rank is None
            else nn.Linear(n_radial, self.radial_rank, bias=False)
        )

        degs = spec_in.degrees
        self.degrees = degs
        # For each |m|, the degrees that carry it are those with l >= |m|.
        self._weights = nn.ParameterDict()
        for m in range(0, self.l_max + 1):
            dm = [l for l in degs if l >= m]
            if not dm:
                continue
            fan_in = sum(spec_in.channels_of(l) for l in dm)
            fan_out = sum(spec_out.channels_of(l) for l in dm)
            scale = 1.0 / np.sqrt(max(fan_in * self.radial_rank, 1))
            # Real part A for every m; imaginary part B only for m > 0.
            self._weights[f"A{m}"] = nn.Parameter(
                torch.randn(self.radial_rank, fan_out, fan_in) * scale
            )
            if m > 0:
                self._weights[f"B{m}"] = nn.Parameter(
                    torch.randn(self.radial_rank, fan_out, fan_in) * scale
                )
        self._degrees_for_m = {
            m: [l for l in degs if l >= m] for m in range(0, self.l_max + 1)
        }

    def _gather(self, h: list[torch.Tensor], m: int, sign: int) -> torch.Tensor:
        """Stack the ``(l, sign*m)`` components over the degrees carrying ``m``.

        ``h[i]`` has shape (E, C_l, 2l+1); result is (E, sum_l C_l).
        """
        parts = []
        for l in self._degrees_for_m[m]:
            i = self.degrees.index(l)
            parts.append(h[i][..., _m_index(l, sign * m)])
        return torch.cat(parts, dim=-1)

    def _scatter(
        self, out: list[torch.Tensor], vec: torch.Tensor, m: int, sign: int
    ) -> None:
        off = 0
        for l in self._degrees_for_m[m]:
            i = self.degrees.index(l)
            c = self.spec_out.channels_of(l)
            out[i][..., _m_index(l, sign * m)] = vec[..., off : off + c]
            off += c

    def forward(self, h: list[torch.Tensor], radial: torch.Tensor) -> list[torch.Tensor]:
        """Apply the map.

        Parameters
        ----------
        h : list of (E, C_l, 2l+1) tensors, one per even degree
            Features already rotated into the edge frame.
        radial : (E, n_radial)
            The radial basis ``beta(||r_{jj'}||)`` for each edge.
        """
        E = h[0].shape[0]
        if self.radial_proj is not None:
            radial = self.radial_proj(radial)
        out = [
            h[0].new_zeros(E, self.spec_out.channels_of(l), 2 * l + 1)
            for l in self.degrees
        ]
        for m in range(0, self.l_max + 1):
            if f"A{m}" not in self._weights:
                continue
            A = torch.einsum("er,roi->eoi", radial, self._weights[f"A{m}"])
            xp = self._gather(h, m, +1)                     # (E, fan_in)
            if m == 0:
                self._scatter(out, torch.einsum("eoi,ei->eo", A, xp), 0, +1)
            else:
                B = torch.einsum("er,roi->eoi", radial, self._weights[f"B{m}"])
                xm = self._gather(h, m, -1)
                yp = torch.einsum("eoi,ei->eo", A, xp) - torch.einsum("eoi,ei->eo", B, xm)
                ym = torch.einsum("eoi,ei->eo", B, xp) + torch.einsum("eoi,ei->eo", A, xm)
                self._scatter(out, yp, m, +1)
                self._scatter(out, ym, m, -1)
        return out


class EquivariantLayerNorm(nn.Module):
    """Normalise each degree by an invariant scale.

    For ``l = 0`` this is an ordinary layer norm over channels.  For ``l > 0``
    the block is divided by the root-mean-square of its own norm across
    channels -- a rotation-invariant scalar -- and rescaled by a learned gain,
    so the direction of every steerable component is untouched.
    """

    def __init__(self, spec: SteerableSpec, eps: float = 1e-5):
        super().__init__()
        self.spec = spec
        self.eps = eps
        self.gains = nn.ParameterList(
            [nn.Parameter(torch.ones(c)) for c in spec.channels]
        )
        self.bias0 = nn.Parameter(torch.zeros(spec.channels[0]))

    def forward(self, h: list[torch.Tensor]) -> list[torch.Tensor]:
        out = []
        for i, ell in enumerate(self.spec.degrees):
            x = h[i]
            if ell == 0:
                v = x[..., 0]
                mu = v.mean(dim=-1, keepdim=True)
                sd = v.std(dim=-1, keepdim=True, unbiased=False)
                y = (v - mu) / (sd + self.eps) * self.gains[i] + self.bias0
                out.append(y.unsqueeze(-1))
            else:
                # ||h^l_c||^2 summed over m is invariant under D_l(R)
                norm = x.pow(2).sum(dim=-1).mean(dim=-1, keepdim=True).sqrt()
                y = x / (norm.unsqueeze(-1) + self.eps) * self.gains[i].view(1, -1, 1)
                out.append(y)
        return out


class GatedNonlinearity(nn.Module):
    """The gated nonlinearity of [16], as described after equation (20).

    ``l = 0`` channels pass through a SiLU; higher degrees are scaled by
    sigmoids of dedicated invariant gates computed from the ``l = 0`` block.
    Scaling a whole degree block by a scalar commutes with ``D_l(R)``, so the
    layer is equivariant.
    """

    def __init__(self, spec: SteerableSpec):
        super().__init__()
        self.spec = spec
        n_gates = sum(c for c, l in zip(spec.channels, spec.degrees) if l > 0)
        self.gate = nn.Linear(spec.channels[0], n_gates) if n_gates else None
        self.act = nn.SiLU()

    def forward(self, h: list[torch.Tensor]) -> list[torch.Tensor]:
        inv = h[0][..., 0]                                  # (..., C_0)
        out = [self.act(inv).unsqueeze(-1)]
        if self.gate is not None:
            g = torch.sigmoid(self.gate(inv))               # (..., n_gates)
            off = 0
            for i, ell in enumerate(self.spec.degrees):
                if ell == 0:
                    continue
                c = self.spec.channels_of(ell)
                out.append(h[i] * g[..., off : off + c].unsqueeze(-1))
                off += c
        else:
            out.extend(h[1:])
        return out
