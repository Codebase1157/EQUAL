"""Real even-degree spherical harmonics and real Wigner matrices.

Implements equation (4) of the manuscript:

    Y_l(R g) = D_l(R) Y_l(g)

Conventions
-----------
The basis is the real, **orthonormal**, symmetric (even-degree) SH basis of
Descoteaux et al. [12], ordered m = -l, ..., +l within each degree.

Orthonormal means

    \\int_{S^2} Y_lm Y_l'm' dOmega = delta_ll' delta_mm',

from which

    \\int_{S^2} Y_lm dOmega = sqrt(4 pi) delta_l0.

NOTE ON EQUATION (12).  The manuscript writes the quadrature constraint as
``Phi^T w = 4 pi e_1``.  With the orthonormal basis used here Y_00 = 1/sqrt(4pi),
so the correct right-hand side is ``sqrt(4 pi) e_1``, which is what makes the
total weight sum to the area of the sphere, ``sum_i w_i = 4 pi``.  The two
statements agree only under the unnormalised convention Y_00 = 1.  We implement
``sqrt(4 pi) e_1`` and assert ``sum_i w_i = 4 pi`` in the tests; see
docs/EQUATION_TO_CODE.md, row (12), for the discussion.

Only even degrees are provided: by (1) the b-tensor depends on g only through
g g^T, so every signal of the form (2) is antipodally symmetric and odd degrees
vanish identically.
"""

from __future__ import annotations

import numpy as np
from scipy.special import sph_harm_y

__all__ = [
    "even_degrees",
    "n_coeff",
    "real_sh",
    "sh_integral_vector",
    "wigner_D",
    "wigner_block_diagonal",
    "rotate_sh_coefficients",
    "random_rotation",
    "cubic_lattice_rotations",
]

_SQRT2 = np.sqrt(2.0)


def even_degrees(l_max: int) -> list[int]:
    """[0, 2, 4, ..., l_max] (l_max rounded down to even)."""
    if l_max < 0:
        raise ValueError("l_max must be non-negative")
    return list(range(0, l_max + 1, 2))


def n_coeff(l_max: int) -> int:
    """Number of even real SH coefficients up to degree l_max.

    Equals (l_max + 1)(l_max + 2) / 2, the count used for the FOD degree
    rule ``l_A`` in Section IV-G.
    """
    return sum(2 * ell + 1 for ell in even_degrees(l_max))


def _cart_to_sphere(g: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Unit vectors -> (theta polar in [0, pi], phi azimuth in [0, 2pi))."""
    g = np.asarray(g, dtype=float)
    norm = np.linalg.norm(g, axis=-1, keepdims=True)
    with np.errstate(invalid="ignore", divide="ignore"):
        g = np.where(norm > 0, g / np.maximum(norm, 1e-300), g)
    theta = np.arccos(np.clip(g[..., 2], -1.0, 1.0))
    phi = np.arctan2(g[..., 1], g[..., 0]) % (2.0 * np.pi)
    return theta, phi


def real_sh(l_max: int, g: np.ndarray) -> np.ndarray:
    """Evaluate the real even SH basis on directions ``g``.

    Parameters
    ----------
    l_max : int
        Maximum (even) degree.
    g : (..., 3) array
        Directions; they are normalised internally.

    Returns
    -------
    (..., n_coeff(l_max)) array
        Columns ordered by (l, m) with l even ascending and m from -l to +l.
    """
    g = np.atleast_2d(np.asarray(g, dtype=float))
    theta, phi = _cart_to_sphere(g)
    cols = []
    for ell in even_degrees(l_max):
        for m in range(-ell, ell + 1):
            am = abs(m)
            # scipy's sph_harm_y(n, m, theta, phi) is the complex orthonormal
            # Y_n^m with the Condon-Shortley phase included.
            y = sph_harm_y(ell, am, theta, phi)
            if m < 0:
                val = _SQRT2 * (-1.0) ** m * y.imag
            elif m == 0:
                val = y.real
            else:
                val = _SQRT2 * (-1.0) ** m * y.real
            cols.append(val)
    return np.stack(cols, axis=-1)


def sh_integral_vector(l_max: int) -> np.ndarray:
    """The vector ``t`` with ``t_lm = \\int_{S^2} Y_lm dOmega``.

    Equals ``sqrt(4 pi) e_1`` for the orthonormal basis.  This is the
    right-hand side of the quadrature constraint (12).
    """
    t = np.zeros(n_coeff(l_max))
    t[0] = np.sqrt(4.0 * np.pi)
    return t


def wigner_D(ell: int, R: np.ndarray, n_probe: int = 8, seed: int = 0) -> np.ndarray:
    """Real Wigner matrix ``D_l(R)`` of equation (4), so ``Y_l(Rg) = D_l(R) Y_l(g)``.

    Computed by solving the defining relation on a well-conditioned set of probe
    directions.  For a single degree ``l`` the block has size (2l+1); we evaluate
    both sides on ``n_probe * (2l + 1)`` fixed pseudo-random directions and solve
    the resulting overdetermined linear system in the least-squares sense.  The
    relation holds exactly, so the residual is at float round-off; the tests
    assert orthogonality and the group law.

    ``ell`` must be even (odd degrees are not carried by this model).
    """
    if ell % 2 != 0:
        raise ValueError("only even degrees are represented")
    R = np.asarray(R, dtype=float)
    if R.shape != (3, 3):
        raise ValueError("R must be 3x3")
    dim = 2 * ell + 1
    rng = np.random.default_rng(seed + 1000 * ell)
    g = rng.normal(size=(max(n_probe * dim, 4 * dim), 3))
    g /= np.linalg.norm(g, axis=-1, keepdims=True)

    # Slice out this degree's block from the full basis evaluation.
    off = sum(2 * k + 1 for k in even_degrees(ell) if k < ell)
    Y = real_sh(ell, g)[:, off : off + dim]            # (P, dim)
    YR = real_sh(ell, g @ R.T)[:, off : off + dim]     # (P, dim), rows Y_l(R g)

    # Solve Y D^T = YR  for D.
    D_T, *_ = np.linalg.lstsq(Y, YR, rcond=None)
    return np.ascontiguousarray(D_T.T)


def wigner_block_diagonal(l_max: int, R: np.ndarray) -> np.ndarray:
    """The block-diagonal ``D(R)`` over all even degrees up to ``l_max``.

    Shape ``(n_coeff, n_coeff)``.  This is the ``D`` of equation (18) and the
    operator ``R *`` acts with on any vector of SH coefficients.
    """
    blocks = [wigner_D(ell, R) for ell in even_degrees(l_max)]
    n = n_coeff(l_max)
    out = np.zeros((n, n))
    off = 0
    for B in blocks:
        d = B.shape[0]
        out[off : off + d, off : off + d] = B
        off += d
    return out


def rotate_sh_coefficients(coeffs: np.ndarray, R: np.ndarray, l_max: int) -> np.ndarray:
    """Apply ``R *`` to SH coefficients: ``o -> D(R) o``, degree by degree.

    A function on the sphere whose coefficients are ``o`` becomes, after the
    rotation ``R``, the function with coefficients ``D(R) o``.  This is the
    transformation the equivariance error (38) compares against when ``F`` is
    read as the vector of FOD coefficients -- comparing against the *unrotated*
    coefficients would measure how far the model is from being rotation
    *invariant*, which it must not be.
    """
    coeffs = np.asarray(coeffs, dtype=float)
    D = wigner_block_diagonal(l_max, R)
    if coeffs.shape[-1] != D.shape[0]:
        raise ValueError(
            f"coefficient vector has width {coeffs.shape[-1]}, expected "
            f"{D.shape[0]} for l_max={l_max}"
        )
    return coeffs @ D.T


def random_rotation(rng: np.random.Generator) -> np.ndarray:
    """A rotation drawn from the Haar measure on SO(3) (QR of a Gaussian)."""
    A = rng.normal(size=(3, 3))
    Q, Rm = np.linalg.qr(A)
    Q = Q * np.sign(np.diag(Rm))
    if np.linalg.det(Q) < 0:
        Q[:, 0] *= -1.0
    return Q


def cubic_lattice_rotations() -> np.ndarray:
    """The 24 rotations of the cubic lattice, as a (24, 3, 3) array.

    These are the rotations used for the head-to-head equivariance comparison of
    Section VIII-C: they permute voxel centres exactly, so a lattice-based model
    can be rotated without image interpolation.
    """
    mats = []
    eye = np.eye(3)
    for perm in [
        (0, 1, 2), (0, 2, 1), (1, 0, 2),
        (1, 2, 0), (2, 0, 1), (2, 1, 0),
    ]:
        P = eye[list(perm)]
        for sx in (1, -1):
            for sy in (1, -1):
                for sz in (1, -1):
                    M = P * np.array([sx, sy, sz])[:, None]
                    if abs(np.linalg.det(M) - 1.0) < 1e-9:
                        mats.append(M)
    out = np.array(mats, dtype=float)
    assert out.shape == (24, 3, 3), out.shape
    return out
