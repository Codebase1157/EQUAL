"""EQUAL: the composed operator of equations (6) and (11).

    F_Theta = K_psi . B_theta . Q_phi,    Theta = (phi, theta, psi)

The constraints (8) hold **by construction**, without augmentation or penalty
terms:

* permutation invariance -- the lift sums over measurements and the shell
  pooling is a softmax over shells, both order-free;
* joint rotation equivariance -- the quadrature rule is a function of the
  direction set and rotates with it (verified at 1e-15), the SH lift transforms
  by Wigner blocks, the backbone message is conjugated into the edge frame, and
  the decoder's matrix function commutes with conjugation;
* ``mu_j in P(T)`` -- a softmax gives the weights and a logistic bounds the
  eigenvalues, so every output is a probability measure on admissible tensors.

Requirement (i) of Problem 1 cannot be imposed exactly, because different
direction sets carry different information; Theorem 2 bounds how far it can
fail and the consistency loss (30) promotes it during training.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import torch
import torch.nn as nn

from .backbone import EdgeGeometry, EquivariantBackbone, build_edges
from .data.protocols import Protocol
from .decoder import DecodedMeasure, LaplaceMeasureDecoder
from .equivariance import WignerCache
from .lifting import QSpaceLifting, b_tensor_descriptor
from .quadrature import build_rule
from .sh import real_sh

__all__ = ["EqualConfig", "EQUAL", "PreparedInput", "prepare_input"]


@dataclass
class EqualConfig:
    """Defaults are those of Section VI-F."""

    l_max: int = 8                       # L
    lift_channels: int = 64              # C
    pool_heads: int = 4                  # N_h
    n_freq: int = 8                      # N_f
    c_invariant: int = 128               # C_0
    c_steerable: int = 64                # C_l for l >= 1
    n_blocks: int = 6
    n_attention_heads: int = 8
    n_radial: int = 16
    radial_rank: int | None = 4   # low-rank factorisation of the SO(2) weights
    r_cut: float = 8.0                   # mm
    n_atoms: int = 8                     # K
    free_water_atom: bool = True
    symmetry_group: str = "joint"        # or "product" for the ablation
    use_quadrature_weights: bool = True  # False -> uniform weights ablation
    use_continuous_descriptor: bool = True
    eig_gap_clamp: float = 1e-6

    def as_dict(self) -> dict:
        return dict(self.__dict__)


@dataclass
class PreparedInput:
    """Everything the forward pass needs that depends only on the protocol.

    Caching this across voxels and across training steps is what makes the
    quadrature program a per-protocol cost rather than a per-batch one
    (Section VI-F: "cached per protocol").
    """

    sh_bases: list[torch.Tensor]
    weights: list[torch.Tensor]
    descriptors: torch.Tensor
    degrees: list[int]
    isotropic_only: list[bool]
    shell_slices: list[tuple[int, int]]
    b_tensors: torch.Tensor
    quadrature_degrees: list[int] = field(default_factory=list)

    @property
    def min_degree(self) -> int:
        """``min_p L_p``: the degree that governs the bound of Theorem 2.

        Section VII-C: the bound is driven by the *smallest* degree across the
        shells, not by the number of measurements, so this is the quantity to
        report beside any result.
        """
        return min(self.degrees) if self.degrees else 0


def prepare_input(
    protocol: Protocol,
    config: EqualConfig,
    dtype: torch.dtype = torch.float32,
    device: torch.device | str = "cpu",
) -> PreparedInput:
    """Build quadrature rules, SH bases and descriptors for one protocol.

    b = 0 shells are dropped here: Section III-D says they are used only for
    normalisation and noise estimation, never as inputs to the lift.
    """
    sh_bases, weights, degrees, iso, slices, descs = [], [], [], [], [], []
    cursor = 0
    full_cursor = 0
    for shell in protocol.shells:
        n = shell.n_directions
        if shell.is_b0:
            full_cursor += n
            continue
        rule = build_rule(
            shell.directions,
            l_max=config.l_max,
            shape_is_spherical=(shell.shape == "STE"),
        )
        w = rule.weights
        if not config.use_quadrature_weights:
            # Ablation (Table XX, "Quadrature"): uniform weights.  The total is
            # kept at 4 pi so the l=0 feature is unchanged and only the angular
            # exactness is lost -- otherwise the ablation would also change the
            # scale of every feature and would not isolate its component.
            w = np.full(n, 4.0 * np.pi / n)
        sh_bases.append(torch.as_tensor(real_sh(config.l_max, shell.directions),
                                        dtype=dtype, device=device))
        weights.append(torch.as_tensor(w, dtype=dtype, device=device))
        degrees.append(rule.degree)
        iso.append(shell.shape == "STE")
        slices.append((full_cursor, full_cursor + n))
        if config.use_continuous_descriptor:
            descs.append(b_tensor_descriptor(shell.b, shell.b_delta, config.n_freq)[0])
        else:
            descs.append(_one_hot_descriptor(shell.b, shell.b_delta, config.n_freq))
        full_cursor += n
        cursor += n

    if not sh_bases:
        raise ValueError(f"protocol {protocol.name!r} has no nonzero shell")
    return PreparedInput(
        sh_bases=sh_bases,
        weights=weights,
        descriptors=torch.as_tensor(np.stack(descs), dtype=dtype, device=device),
        degrees=degrees,
        isotropic_only=iso,
        shell_slices=slices,
        b_tensors=torch.as_tensor(protocol.b_tensors(), dtype=dtype, device=device),
        quadrature_degrees=degrees,
    )


#: The closed vocabulary of the one-hot ablation (Table XX, "Encoding"), matching
#: the ten fixed b-values of UPER [6].
_ONE_HOT_B_VALUES = (0.0, 700.0, 1000.0, 1500.0, 2000.0, 2500.0,
                     3000.0, 4000.0, 5000.0, 6000.0)


def _one_hot_descriptor(b: float, b_delta: float, n_freq: int) -> np.ndarray:
    """One-hot shell token over a closed list, for the ablation.

    A b-value outside the list is mapped to the nearest entry, which is exactly
    the bias Section III-A describes; a shape other than LTE has no slot at all
    and is left as the zero vector.  Padded to the width of (14) so the two
    variants are otherwise identical.
    """
    v = np.zeros(2 + 2 * n_freq)
    idx = int(np.argmin([abs(b - x) for x in _ONE_HOT_B_VALUES]))
    v[idx] = 1.0
    if abs(b_delta - 1.0) > 1e-9:
        v[:] = 0.0
    return v


class EQUAL(nn.Module):
    """The operator ``F_Theta`` of (6)."""

    def __init__(self, config: EqualConfig | None = None):
        super().__init__()
        self.config = config or EqualConfig()
        c = self.config
        self.lift = QSpaceLifting(
            l_max=c.l_max,
            channels=c.lift_channels,
            n_heads=c.pool_heads,
            n_freq=c.n_freq,
        )
        self.backbone = EquivariantBackbone(
            in_spec=self.lift.out_spec,
            l_max=c.l_max,
            c_invariant=c.c_invariant,
            c_steerable=c.c_steerable,
            n_blocks=c.n_blocks,
            n_heads=c.n_attention_heads,
            n_radial=c.n_radial,
            r_cut=c.r_cut,
            symmetry_group=c.symmetry_group,
            radial_rank=c.radial_rank,
        )
        self.decoder = LaplaceMeasureDecoder(
            n_atoms=c.n_atoms,
            c_invariant=c.c_invariant,
            c_degree2=c.c_steerable,
            eig_gap_clamp=c.eig_gap_clamp,
            free_water_atom=c.free_water_atom,
        )
        self._wigner = WignerCache(c.l_max)

    # -- geometry -----------------------------------------------------------
    def build_geometry(self, positions: np.ndarray, dtype=torch.float32) -> EdgeGeometry:
        """Neighbour graph for a patch of voxel centres in millimetres."""
        return build_edges(positions, self.config.r_cut, self._wigner, self.config.l_max, dtype)

    # -- forward ------------------------------------------------------------
    def forward(
        self,
        signals: list[torch.Tensor],
        prepared: PreparedInput,
        geometry: EdgeGeometry,
    ) -> DecodedMeasure:
        """``X_O -> (mu_1, ..., mu_V)``.

        ``signals`` is one (V, n_p) tensor per nonzero shell, in the order of
        ``prepared``.
        """
        z = self.lift(
            signals,
            prepared.sh_bases,
            prepared.weights,
            prepared.descriptors,
            prepared.degrees,
            prepared.isotropic_only,
        )
        h = self.backbone(z, geometry)
        return self.decoder(h)

    @property
    def n_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters())
