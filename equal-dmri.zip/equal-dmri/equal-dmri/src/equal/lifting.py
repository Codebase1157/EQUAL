"""Quadrature-weighted q-space lifting: equations (14) to (17).

The lifting ``Q_phi`` turns a raw measurement set into steerable features, with
no resampling at any stage.  Three things happen here:

1. Equation (14): a **continuous** descriptor of the b-tensor replaces the
   one-hot shell token, so an unseen b-value and an unseen encoding shape are
   points of the same input space rather than absent symbols.
2. Equation (15): measurements are integrated against the real SH basis using
   the quadrature weights of (12), so sums over acquired directions approximate
   integrals over the sphere (16) with an error Theorem 2 bounds.
3. Equation (17): shells are merged by multi-head attention pooling, which
   accepts any number of shells and ignores their order.

Degrees above ``L_p`` are held at zero.  Section VII-C is explicit that step
(13) "stops the lifting from claiming a degree the protocol cannot support";
writing a coefficient the rule cannot integrate exactly would void the
hypothesis of Theorem 2 silently.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn

from .equivariance import SteerableSpec
from .sh import even_degrees, n_coeff

__all__ = ["B_REF", "b_tensor_descriptor", "QSpaceLifting"]

#: Reference b-value of equation (14), s/mm^2.
B_REF = 2.0e4


def b_tensor_descriptor(b: float | np.ndarray, b_delta: float | np.ndarray,
                        n_freq: int = 8) -> np.ndarray:
    """Equation (14): ``gamma(b, b_Delta)``.

    ``[ b/b_ref, b_Delta, {sin(2^n pi b/b_ref), cos(2^n pi b/b_ref)}_{n=0}^{N_f-1} ]``

    Every b-value up to ``b_ref`` and every shape in ``[-1/2, 1]`` is a point of
    the same space, which is the whole reason an unseen shell needs no new
    symbol.  Dimension is ``2 + 2 N_f`` (18 at the default ``N_f = 8``).
    """
    b = np.atleast_1d(np.asarray(b, dtype=float))
    b_delta = np.atleast_1d(np.asarray(b_delta, dtype=float))
    b, b_delta = np.broadcast_arrays(b, b_delta)
    x = b / B_REF
    feats = [x, b_delta]
    for n in range(n_freq):
        arg = (2.0**n) * np.pi * x
        feats.append(np.sin(arg))
        feats.append(np.cos(arg))
    return np.stack(feats, axis=-1)


def descriptor_dim(n_freq: int = 8) -> int:
    return 2 + 2 * n_freq


class _PhiMLP(nn.Module):
    """The embedding ``phi`` of equation (15).

    Maps ``(s, gamma)`` to ``C`` channels.  **Channel 0 is kept linear**,
    ``phi_1(s, gamma) = s``, which is the hypothesis of Theorem 3(i) and what
    lets the lift recover a band-limited shell signal exactly.  The remaining
    ``C - 1`` channels are a SiLU network, which is smooth with bounded
    derivatives on the bounded input domain -- the assumption Theorem 2 needs on
    ``phi`` (Section VII-A).
    """

    def __init__(self, n_desc: int, channels: int, hidden: int = 64):
        super().__init__()
        if channels < 1:
            raise ValueError("need at least the linear channel")
        self.channels = channels
        self.net = (
            nn.Sequential(
                nn.Linear(1 + n_desc, hidden),
                nn.SiLU(),
                nn.Linear(hidden, hidden),
                nn.SiLU(),
                nn.Linear(hidden, channels - 1),
            )
            if channels > 1
            else None
        )

    def forward(self, s: torch.Tensor, gamma: torch.Tensor) -> torch.Tensor:
        """``s``: (..., ) signals.  ``gamma``: (..., n_desc).  -> (..., C)."""
        lin = s.unsqueeze(-1)
        if self.net is None:
            return lin
        x = torch.cat([lin, gamma], dim=-1)
        return torch.cat([lin, self.net(x)], dim=-1)


class QSpaceLifting(nn.Module):
    """``Q_phi`` of equation (11): raw measurement set -> steerable features.

    Parameters
    ----------
    l_max : int
        Maximum degree ``L``.
    channels : int
        ``C``, the number of lifting channels.
    n_heads : int
        ``N_h``, the number of attention-pooling heads of (17).
    n_freq : int
        ``N_f`` of the descriptor (14).
    """

    def __init__(
        self,
        l_max: int = 8,
        channels: int = 64,
        n_heads: int = 4,
        n_freq: int = 8,
        pool_hidden: int = 64,
    ):
        super().__init__()
        self.l_max = l_max
        self.channels = channels
        self.n_heads = n_heads
        self.n_freq = n_freq
        self.n_desc = descriptor_dim(n_freq)
        self.phi = _PhiMLP(self.n_desc, channels)
        # kappa of (17): acts on the invariant l=0 features and the descriptor
        self.kappa = nn.Sequential(
            nn.Linear(channels + self.n_desc, pool_hidden),
            nn.SiLU(),
            nn.Linear(pool_hidden, pool_hidden),
        )
        self.queries = nn.Parameter(torch.randn(n_heads, pool_hidden) / np.sqrt(pool_hidden))

    @property
    def out_spec(self) -> SteerableSpec:
        """Layout of ``z_j``: ``N_h * C`` channels at every even degree."""
        n = len(even_degrees(self.l_max))
        return SteerableSpec(self.l_max, tuple([self.n_heads * self.channels] * n))

    def forward(
        self,
        signals: list[torch.Tensor],
        sh_bases: list[torch.Tensor],
        weights: list[torch.Tensor],
        descriptors: torch.Tensor,
        degrees: list[int],
        isotropic_only: list[bool],
    ) -> list[torch.Tensor]:
        """Lift one patch.

        Parameters
        ----------
        signals : list over shells of (V, n_p) tensors
            Normalised signals ``s_ij``.
        sh_bases : list over shells of (n_p, n_coeff(l_max)) tensors
            ``Y_lm(g_i)`` for the directions of that shell, precomputed.
        weights : list over shells of (n_p,) tensors
            Quadrature weights ``w_p`` from (12).
        descriptors : (P, n_desc) tensor
            ``gamma_p`` from (14), one row per shell.
        degrees : list over shells of int
            ``L_p`` from (13).
        isotropic_only : list over shells of bool
            True for spherical encoding, where the direction carries nothing.

        Returns
        -------
        list over even degrees of (V, N_h*C, 2l+1) tensors
        """
        n_shells = len(signals)
        if n_shells == 0:
            raise ValueError("a protocol with no nonzero shell cannot be lifted")
        V = signals[0].shape[0]
        degs = even_degrees(self.l_max)
        offsets = {}
        off = 0
        for ell in degs:
            offsets[ell] = off
            off += 2 * ell + 1

        per_shell: list[list[torch.Tensor]] = []   # [p][degree] -> (V, C, 2l+1)
        inv_feats = []                             # [p] -> (V, C), the l=0 block
        for p in range(n_shells):
            s = signals[p]                                     # (V, n_p)
            gam = descriptors[p].unsqueeze(0).unsqueeze(0)     # (1,1,n_desc)
            gam = gam.expand(s.shape[0], s.shape[1], -1)
            phi = self.phi(s, gam)                             # (V, n_p, C)
            w = weights[p]                                     # (n_p,)
            wphi = phi * w.view(1, -1, 1)                      # (V, n_p, C)

            blocks = []
            for ell in degs:
                dim = 2 * ell + 1
                if ell == 0:
                    # Equation (15) at l=0.  For a spherical shell this is the
                    # only term that survives, and it reduces to the mean of phi
                    # times sqrt(4 pi) under uniform weights -- the orthonormal
                    # form of the expression in Section IV-B.
                    Y0 = sh_bases[p][:, 0:1]                   # (n_p, 1)
                    z = torch.einsum("vnc,nk->vck", wphi, Y0)  # (V, C, 1)
                    blocks.append(z)
                elif isotropic_only[p] or ell > degrees[p]:
                    # Degrees the rule cannot integrate exactly are not claimed.
                    blocks.append(wphi.new_zeros(V, self.channels, dim))
                else:
                    o = offsets[ell]
                    Yl = sh_bases[p][:, o : o + dim]           # (n_p, dim)
                    blocks.append(torch.einsum("vnc,nk->vck", wphi, Yl))
            per_shell.append(blocks)
            inv_feats.append(blocks[0][..., 0])                # (V, C)

        # -- equation (17): multi-head attention pooling over shells ---------
        inv = torch.stack(inv_feats, dim=1)                    # (V, P, C)
        desc = descriptors.unsqueeze(0).expand(V, -1, -1)      # (V, P, n_desc)
        k = self.kappa(torch.cat([inv, desc], dim=-1))         # (V, P, H)
        scores = torch.einsum("hH,vpH->vhp", self.queries, k)  # (V, n_heads, P)
        alpha = torch.softmax(scores, dim=-1)

        out = []
        for i, ell in enumerate(degs):
            stacked = torch.stack([per_shell[p][i] for p in range(n_shells)], dim=1)
            # stacked: (V, P, C, 2l+1)
            pooled = torch.einsum("vhp,vpcm->vhcm", alpha, stacked)
            out.append(pooled.reshape(V, self.n_heads * self.channels, 2 * ell + 1))
        return out
