"""Identifiability-aware inference: equation (10) and Section IV-G.

    rho(A) = ( rho_FW, rho_MD, rho_FOD, rho_muFA )(A)

Each entry takes one of ``identified``, ``approximate`` or ``prior-driven``.

Three properties of this rule are the point of it, and all three are enforced
here:

1. **It reads the protocol alone.**  No image data, no model output, no trained
   parameter enters.  So it can be evaluated *before a scan is acquired*, which
   makes it a study-design check and not only a post-hoc label (Section X-D).
   :func:`identifiability_map` takes a :class:`~equal.data.protocols.Protocol`
   and nothing else, by design.
2. **Every label is conditional on a stated model.**  ``identified`` means the
   data determine the readout *within the named model* -- two-compartment,
   cumulant, or spherical convolution -- not within the full class (2).  Each
   verdict therefore carries the model it is conditional on, so a reader who
   rejects that model can see what the label rested on.
3. **Mathematical identifiability is not practical identifiability.**  Theorem 5
   concerns noise-free data of infinite precision.  A flag that reads
   ``identified`` is a statement about the protocol, never a promise about the
   estimate; Table XVI reports the two side by side and Section VIII-E is
   explicit that they often disagree.

EQUAL always returns every readout.  ``prior-driven`` readouts are flagged
rather than hidden, so a reader can see that a free-water map from a
single-shell clinical scan reflects the training population rather than that
patient's data.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np

from .data.protocols import Protocol

__all__ = [
    "Flag",
    "Verdict",
    "IdentifiabilityMap",
    "identifiability_map",
    "fod_degree",
    "READOUTS",
]

Flag = Literal["identified", "approximate", "prior-driven"]

READOUTS = ("FW", "MD", "FOD", "muFA")

#: Section IV-G: the FOD degree rule uses the densest LTE shell at or above this
#: b-value, because lower shells carry too little angular contrast.
_FOD_MIN_B = 1000.0


@dataclass(frozen=True)
class Verdict:
    """One readout's flag, with the model it is conditional on and the reason."""

    readout: str
    flag: Flag
    model: str
    reason: str

    def __str__(self) -> str:
        return f"{self.readout}: {self.flag} ({self.reason}; under the {self.model})"


@dataclass(frozen=True)
class IdentifiabilityMap:
    """``rho(A)`` of equation (10)."""

    verdicts: dict[str, Verdict]
    protocol_name: str = "unnamed"

    def __getitem__(self, readout: str) -> Verdict:
        return self.verdicts[readout]

    def flag(self, readout: str) -> Flag:
        return self.verdicts[readout].flag

    def as_dict(self) -> dict[str, str]:
        return {k: v.flag for k, v in self.verdicts.items()}

    def ordinal(self, readout: str) -> int:
        """``identified`` -> 0, ``approximate`` -> 1, ``prior-driven`` -> 2.

        Section VI-C.4 treats the three-level flag as an **ordinal score** when
        it is used as a detector, which is what makes its ROC curve have two
        interior points and what requires tied levels to count one half.
        """
        return {"identified": 0, "approximate": 1, "prior-driven": 2}[self.flag(readout)]

    def __str__(self) -> str:
        head = f"rho({self.protocol_name}):"
        return "\n".join([head] + [f"  {v}" for v in self.verdicts.values()])


def fod_degree(
    protocol: Protocol, min_b: float = _FOD_MIN_B, l_max: int | None = 8
) -> int:
    """``l_A`` of Section IV-G.

    The largest even degree with ``(l_A + 1)(l_A + 2) / 2 <= |I_p|`` on the
    densest LTE shell with ``b >= min_b``.  Returns 0 when no such shell exists.

    Note this counts *directions on one shell*, not total measurements: the
    orientational part of the FOD is identified under the spherical convolution
    model shell by shell.

    ``l_max`` caps the result at the degree the FOD is actually represented to.
    Equation (27) projects onto even harmonics up to degree 8, so a protocol
    dense enough to support degree 10 still yields an output that carries only
    degree 8, and reporting ``l_A = 10`` would claim angular resolution the
    readout does not have.  The cap does not change any flag, since the
    threshold for ``identified`` is ``l_A >= 6``.  Pass ``l_max=None`` for the
    uncapped quantity as Section IV-G defines it.
    """
    lte = [
        s for s in protocol.nonzero_shells()
        if s.shape == "LTE" and s.b >= min_b - 1e-9
    ]
    if not lte:
        return 0
    n = max(s.n_directions for s in lte)
    best = 0
    for ell in range(0, 33, 2):
        if (ell + 1) * (ell + 2) / 2 <= n:
            best = ell
        else:
            break
    return best if l_max is None else min(best, l_max)


def _fw_verdict(protocol: Protocol) -> Verdict:
    """Theorem 5(iv) with ``n = 1``: the two-compartment FW-DTI model [8].

    FW is identified when the protocol contains at least two distinct nonzero
    b-values; the gap between ``d_t`` and ``d_fw`` is what keeps the two rates
    apart.  Within the full K-atom class the same theorem would need ``2K + 1``
    distinct b-values, which no clinical protocol provides -- so the label is
    conditional on the two-compartment model and says so.

    With one shell it is prior-driven: Theorem 5(iii) exhibits a continuum of
    pairs ``(f, lambda)`` matching the same single-shell signal exactly.
    """
    n_b = len(protocol.distinct_b_values())
    if n_b >= 2:
        return Verdict("FW", "identified", "two-compartment FW-DTI model (Thm 5(iv), n=1)",
                       f"{n_b} distinct nonzero b-values")
    return Verdict("FW", "prior-driven", "two-compartment FW-DTI model (Thm 5(iii))",
                   "a single shell admits a continuum of (f, lambda) pairs")


def _md_verdict(protocol: Protocol) -> Verdict:
    """Second-order cumulant model [24].

    With one shell MD is *approximate*: the powder-averaged signal satisfies
    ``log E(b) = -b MD + b^2 V / 2 + O(b^3)``, so a single-shell estimate
    underestimates MD by about ``b V / 2``.
    """
    n_b = len(protocol.distinct_b_values())
    if n_b >= 2:
        return Verdict("MD", "identified", "second-order cumulant model [24]",
                       f"{n_b} distinct nonzero b-values")
    if n_b == 1:
        return Verdict("MD", "approximate", "second-order cumulant model [24]",
                       "one shell: biased low by about b V / 2")
    return Verdict("MD", "prior-driven", "second-order cumulant model [24]",
                   "no nonzero b-value")


def _fod_verdict(protocol: Protocol) -> Verdict:
    """Spherical convolution model of constrained spherical deconvolution [23].

    Only the **orientational** part of the FOD -- its normalised coefficients
    with ``l >= 2`` -- can be identified from LTE data, because the amplitude in
    (27) depends on anisotropy (Theorem 5(ii)).  The degree rule then gives
    identified for ``l_A >= 6``, approximate for ``l_A = 4``, prior-driven below.
    """
    la = fod_degree(protocol)
    if la >= 6:
        flag: Flag = "identified"
    elif la == 4:
        flag = "approximate"
    else:
        flag = "prior-driven"
    return Verdict(
        "FOD", flag, "spherical convolution model [23]; orientational part (l>=2) only",
        f"l_A = {la} on the densest LTE shell with b >= {int(_FOD_MIN_B)}",
    )


def _mufa_verdict(protocol: Protocol) -> Verdict:
    """Theorem 5(ii) and the cumulant relation (26).

    muFA is **never** identified by LTE data alone, at any angular resolution:
    uniformly oriented sticks and a spread of isotropic tensors give identical
    LTE signals for every b and g, yet have muFA 1 and 0 respectively.

    It is identified when LTE data and either PTE or STE data are each available
    at two or more distinct nonzero b-values, which fixes the second-order
    cumulants used by QTI [4]; approximate when the encodings share a single
    b-value.
    """
    shapes = protocol.shapes_present()
    has_lte = "LTE" in shapes
    partners = [s for s in ("PTE", "STE") if s in shapes]
    if not has_lte or not partners:
        return Verdict(
            "muFA", "prior-driven", "Thm 5(ii)",
            "linear encoding only: sticks and isotropic spreads are indistinguishable",
        )
    n_lte = len(protocol.distinct_b_values("LTE"))
    n_partner = max(len(protocol.distinct_b_values(s)) for s in partners)
    if n_lte >= 2 and n_partner >= 2:
        return Verdict(
            "muFA", "identified", "second-order cumulant model, QTI [4] and [25]",
            f"LTE at {n_lte} and {'/'.join(partners)} at {n_partner} distinct nonzero b-values",
        )
    return Verdict(
        "muFA", "approximate", "second-order cumulant model, QTI [4] and [25]",
        f"LTE at {n_lte} and {'/'.join(partners)} at {n_partner} distinct nonzero "
        f"b-values: the encodings do not both reach two shells",
    )


def identifiability_map(protocol: Protocol) -> IdentifiabilityMap:
    """Evaluate ``rho(A)``.

    Takes a protocol and nothing else -- no image, no model, no weights.  That
    restriction is the point: it is what lets the same rule be run on a *planned*
    protocol before any subject is scanned.
    """
    if not isinstance(protocol, Protocol):
        raise TypeError(
            "the identifiability rule reads a Protocol and nothing else; "
            "passing image data or model output would defeat its purpose"
        )
    verdicts = {
        "FW": _fw_verdict(protocol),
        "MD": _md_verdict(protocol),
        "FOD": _fod_verdict(protocol),
        "muFA": _mufa_verdict(protocol),
    }
    return IdentifiabilityMap(verdicts=verdicts, protocol_name=protocol.name)
