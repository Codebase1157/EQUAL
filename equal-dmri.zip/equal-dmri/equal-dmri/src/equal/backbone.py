"""Joint roto-translation equivariant backbone: equations (18) to (20).

The patch is treated as a point cloud of ``V`` voxel centres **in millimetres**,
not as a voxel lattice.  Reading physical coordinates is what makes the network
aware of voxel size, a nuisance that lattice-based patch embeddings absorb
implicitly (Section IV-C).

The symmetry is the **joint** (diagonal) action of SE(3) on image space and
q-space -- the transformation a rigid motion of the head actually induces.  The
larger product group ``E(3) x SO(3)`` of [17] lets q-space rotate independently
of anatomy, which is more symmetry than the physics has: a fibre's orientation
is tied to the course of its tract through space, and product-group equivariance
would forbid the network from relating a fibre's orientation to the direction in
which its neighbours lie.  ``symmetry_group="product"`` implements that variant
for the ablation in Table XX.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn

from .equivariance import (
    EquivariantLayerNorm,
    GatedNonlinearity,
    SO2Linear,
    SteerableSpec,
    WignerCache,
    edge_frame_rotation,
)
from .sh import even_degrees

__all__ = ["EquivariantBackbone", "EdgeGeometry", "build_edges"]


class EdgeGeometry:
    """Precomputed per-edge geometry for one patch.

    Wigner blocks are constants with respect to the parameters, so they are
    built once in numpy and cached by direction; a voxel lattice yields very few
    distinct edge directions, so the cache hit rate is high.
    """

    __slots__ = ("src", "dst", "dist", "wigner", "n_edges")

    def __init__(self, src, dst, dist, wigner):
        self.src = src
        self.dst = dst
        self.dist = dist
        self.wigner = wigner        # list over degrees of (E, 2l+1, 2l+1)
        self.n_edges = int(src.shape[0])


def build_edges(
    positions: np.ndarray,
    r_cut: float,
    cache: WignerCache,
    l_max: int,
    dtype: torch.dtype = torch.float32,
) -> EdgeGeometry:
    """Build the neighbour graph within ``r_cut`` millimetres.

    ``positions`` is (V, 3) in millimetres.  Self-edges are excluded.
    """
    positions = np.asarray(positions, dtype=float)
    V = positions.shape[0]
    diff = positions[None, :, :] - positions[:, None, :]       # (V, V, 3): x_j' - x_j
    dist = np.linalg.norm(diff, axis=-1)
    mask = (dist > 0) & (dist <= r_cut)
    src_j, dst_jp = np.nonzero(mask)                           # edge j <- j'
    if src_j.size == 0:
        raise ValueError(
            f"no edges within r_cut={r_cut} mm for {V} voxels; the patch is "
            f"disconnected and the backbone would be a no-op"
        )
    r = diff[src_j, dst_jp]                                    # (E, 3)
    d = dist[src_j, dst_jp]

    degs = even_degrees(l_max)
    blocks = [np.empty((len(src_j), 2 * l + 1, 2 * l + 1), dtype=np.float64) for l in degs]
    for e in range(len(src_j)):
        R = edge_frame_rotation(r[e])
        Ds = cache.blocks(R)
        for i in range(len(degs)):
            blocks[i][e] = Ds[i].numpy()
    wig = [torch.as_tensor(b, dtype=dtype) for b in blocks]
    return EdgeGeometry(
        torch.as_tensor(src_j, dtype=torch.long),
        torch.as_tensor(dst_jp, dtype=torch.long),
        torch.as_tensor(d, dtype=dtype),
        wig,
    )


class _RadialBasis(nn.Module):
    """Gaussian radial basis ``beta(||r||)`` with the cosine envelope ``chi``.

    ``chi`` falls smoothly to zero at ``r_c`` so that a neighbour entering or
    leaving the cutoff does not produce a discontinuity in the output.
    """

    def __init__(self, n_basis: int, r_cut: float):
        super().__init__()
        self.r_cut = r_cut
        centres = torch.linspace(0.0, r_cut, n_basis)
        self.register_buffer("centres", centres)
        self.width = float(r_cut / max(n_basis - 1, 1))

    def envelope(self, d: torch.Tensor) -> torch.Tensor:
        return 0.5 * (1.0 + torch.cos(np.pi * torch.clamp(d / self.r_cut, max=1.0)))

    def forward(self, d: torch.Tensor) -> torch.Tensor:
        g = torch.exp(-((d.unsqueeze(-1) - self.centres) ** 2) / (2.0 * self.width**2))
        return g * self.envelope(d).unsqueeze(-1)


class _EquivariantBlock(nn.Module):
    """One message-passing block: equations (18), (19), (20).

    (18) rotates the neighbour's features into the edge frame, applies the
    SO(2)-reduced map, and rotates back.  (19) scores edges with invariants
    only, so the attention weights are scalars and commute with rotations.
    (20) is a residual update, followed by equivariant normalisation and the
    gated nonlinearity.
    """

    def __init__(
        self,
        spec: SteerableSpec,
        n_radial: int,
        n_heads: int,
        r_cut: float,
        symmetry_group: str = "joint",
        radial_rank: int | None = 4,
    ):
        super().__init__()
        self.spec = spec
        self.n_heads = n_heads
        self.symmetry_group = symmetry_group
        self.radial = _RadialBasis(n_radial, r_cut)
        self.so2 = SO2Linear(spec, spec, n_radial, radial_rank=radial_rank)
        c0 = spec.channels[0]
        self.d_att = max(c0 // n_heads, 1)
        self.to_q = nn.Linear(c0, n_heads * self.d_att)
        self.to_k = nn.Linear(c0 + n_radial, n_heads * self.d_att)
        self.norm = EquivariantLayerNorm(spec)
        self.gate = GatedNonlinearity(spec)

    def forward(self, h: list[torch.Tensor], geo: EdgeGeometry) -> list[torch.Tensor]:
        src, dst = geo.src, geo.dst
        rad = self.radial(geo.dist)                            # (E, n_radial)

        # -- (18) message in the edge frame ------------------------------
        h_nb = [x[dst] for x in h]                             # (E, C_l, 2l+1)
        if self.symmetry_group == "joint":
            rot = [torch.einsum("emn,ecn->ecm", geo.wigner[i], h_nb[i])
                   for i in range(len(h_nb))]
            msg = self.so2(rot, rad)
            msg = [torch.einsum("enm,ecn->ecm", geo.wigner[i], msg[i])
                   for i in range(len(msg))]
        elif self.symmetry_group == "product":
            # Ablation (Table XX, "Symmetry group"): q-space is allowed to
            # rotate independently of anatomy, so the edge frame is not used to
            # relate the two and the message is a purely radial, degree-wise map.
            msg = self.so2(h_nb, rad)
        else:
            raise ValueError(f"unknown symmetry_group {self.symmetry_group!r}")

        # -- (19) attention with invariant scores --------------------------
        inv_self = h[0][..., 0]                                # (V, C_0)
        inv_nb = h_nb[0][..., 0]                               # (E, C_0)
        q = self.to_q(inv_self).view(-1, self.n_heads, self.d_att)[src]
        k = self.to_k(torch.cat([inv_nb, rad], dim=-1)).view(-1, self.n_heads, self.d_att)
        logits = (q * k).sum(-1) / np.sqrt(self.d_att)         # (E, n_heads)
        env = self.radial.envelope(geo.dist).unsqueeze(-1)     # (E, 1)
        num = env * torch.exp(logits - logits.max())
        den = torch.zeros(h[0].shape[0], self.n_heads, device=num.device, dtype=num.dtype)
        den.index_add_(0, src, num)
        a = num / (den[src] + 1e-12)                           # (E, n_heads)
        a_edge = a.mean(dim=-1)                                # scalar per edge

        # -- (20) aggregate and update --------------------------------------
        out = []
        for i, x in enumerate(h):
            agg = torch.zeros_like(x)
            agg.index_add_(0, src, msg[i] * a_edge.view(-1, 1, 1))
            out.append(x + agg)
        return self.gate(self.norm(out))


class EquivariantBackbone(nn.Module):
    """``B_theta`` of equation (11): six blocks with eight attention heads."""

    def __init__(
        self,
        in_spec: SteerableSpec,
        l_max: int = 8,
        c_invariant: int = 128,
        c_steerable: int = 64,
        n_blocks: int = 6,
        n_heads: int = 8,
        n_radial: int = 16,
        r_cut: float = 8.0,
        symmetry_group: str = "joint",
        radial_rank: int | None = 4,
    ):
        super().__init__()
        degs = even_degrees(l_max)
        channels = tuple(c_invariant if l == 0 else c_steerable for l in degs)
        self.spec = SteerableSpec(l_max, channels)
        self.r_cut = r_cut
        self.l_max = l_max
        # Degree-wise channel projection from the lift; a per-degree linear map
        # over channels commutes with D_l(R), so this is equivariant.
        self.project = nn.ParameterList(
            [
                nn.Parameter(
                    torch.randn(channels[i], in_spec.channels[i])
                    / np.sqrt(in_spec.channels[i])
                )
                for i in range(len(degs))
            ]
        )
        self.blocks = nn.ModuleList(
            [
                _EquivariantBlock(self.spec, n_radial, n_heads, r_cut,
                                  symmetry_group, radial_rank)
                for _ in range(n_blocks)
            ]
        )

    def forward(self, z: list[torch.Tensor], geo: EdgeGeometry) -> list[torch.Tensor]:
        h = [torch.einsum("oc,vcm->vom", self.project[i], z[i]) for i in range(len(z))]
        for blk in self.blocks:
            h = blk(h, geo)
        return h
