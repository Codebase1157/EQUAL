"""Statistical protocol: Section VI-D.

The rules this module enforces, each of which the audit's Section 8 asks to be
stated and which are easy to get wrong silently:

* **The unit of analysis** is the one named for each source in Table VIII: the
  subject; a spatial block of 8x8x8 voxels for the single-subject tensor-valued
  data and the phantoms; the simulated field for in silico signal prediction;
  and the independently drawn case for the in silico flag analysis.  Error is
  averaged **within a unit before any test across units**.
* **Three seeds are averaged within a unit before testing**, so a seed is never
  counted as an independent observation.  :func:`aggregate_seeds` is the only
  sanctioned way to collapse them.
* **The 46 retest pairs are resampled as pairs**, not as individual scans.
* **The Holm-Bonferroni family** is the set of comparisons against EQUAL within
  one table.
* For the single-subject tensor-valued data and the phantoms, where
  subject-level tests are impossible, we report bootstrap intervals over spatial
  blocks and **make no significance claims** -- :func:`paired_comparison`
  refuses to return a p-value when told the unit is a spatial block.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Sequence

import numpy as np
from scipy.stats import norm, wilcoxon

__all__ = [
    "AnalysisUnit",
    "ComparisonResult",
    "aggregate_seeds",
    "rank_biserial",
    "bootstrap_ci",
    "paired_comparison",
    "holm_bonferroni",
    "wilson_interval",
    "ordinal_auc",
]

AnalysisUnit = Literal["subject", "spatial_block", "field", "case", "pair"]

#: Units for which subject-level significance testing is not meaningful.
_NO_SIGNIFICANCE: frozenset[str] = frozenset({"spatial_block"})

N_BOOTSTRAP = 10_000


def aggregate_seeds(values: np.ndarray, axis: int = 0) -> np.ndarray:
    """Average the training seeds within a unit (Section VI-D).

    ``values`` has the seed axis at ``axis``.  Averaging here, before any test,
    is what stops a seed being counted as an independent observation and is why
    ``n`` in every test below is the number of units, not units x seeds.
    """
    values = np.asarray(values, dtype=float)
    if values.shape[axis] > 5:
        raise ValueError(
            f"axis {axis} has {values.shape[axis]} entries; this looks like the "
            f"unit axis rather than the seed axis"
        )
    return values.mean(axis=axis)


def rank_biserial(a: np.ndarray, b: np.ndarray) -> float:
    """Rank-biserial effect size ``r`` for a paired comparison.

    Defined as the difference between the proportion of favourable and
    unfavourable signed ranks, which is the effect size reported beside every
    Wilcoxon p-value in the manuscript's tables.
    """
    d = np.asarray(a, dtype=float) - np.asarray(b, dtype=float)
    d = d[d != 0]
    if d.size == 0:
        return 0.0
    from scipy.stats import rankdata

    ranks = rankdata(np.abs(d))
    total = ranks.sum()
    pos = ranks[d > 0].sum()
    neg = ranks[d < 0].sum()
    return float((pos - neg) / total)


def bootstrap_ci(
    values: np.ndarray,
    statistic=np.mean,
    n_resamples: int = N_BOOTSTRAP,
    confidence: float = 0.95,
    seed: int = 0,
    paired: bool = False,
) -> tuple[float, float]:
    """Percentile bootstrap interval over the unit of analysis.

    ``values`` is one row per unit.  When ``paired`` is set, ``values`` is
    (n_units, 2) and whole **pairs** are resampled -- which is what the 46
    retest pairs require.
    """
    values = np.asarray(values, dtype=float)
    rng = np.random.default_rng(seed)
    n = values.shape[0]
    if n < 2:
        raise ValueError("need at least two units to bootstrap")
    idx = rng.integers(0, n, size=(n_resamples, n))
    if paired:
        if values.ndim != 2 or values.shape[1] != 2:
            raise ValueError("paired bootstrap expects a (n_units, 2) array")
        draws = values[idx]                               # (R, n, 2)
        stat = statistic(draws[..., 0] - draws[..., 1], axis=1)
    else:
        stat = statistic(values[idx], axis=1)
    lo = float(np.percentile(stat, 100 * (1 - confidence) / 2))
    hi = float(np.percentile(stat, 100 * (1 + confidence) / 2))
    return lo, hi


@dataclass(frozen=True)
class ComparisonResult:
    """One paired comparison against EQUAL."""

    name: str
    n_units: int
    unit: str
    median_difference: float
    effect_size: float
    ci: tuple[float, float]
    p_value: float | None
    p_adjusted: float | None = None

    @property
    def significance_claimed(self) -> bool:
        return self.p_value is not None


def paired_comparison(
    reference: np.ndarray,
    other: np.ndarray,
    name: str,
    unit: AnalysisUnit = "subject",
    seed: int = 0,
) -> ComparisonResult:
    """Wilcoxon signed-rank comparison with effect size and bootstrap interval.

    Returns ``p_value = None`` when ``unit`` is one for which the manuscript
    makes no significance claim (the single-subject tensor-valued data and the
    phantoms, Section VI-D).  The interval is still reported.
    """
    a = np.asarray(reference, dtype=float)
    b = np.asarray(other, dtype=float)
    if a.shape != b.shape or a.ndim != 1:
        raise ValueError("reference and other must be 1-D arrays over units")
    if a.size < 2:
        raise ValueError("need at least two units")

    diff = b - a
    ci = bootstrap_ci(np.stack([b, a], axis=1), paired=True, seed=seed)
    p: float | None
    if unit in _NO_SIGNIFICANCE:
        p = None
    elif np.allclose(diff, 0):
        p = 1.0
    else:
        p = float(wilcoxon(b, a, zero_method="wilcox").pvalue)
    return ComparisonResult(
        name=name,
        n_units=int(a.size),
        unit=str(unit),
        median_difference=float(np.median(diff)),
        effect_size=rank_biserial(b, a),
        ci=ci,
        p_value=p,
    )


def holm_bonferroni(
    results: Sequence[ComparisonResult], alpha: float = 0.05
) -> list[ComparisonResult]:
    """Holm's sequentially rejective correction [49] within one table.

    The family is the set of comparisons against EQUAL **within one table**, as
    Section VI-D states.  Comparisons carrying no p-value pass through
    untouched, since they make no significance claim to correct.
    """
    testable = [r for r in results if r.p_value is not None]
    order = sorted(range(len(testable)), key=lambda i: testable[i].p_value)
    m = len(testable)
    adjusted: dict[int, float] = {}
    running = 0.0
    for rank, i in enumerate(order):
        val = (m - rank) * testable[i].p_value
        running = max(running, val)
        adjusted[i] = min(running, 1.0)

    out: list[ComparisonResult] = []
    k = 0
    for r in results:
        if r.p_value is None:
            out.append(r)
        else:
            out.append(
                ComparisonResult(
                    r.name, r.n_units, r.unit, r.median_difference, r.effect_size,
                    r.ci, r.p_value, adjusted[k],
                )
            )
            k += 1
    return out


def wilson_interval(
    successes: int, trials: int, confidence: float = 0.95
) -> tuple[float, float]:
    """Wilson score interval for a proportion.

    Used for the flag calibration and the false-confident rate of Table XVII,
    where counts are small and a normal-approximation interval would run outside
    [0, 1].
    """
    if trials <= 0:
        raise ValueError("trials must be positive")
    if not 0 <= successes <= trials:
        raise ValueError("successes must lie in [0, trials]")
    z = float(norm.ppf(0.5 + confidence / 2))
    p = successes / trials
    den = 1 + z**2 / trials
    centre = (p + z**2 / (2 * trials)) / den
    half = z * np.sqrt(p * (1 - p) / trials + z**2 / (4 * trials**2)) / den
    return float(max(0.0, centre - half)), float(min(1.0, centre + half))


def ordinal_auc(scores: np.ndarray, labels: np.ndarray) -> float:
    """Area under the ROC curve of an **ordinal** score, ties counted one half.

    Section VI-C.4: the three-level flag is an ordinal score, so its ROC curve
    has two interior points and tied levels count one half in the area.  This is
    the Mann-Whitney U statistic normalised, which handles ties correctly by
    construction -- computing the area from the three-point curve with ties
    broken arbitrarily would not.

    ``scores`` higher means more likely positive; ``labels`` is boolean, True
    for the positive class (here, an unreliable readout).
    """
    s = np.asarray(scores, dtype=float)
    y = np.asarray(labels, dtype=bool)
    pos, neg = s[y], s[~y]
    if pos.size == 0 or neg.size == 0:
        raise ValueError("need both classes present to compute an AUC")
    diff = pos[:, None] - neg[None, :]
    wins = (diff > 0).sum() + 0.5 * (diff == 0).sum()
    return float(wins / (pos.size * neg.size))
