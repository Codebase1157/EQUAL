"""Model-based baselines of Section VI-B, group (a).

These fit per scan and borrow no strength across subjects, which is precisely
the limitation Section II-C describes: they are protocol-independent in a sense,
but they degrade quickly when the acquisition is sparse and nothing in the basis
prevents an evaluated signal from rising with b.  :func:`sh_interpolate` and
:func:`fit_dti` are therefore expected to show nonzero violation rates in (39),
unlike EQUAL where Theorem 4 forbids it.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..sh import n_coeff, real_sh
from ..signal_model import D_FREE_WATER

__all__ = [
    "DTIFit", "FreeWaterDTI", "SHInterpolation",
    "fit_dti", "fit_free_water_dti", "sh_interpolate", "powder_average",
]


@dataclass
class DTIFit:
    """A single diffusion tensor per voxel."""

    tensors: np.ndarray                 # (V, 3, 3)
    s0: np.ndarray                      # (V,)

    def predict(self, B: np.ndarray) -> np.ndarray:
        rates = np.einsum("nij,vij->vn", np.asarray(B), self.tensors)
        return np.exp(-rates)

    @property
    def mean_diffusivity(self) -> np.ndarray:
        return np.einsum("vii->v", self.tensors) / 3.0

    @property
    def fractional_anisotropy(self) -> np.ndarray:
        ev = np.linalg.eigvalsh(self.tensors)
        md = ev.mean(axis=1, keepdims=True)
        num = np.sqrt(1.5 * ((ev - md) ** 2).sum(axis=1))
        den = np.sqrt((ev**2).sum(axis=1)) + 1e-20
        return num / den


def fit_dti(signals: np.ndarray, B: np.ndarray, ridge: float = 1e-8) -> DTIFit:
    """Weighted least squares on the log signal.

    ``log E = -<B, D>`` is linear in the six independent entries of ``D``.  This
    is a reference implementation, not a replacement for a production DTI fit:
    it uses the log-transform, which (as Section IV-F notes) overweights low,
    noise-floor-dominated signals at high b -- one of the reasons EQUAL uses the
    Rician likelihood instead.
    """
    signals = np.atleast_2d(np.asarray(signals, dtype=float))
    B = np.asarray(B, dtype=float)
    if signals.shape[1] != B.shape[0]:
        raise ValueError("signals and b-tensors disagree in length")

    # Design: columns are (Bxx, Byy, Bzz, 2Bxy, 2Bxz, 2Byz)
    A = np.stack([
        B[:, 0, 0], B[:, 1, 1], B[:, 2, 2],
        2 * B[:, 0, 1], 2 * B[:, 0, 2], 2 * B[:, 1, 2],
    ], axis=1)
    y = -np.log(np.clip(signals, 1e-8, None))
    G = A.T @ A + ridge * np.eye(6)
    coef = np.linalg.solve(G, A.T @ y.T).T            # (V, 6)
    V = signals.shape[0]
    D = np.zeros((V, 3, 3))
    D[:, 0, 0], D[:, 1, 1], D[:, 2, 2] = coef[:, 0], coef[:, 1], coef[:, 2]
    D[:, 0, 1] = D[:, 1, 0] = coef[:, 3]
    D[:, 0, 2] = D[:, 2, 0] = coef[:, 4]
    D[:, 1, 2] = D[:, 2, 1] = coef[:, 5]
    return DTIFit(tensors=D, s0=np.ones(V))


@dataclass
class FreeWaterDTI:
    """Two-compartment free-water elimination [8]."""

    f_free_water: np.ndarray            # (V,)
    tissue_tensors: np.ndarray          # (V, 3, 3)

    def predict(self, B: np.ndarray) -> np.ndarray:
        B = np.asarray(B)
        tr = np.einsum("nii->n", B)
        fw = np.exp(-tr * D_FREE_WATER)[None, :]
        rates = np.einsum("nij,vij->vn", B, self.tissue_tensors)
        return self.f_free_water[:, None] * fw + (1 - self.f_free_water)[:, None] * np.exp(-rates)


def fit_free_water_dti(
    signals: np.ndarray, B: np.ndarray, n_grid: int = 41
) -> FreeWaterDTI:
    """Grid search over the free-water fraction, with a DTI fit at each step.

    With a single shell this problem is **not identifiable**: Theorem 5(iii)
    exhibits a continuum of ``(f, lambda)`` pairs matching the data exactly, so
    the grid search will return whichever point the objective happens to favour.
    That is the behaviour the identifiability flag exists to report, not a bug
    in this function.
    """
    signals = np.atleast_2d(np.asarray(signals, dtype=float))
    B = np.asarray(B, dtype=float)
    tr = np.einsum("nii->n", B)
    fw_signal = np.exp(-tr * D_FREE_WATER)

    V = signals.shape[0]
    best_err = np.full(V, np.inf)
    best_f = np.zeros(V)
    best_D = np.zeros((V, 3, 3))
    for f in np.linspace(0.0, 0.95, n_grid):
        resid = (signals - f * fw_signal[None, :]) / max(1.0 - f, 1e-6)
        fit = fit_dti(np.clip(resid, 1e-6, None), B)
        err = ((fit.predict(B) * (1 - f) + f * fw_signal[None, :] - signals) ** 2).sum(1)
        take = err < best_err
        best_err[take] = err[take]
        best_f[take] = f
        best_D[take] = fit.tensors[take]
    return FreeWaterDTI(f_free_water=best_f, tissue_tensors=best_D)


@dataclass
class SHInterpolation:
    """Per-shell spherical-harmonic fit, used for signal imputation.

    Section VI-C.1 also uses a degree-8 SH fit to map grid outputs back to the
    held-out directions, so that a grid-based model is scored on the same raw
    measurements as everything else.
    """

    coefficients: dict[int, np.ndarray]     # shell index -> (V, n_coeff)
    l_max: int

    def predict_shell(self, shell_idx: int, directions: np.ndarray) -> np.ndarray:
        Y = real_sh(self.l_max, directions)
        return self.coefficients[shell_idx] @ Y.T


def sh_interpolate(
    signals_per_shell: list[np.ndarray],
    directions_per_shell: list[np.ndarray],
    l_max: int = 8,
    ridge: float = 1e-6,
) -> SHInterpolation:
    """Fit even SH coefficients per shell by ridge-regularised least squares.

    The degree is capped by what the directions support: fitting ``n_coeff(l)``
    coefficients from fewer than that many directions is under-determined, and
    the ridge would silently decide the answer.  We lower the degree instead,
    which is the same discipline equation (13) applies to the quadrature rule.
    """
    coeffs: dict[int, np.ndarray] = {}
    used = l_max
    for p, (s, g) in enumerate(zip(signals_per_shell, directions_per_shell)):
        s = np.atleast_2d(np.asarray(s, dtype=float))
        n = len(g)
        ell = l_max
        while ell > 0 and n_coeff(ell) > n:
            ell -= 2
        used = min(used, ell)
        Y = real_sh(ell, g)                              # (n, K)
        G = Y.T @ Y + ridge * np.eye(Y.shape[1])
        c = np.linalg.solve(G, Y.T @ s.T).T               # (V, K)
        full = np.zeros((s.shape[0], n_coeff(l_max)))
        full[:, : c.shape[1]] = c
        coeffs[p] = full
    return SHInterpolation(coefficients=coeffs, l_max=l_max)


def powder_average(signals: np.ndarray, shell_index: np.ndarray) -> dict[int, np.ndarray]:
    """Direction-averaged signal per shell.

    The quantity the cumulant relations of [19], [24] and [25] are written in,
    and the one Fig. 15(j) plots.  Averaging over directions removes the
    orientation dependence, leaving the part of the signal that carries
    microscopic anisotropy when compared across encoding shapes.
    """
    signals = np.atleast_2d(np.asarray(signals, dtype=float))
    out = {}
    for p in np.unique(shell_index):
        out[int(p)] = signals[:, shell_index == p].mean(axis=1)
    return out
