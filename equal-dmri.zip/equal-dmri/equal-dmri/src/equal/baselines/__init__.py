"""Baselines that can be run from this repository without external weights.

Section VI-B names four groups.  The ones implemented here are the model-based
fits of group (a), because they are self-contained: they fit per scan and need
no training.  The deep baselines of groups (b) to (d) -- UPER [6], D-RoPE [7],
PIGMENT [44], SH-sCNN [45], the spherical CNN [46], the E(3)xSO(3) network [17]
and the per-protocol SH-CNN [47] -- are run from **their authors' public code**,
retrained on our split with their published hyperparameters.  Reimplementing
them here would make the comparison a comparison with our reimplementation.

:func:`applicable_baselines` encodes which methods can process which protocol at
all.  Section VIII-A is emphatic that this matters: a method that cannot
represent a planar or spherical b-tensor is recorded as ``n/a``, not forced
through a representation never designed for it, and a margin on a source where
most baselines read ``n/a`` is a margin over the few that remain.
"""

from __future__ import annotations

from .model_based import (
    DTIFit, FreeWaterDTI, SHInterpolation, fit_dti, fit_free_water_dti,
    powder_average, sh_interpolate,
)

__all__ = [
    "DTIFit", "FreeWaterDTI", "SHInterpolation",
    "fit_dti", "fit_free_water_dti", "powder_average", "sh_interpolate",
    "applicable_baselines", "BASELINE_CAPABILITIES",
]

#: What each baseline can represent.  ``shapes`` lists the b-tensor shapes it
#: accepts; ``needs_multiple_shapes`` marks a method that is under-determined
#: without more than one (QTI); ``per_protocol`` marks one that has no weights
#: for an unseen shell list (SH-CNN).
BASELINE_CAPABILITIES: dict[str, dict] = {
    "SH_interp": {"shapes": {"LTE"}, "needs_multiple_shapes": False, "per_protocol": False},
    "MAP_MRI":   {"shapes": {"LTE"}, "needs_multiple_shapes": False, "per_protocol": False},
    "SHARD":     {"shapes": {"LTE"}, "needs_multiple_shapes": False, "per_protocol": False},
    "QTI":       {"shapes": {"LTE", "PTE", "STE"}, "needs_multiple_shapes": True,
                  "per_protocol": False},
    "SH_CNN":    {"shapes": {"LTE"}, "needs_multiple_shapes": False, "per_protocol": True},
    "SH_sCNN":   {"shapes": {"LTE"}, "needs_multiple_shapes": False, "per_protocol": False},
    "S_CNN":     {"shapes": {"LTE"}, "needs_multiple_shapes": False, "per_protocol": False},
    "E3xSO3":    {"shapes": {"LTE"}, "needs_multiple_shapes": False, "per_protocol": False},
    "UPER":      {"shapes": {"LTE"}, "needs_multiple_shapes": False, "per_protocol": False},
    "D_RoPE":    {"shapes": {"LTE"}, "needs_multiple_shapes": False, "per_protocol": False},
    "PIGMENT":   {"shapes": {"LTE"}, "needs_multiple_shapes": False, "per_protocol": False},
    "EQUAL":     {"shapes": {"LTE", "PTE", "STE"}, "needs_multiple_shapes": False,
                  "per_protocol": False},
}


def applicable_baselines(protocol, trained_shell_lists=None) -> dict[str, str | None]:
    """Which baselines can process ``protocol``, and why not when they cannot.

    Returns a mapping from method name to ``None`` (applicable) or a short
    reason.  The reasons are those of Table VIII:

    * nine of the eleven baselines represent a measurement by a q-vector and
      have no slot for a planar or spherical b-tensor;
    * QTI needs more than one b-tensor shape, so it cannot be run on
      linear-only data;
    * the per-protocol specialist has no weights for an unseen shell list.
    """
    shapes = protocol.shapes_present()
    out: dict[str, str | None] = {}
    for name, cap in BASELINE_CAPABILITIES.items():
        missing = shapes - cap["shapes"]
        if missing:
            out[name] = (
                f"no slot for {'/'.join(sorted(missing))} encoding: a measurement "
                f"is represented by a q-vector"
            )
        elif cap["needs_multiple_shapes"] and len(shapes) < 2:
            out[name] = "needs more than one b-tensor shape; LTE-only data under-determine it"
        elif cap["per_protocol"] and trained_shell_lists is not None:
            key = tuple(sorted((s.b, s.shape) for s in protocol.nonzero_shells()))
            out[name] = None if key in trained_shell_lists else (
                "one network per protocol; no weights exist for this shell list")
        else:
            out[name] = None
    return out
