"""Quadrature-weighted lifting: equations (12) and (13).

Equation (12) -- minimum-norm nonnegative rule exact to degree L_p:

    w_p = argmin_{w >= 0} ||w||_2^2   s.t.   Phi_{p,<=L_p}^T w = t,

with ``t = \\int Y_lm dOmega = sqrt(4 pi) e_1`` in the orthonormal basis used
here (see the note in ``equal.sh``).

Equation (13) -- the exact degree is the largest even degree for which such a
rule exists:

    L_p = max { l <= L, l even : exists w >= 0 with Phi_{p,<=l}^T w = t }.

Two properties are what Theorem 2 relies on, and both are asserted by the tests:
**exactness** to degree L_p and **nonnegativity** of the weights.

Solver
------
(13) is a linear feasibility problem and is decided exactly with a phase-1 LP
(`scipy.optimize.linprog`, HiGHS).

(12) is a strictly convex QP with linear equality constraints and a
nonnegativity bound.  We solve its Lagrangian dual, which is smooth,
unconstrained and concave:

    w(lambda) = [Phi lambda / 2]_+ ,
    g(lambda) = -|| w(lambda) ||^2 + lambda^T t ,      grad g = t - Phi^T w(lambda).

Maximising ``g`` with L-BFGS-B recovers the unique primal minimiser.  Section
VII-A of the manuscript notes that uniqueness of this minimiser is what makes
the weights a *function of the direction set* rather than a choice, and hence
what makes Theorem 1 hold: a rotated protocol must receive the rotated rule, not
a different one.  ``solve_minimum_norm_weights`` therefore refuses to return a
solution whose constraint residual exceeds ``tol``.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import linprog, minimize

from .sh import even_degrees, n_coeff, real_sh, sh_integral_vector

__all__ = [
    "QuadratureRule",
    "is_degree_feasible",
    "exact_degree",
    "solve_minimum_norm_weights",
    "build_rule",
]

_TOTAL_WEIGHT = 4.0 * np.pi


@dataclass(frozen=True)
class QuadratureRule:
    """A quadrature rule attached to one shell.

    Attributes
    ----------
    weights : (N,) array
        Nonnegative weights ``w_p`` of equation (12).
    degree : int
        The exact degree ``L_p`` of equation (13).
    directions : (N, 3) array
        The directions the rule was computed for.
    residual : float
        ``max |Phi^T w - t|`` at degree ``L_p``; a diagnostic, asserted small.
    is_isotropic_only : bool
        True when ``degree == 0``, i.e. the directions support no angular
        information at all and the lifting keeps only the l=0 feature.
    """

    weights: np.ndarray
    degree: int
    directions: np.ndarray
    residual: float
    is_isotropic_only: bool = field(default=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "is_isotropic_only", self.degree == 0)

    def integrate(self, values: np.ndarray) -> np.ndarray:
        """Approximate ``\\int_{S^2} f dOmega`` from samples ``f(g_i)``.

        ``values`` has shape (N, ...) with N the number of directions.
        """
        w = self.weights
        return np.tensordot(w, np.asarray(values), axes=(0, 0))


def _design(directions: np.ndarray, ell: int) -> np.ndarray:
    """``Phi_{<=ell}``: one row per direction, one column per harmonic."""
    return real_sh(ell, directions)


def is_degree_feasible(directions: np.ndarray, ell: int, tol: float = 1e-8) -> bool:
    """Does a nonnegative rule exact to degree ``ell`` exist for these directions?

    Decided by a phase-1 linear program: minimise 0 subject to
    ``Phi^T w = t, w >= 0``.  Feasibility at ``ell = 0`` is automatic (uniform
    weights), so the question is only ever how high the degree can go --
    Section VII-C makes this point and measures it on real acquisitions.
    """
    directions = np.atleast_2d(np.asarray(directions, dtype=float))
    if ell == 0:
        return True
    A = _design(directions, ell).T               # (n_coeff, N)
    t = sh_integral_vector(ell)
    res = linprog(
        c=np.zeros(A.shape[1]),
        A_eq=A,
        b_eq=t,
        bounds=[(0.0, None)] * A.shape[1],
        method="highs",
    )
    if not res.success:
        return False
    return bool(np.max(np.abs(A @ res.x - t)) <= tol * max(1.0, float(np.abs(t).max())))


def exact_degree(directions: np.ndarray, l_max: int = 8, tol: float = 1e-8) -> int:
    """Equation (13): the largest even degree ``<= l_max`` that is feasible.

    Feasibility is monotone in practice but not guaranteed to be, so we scan
    downwards from ``l_max`` and return the first feasible degree.
    """
    for ell in sorted(even_degrees(l_max), reverse=True):
        if is_degree_feasible(directions, ell, tol=tol):
            return ell
    return 0


def solve_minimum_norm_weights(
    directions: np.ndarray,
    ell: int,
    tol: float = 1e-7,
    maxiter: int = 2000,
) -> tuple[np.ndarray, float]:
    """Equation (12) by its dual.  Returns ``(weights, residual)``.

    Raises
    ------
    RuntimeError
        If the constraint residual exceeds ``tol``.  A silently inexact rule
        would break the hypothesis of Theorem 2 without any visible symptom, so
        this is a hard failure rather than a warning.
    """
    directions = np.atleast_2d(np.asarray(directions, dtype=float))
    n = directions.shape[0]
    if n == 0:
        raise ValueError("no directions")

    Phi = _design(directions, ell)               # (N, K)
    t = sh_integral_vector(ell)                  # (K,)

    if ell == 0:
        # Closed form: minimum-norm nonnegative solution of sum_i w_i Y_00 = t_0
        # is uniform, w_i = 4 pi / N.
        w = np.full(n, _TOTAL_WEIGHT / n)
        resid = float(np.max(np.abs(Phi.T @ w - t)))
        return w, resid

    def neg_dual_and_grad(lam: np.ndarray) -> tuple[float, np.ndarray]:
        w = np.maximum(Phi @ lam * 0.5, 0.0)
        g = -float(w @ w) + float(lam @ t)
        grad = t - Phi.T @ w
        return -g, -grad

    lam0 = np.zeros(Phi.shape[1])
    lam0[0] = 2.0 * _TOTAL_WEIGHT / max(n, 1)
    res = minimize(
        neg_dual_and_grad,
        lam0,
        jac=True,
        method="L-BFGS-B",
        options={"maxiter": maxiter, "ftol": 1e-18, "gtol": 1e-14},
    )
    w = np.maximum(Phi @ res.x * 0.5, 0.0)

    # Active-set polish.  The dual identifies the support reliably but converges
    # only linearly in the residual; on the support the problem is an equality-
    # constrained least-norm solve with a closed form, which lands at machine
    # precision.  Indices that come back negative are dropped and the solve is
    # repeated, which terminates because the support strictly shrinks.
    support = w > max(1e-12, 1e-9 * float(w.max(initial=0.0)))
    if not support.any():
        support = np.ones(n, dtype=bool)
    for _ in range(n + 1):
        Phi_s = Phi[support]                      # (|S|, K)
        # min ||w_S|| s.t. Phi_s^T w_S = t   ->   w_S = Phi_s (Phi_s^T Phi_s)^+ t
        coef, *_ = np.linalg.lstsq(Phi_s.T @ Phi_s, t, rcond=None)
        w_s = Phi_s @ coef
        if np.all(w_s >= -1e-12):
            w = np.zeros(n)
            w[support] = np.maximum(w_s, 0.0)
            break
        drop = np.flatnonzero(support)[np.argmin(w_s)]
        support = support.copy()
        support[drop] = False
        if not support.any():
            break

    resid = float(np.max(np.abs(Phi.T @ w - t)))
    if resid > tol:
        raise RuntimeError(
            f"quadrature rule at degree {ell} did not converge: residual {resid:.3e} "
            f"> tol {tol:.3e} for {n} directions. Theorem 2 assumes an exact rule, and "
            f"an inexact one would void its hypothesis silently. Check that degree "
            f"{ell} is feasible for this direction set (see exact_degree)."
        )
    return w, resid


def build_rule(
    directions: np.ndarray,
    l_max: int = 8,
    tol: float = 1e-7,
    shape_is_spherical: bool = False,
) -> QuadratureRule:
    """Build the rule for one shell: find ``L_p`` by (13), then ``w_p`` by (12).

    ``shape_is_spherical`` marks a spherical (STE) shell.  For STE the symmetry
    axis carries no information, so by Section IV-B such a shell contributes only
    to l = 0 and is given degree 0 with uniform weights regardless of how its
    nominal directions are listed.
    """
    directions = np.atleast_2d(np.asarray(directions, dtype=float))
    norms = np.linalg.norm(directions, axis=1)
    if np.any(norms <= 0):
        raise ValueError("direction vectors must be nonzero")
    directions = directions / norms[:, None]

    if shape_is_spherical:
        n = directions.shape[0]
        w = np.full(n, _TOTAL_WEIGHT / n)
        return QuadratureRule(weights=w, degree=0, directions=directions, residual=0.0)

    degree = exact_degree(directions, l_max=l_max, tol=1e-8)
    w, resid = solve_minimum_norm_weights(directions, degree, tol=tol)
    return QuadratureRule(weights=w, degree=degree, directions=directions, residual=resid)
