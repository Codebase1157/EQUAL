"""The diffusion signal model: equations (2), (3) and (24).

Equation (2) -- the normalised signal is the Laplace transform of a probability
measure ``mu`` over diffusion tensors::

    E(B) = \\int_T exp(-<B, D>) dmu(D),
    T = { D in Sym(3) : 0 <= D <= d_fw I },     d_fw = 3.0e-3 mm^2/s.

Equation (3) -- magnitude images carry Rician noise.

Equation (24) -- for the atomic measure (21) the transform is available in
closed form::

    E_j(B) = pi_{j,0} exp(-d_fw tr B) + sum_k pi_{j,k} exp(-<B, D_{j,k}>).

This module is numpy-only: it is the reference implementation the torch decoder
is tested against, and it is what the in-silico generator uses to produce
signals from a *known* measure.
"""

from __future__ import annotations

import numpy as np
from scipy.special import i0e, ive

__all__ = [
    "D_FREE_WATER",
    "D_TISSUE_MAX",
    "TensorDistribution",
    "laplace_signal",
    "rician_pdf",
    "rician_nll",
    "sample_rician",
    "inner",
]

#: Diffusivity of free water at body temperature (mm^2/s), Section III-C.
D_FREE_WATER = 3.0e-3

#: Upper limit for the eigenvalues of a tissue atom (mm^2/s), Section IV-D.
#: The gap to ``D_FREE_WATER`` is what Theorem 5(iv) requires and what keeps the
#: free-water atom separable in practice.
D_TISSUE_MAX = 2.5e-3


def inner(B: np.ndarray, D: np.ndarray) -> np.ndarray:
    """``<B, D> = tr(B D)``, broadcasting over leading axes."""
    return np.einsum("...ij,...ij->...", B, D)


class TensorDistribution:
    """An atomic measure ``mu`` of the form (21).

    ``weights`` sums to one; ``tensors[0]`` is conventionally the free-water
    atom ``d_fw I`` when ``has_free_water`` is set, matching (21).
    """

    __slots__ = ("weights", "tensors", "has_free_water")

    def __init__(
        self,
        weights: np.ndarray,
        tensors: np.ndarray,
        has_free_water: bool = True,
    ) -> None:
        w = np.asarray(weights, dtype=float)
        D = np.asarray(tensors, dtype=float)
        if D.ndim != 3 or D.shape[1:] != (3, 3):
            raise ValueError("tensors must have shape (K, 3, 3)")
        if w.shape[0] != D.shape[0]:
            raise ValueError("weights and tensors disagree in length")
        if np.any(w < -1e-12):
            raise ValueError("weights must be nonnegative (mu is a probability measure)")
        s = w.sum()
        if not np.isclose(s, 1.0, atol=1e-8):
            raise ValueError(f"weights must sum to 1, got {s!r}")
        self.weights = np.maximum(w, 0.0)
        self.tensors = D
        self.has_free_water = has_free_water

    # -- admissibility ------------------------------------------------------
    def is_admissible(self, tol: float = 1e-9) -> bool:
        """Is every atom in ``T``, i.e. ``0 <= D <= d_fw I``?"""
        for D in self.tensors:
            if not np.allclose(D, D.T, atol=1e-10):
                return False
            ev = np.linalg.eigvalsh(D)
            if ev.min() < -tol or ev.max() > D_FREE_WATER + tol:
                return False
        return True

    # -- the Laplace transform (2)/(24) -------------------------------------
    def signal(self, B: np.ndarray) -> np.ndarray:
        """Equation (24).  ``B`` is (..., 3, 3); returns (...)."""
        B = np.asarray(B, dtype=float)
        rates = inner(B[..., None, :, :], self.tensors)      # (..., K)
        return np.einsum("...k,k->...", np.exp(-rates), self.weights)

    # -- moments, used by the readouts --------------------------------------
    def mean_tensor(self) -> np.ndarray:
        return np.einsum("k,kij->ij", self.weights, self.tensors)

    def second_moment_frobenius(self) -> float:
        """``E_mu ||D||_F^2``."""
        return float(np.einsum("k,kij,kij->", self.weights, self.tensors, self.tensors))


def laplace_signal(weights: np.ndarray, tensors: np.ndarray, B: np.ndarray) -> np.ndarray:
    """Equation (24) without building a :class:`TensorDistribution`."""
    weights = np.asarray(weights, dtype=float)
    tensors = np.asarray(tensors, dtype=float)
    B = np.asarray(B, dtype=float)
    rates = inner(B[..., None, :, :], tensors)
    return np.einsum("...k,...k->...", np.exp(-rates), np.broadcast_to(weights, rates.shape))


# -- Rician noise, equation (3) ---------------------------------------------

def rician_pdf(s: np.ndarray, nu: np.ndarray, sigma: np.ndarray) -> np.ndarray:
    """Equation (3).  Evaluated with the exponentially scaled Bessel function.

    ``p(s|nu,sigma) = s/sigma^2 exp(-(s^2+nu^2)/(2 sigma^2)) I_0(s nu / sigma^2)``
    """
    s = np.asarray(s, dtype=float)
    nu = np.asarray(nu, dtype=float)
    sigma = np.asarray(sigma, dtype=float)
    z = s * nu / sigma**2
    # i0e(z) = exp(-|z|) I_0(z), so I_0(z) = i0e(z) exp(z); folding exp(z) into
    # the Gaussian exponent keeps the whole expression finite for large z.
    expo = -(s**2 + nu**2) / (2.0 * sigma**2) + z
    return s / sigma**2 * np.exp(expo) * i0e(z)


def rician_nll(s: np.ndarray, nu: np.ndarray, sigma: np.ndarray) -> np.ndarray:
    """Equation (28), per measurement, up to terms independent of ``nu``.

    ``(s^2 + nu^2) / (2 sigma^2) - log I_0(s nu / sigma^2)``

    ``log I_0(x)`` is evaluated as ``x + log i0e(x)``, which is the stable form
    the manuscript specifies in Section IV-F.
    """
    s = np.asarray(s, dtype=float)
    nu = np.asarray(nu, dtype=float)
    sigma = np.asarray(sigma, dtype=float)
    z = s * nu / sigma**2
    log_i0 = z + np.log(np.maximum(i0e(z), 1e-300))
    return (s**2 + nu**2) / (2.0 * sigma**2) - log_i0


def sample_rician(nu: np.ndarray, sigma: float, rng: np.random.Generator) -> np.ndarray:
    """Draw magnitude measurements with Rician noise at level ``sigma``.

    A Rician magnitude is the modulus of a complex Gaussian whose mean modulus
    is ``nu``; sampling the two channels is exact and avoids inverting (3).
    """
    nu = np.asarray(nu, dtype=float)
    real = rng.normal(loc=nu, scale=sigma, size=nu.shape)
    imag = rng.normal(loc=0.0, scale=sigma, size=nu.shape)
    return np.sqrt(real**2 + imag**2)
