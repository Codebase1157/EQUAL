"""Theorem 6(ii): the extrapolation bound, equation (35).

    |h(b*)| <= 2^{1 - omega(b*)} eps^{omega(b*)},
    omega(b*) = (2/pi) arcsin(b_max / b*).

Three things about this bound are easy to misread, and the code enforces all
three:

1. **It compares two models, not a model with the truth.**  ``eps`` bounds the
   discrepancy between two EQUAL outputs on the acquired range; the bound says
   how far they may diverge beyond it.  It is not an error bound with respect to
   the true signal, which also depends on noise and model error.
2. **It is informative only while it stays below 1.**  Since every output lies
   in (0, 1], a bound of 1 or more says nothing at all.  :func:`divergence_bound`
   returns ``nan`` past the crossing point and :func:`trivial_crossing_ratio`
   gives that point, so a caller cannot accidentally plot a vacuous curve.
3. **Its interval hypothesis is stronger than any acquisition offers.**  It
   assumes ``|h| <= eps`` on the whole interval ``[0, b_max]``, whereas an
   acquisition provides finitely many shells.  A discrete-shell version would
   need an additional stability argument for exponential sums and is left open
   (Section X-C).

Verification against the manuscript
-----------------------------------
The crossing points quoted in the Section V remark and in the Fig. 5(b) caption
-- ``b*/b_max ~ 3.4, 4.9, 7.0`` for ``eps = 0.05, 0.01, 0.001`` -- are
reproduced by this formula to three significant figures (3.438, 4.901, 7.005),
which is what fixes the reading of (35).  The bound row of Table XIV does *not*
follow from it; see ``audit/audit.py``, check ``thm6_bound_row``.
"""

from __future__ import annotations

import numpy as np
from scipy.optimize import brentq

__all__ = [
    "harmonic_measure",
    "divergence_bound",
    "trivial_crossing_ratio",
    "quadrature_consistency_rate",
]


def harmonic_measure(ratio: float | np.ndarray) -> np.ndarray:
    """``omega(b*) = (2/pi) arcsin(b_max / b*)``, as a function of ``b*/b_max``.

    Equals 1 at ``ratio = 1`` and decreases towards 0 as the ratio grows.
    """
    ratio = np.asarray(ratio, dtype=float)
    if np.any(ratio < 1.0):
        raise ValueError("b*/b_max must be at least 1; the bound is for b* > b_max")
    return (2.0 / np.pi) * np.arcsin(np.clip(1.0 / ratio, -1.0, 1.0))


def divergence_bound(
    ratio: float | np.ndarray, eps: float, mask_trivial: bool = True
) -> np.ndarray:
    """Equation (35) as a function of ``b*/b_max``.

    Returns ``nan`` wherever the bound reaches 1 or more, unless
    ``mask_trivial`` is cleared: past that point the statement is weaker than
    the trivial bound ``|h| <= 1`` and the manuscript reports it only below
    that value.
    """
    if not 0 < eps < 1:
        raise ValueError("eps must lie in (0, 1)")
    w = harmonic_measure(ratio)
    out = 2.0 ** (1.0 - w) * eps**w
    if mask_trivial:
        out = np.where(out >= 1.0, np.nan, out)
    return out


def trivial_crossing_ratio(eps: float) -> float:
    """The ratio ``b*/b_max`` at which (35) reaches the trivial value 1.

    Beyond it a synthesized shell should be read as an extrapolation with no
    guarantee attached.  For ``eps = 0.05, 0.01, 0.001`` this returns
    3.438, 4.901 and 7.005, matching the values quoted in Section V and in the
    Fig. 5(b) caption.
    """
    if not 0 < eps < 1:
        raise ValueError("eps must lie in (0, 1)")
    f = lambda r: float(divergence_bound(r, eps, mask_trivial=False)) - 1.0
    if f(1.0) >= 0:
        return 1.0
    return float(brentq(f, 1.0 + 1e-12, 1e6, xtol=1e-12, rtol=1e-14))


def quadrature_consistency_rate(
    degrees: np.ndarray, discrepancy: np.ndarray
) -> dict[str, float]:
    """Fit the power law Theorem 2 predicts: ``SW_2 ~ Gamma (L)^{-r}``.

    Theorem 2 bounds the discrepancy between estimates from two direction sets
    by ``Gamma beta_F ((L_1)^{-r} + (L_2)^{-r})``, so on a log-log plot of
    discrepancy against quadrature degree the slope estimates ``-r``.

    Returns the slope, its 95% interval from the regression standard error, and
    the fitted intercept.  Section VIII-C reports a slope of -2.19 with an
    interval of [-2.31, -2.07] on noise-free in silico data, and notes that the
    same curve on real data flattens at the scan-rescan floor -- which is the
    correct behaviour, since falling below the floor would mean the model was
    reproducing its own prior rather than the data.

    Note the bound is governed by the **smallest** degree across the shells, not
    by the number of measurements (Section VII-C).
    """
    L = np.asarray(degrees, dtype=float)
    d = np.asarray(discrepancy, dtype=float)
    if L.shape != d.shape or L.ndim != 1:
        raise ValueError("degrees and discrepancy must be 1-D arrays of equal length")
    ok = (L > 0) & (d > 0)
    if ok.sum() < 3:
        raise ValueError("need at least three positive points to fit a rate")
    x = np.log(L[ok])
    y = np.log(d[ok])
    n = len(x)
    A = np.vstack([x, np.ones(n)]).T
    coef, residuals, *_ = np.linalg.lstsq(A, y, rcond=None)
    slope, intercept = float(coef[0]), float(coef[1])
    resid = y - A @ coef
    dof = max(n - 2, 1)
    s2 = float(resid @ resid) / dof
    cov = s2 * np.linalg.inv(A.T @ A)
    se = float(np.sqrt(cov[0, 0]))
    # t critical value at 95% for the given dof
    from scipy.stats import t as student_t

    crit = float(student_t.ppf(0.975, dof))
    return {
        "slope": slope,
        "ci_low": slope - crit * se,
        "ci_high": slope + crit * se,
        "intercept": intercept,
        "n_points": n,
    }
