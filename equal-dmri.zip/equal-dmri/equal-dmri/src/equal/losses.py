"""Training objective: equations (28) to (32).

    L = lambda_rec L_Rice + lambda_cons L_cons + lambda_sup L_sup           (32)

``L_Rice`` (28) scores every prediction against a **raw acquired value the
encoder has not seen**.  This is the whole content of Section III-A's objection
to grid-based self-supervision: when the target is an interpolant, part of it
can be rebuilt from measurements that are still visible, and the reported error
is agreement with the interpolant rather than prediction of an unseen
acquisition.  There is no resampling step anywhere in this file.

``L_cons`` (30) compares two thinned views of the same patch in sliced
Wasserstein distance (29).  It is computed on *measures*, not on atoms, and is
therefore invariant to relabelling -- an atom-wise penalty would not be, and
would punish the model for a symmetry it is entitled to.

``L_sup`` (31) is optional: EQUAL trains with ``lambda_sup = 0`` and uses no
fitted labels at all; EQUAL-D sets 0.5.  Reporting both is what shows whether
the readouts need labels (Table XX, "Supervision").
"""

from __future__ import annotations

import numpy as np
import torch

from .decoder import DecodedMeasure

__all__ = [
    "rician_nll_loss",
    "mandel_vector",
    "sliced_wasserstein2",
    "consistency_loss",
    "distillation_loss",
    "total_loss",
    "LossWeights",
]


def rician_nll_loss(
    pred: torch.Tensor, target: torch.Tensor, sigma: torch.Tensor
) -> torch.Tensor:
    """Equation (28), averaged over voxels and held-out measurements.

    ``(s^2 + nu^2) / (2 sigma^2) - log I_0(s nu / sigma^2)``

    ``log I_0(x)`` is evaluated as ``x + log(i0e(x))`` with the exponentially
    scaled Bessel function, which stays finite for large arguments -- the stable
    form Section IV-F specifies.  Unlike a squared error on the ADC or on the
    log-signal, (28) does not overweight the low, noise-floor-dominated signals
    that dominate at high b.

    ``pred`` and ``target`` are (V, H); ``sigma`` is (V, 1) or (V, H).
    """
    if pred.shape != target.shape:
        raise ValueError(f"shape mismatch {tuple(pred.shape)} vs {tuple(target.shape)}")
    s2 = sigma**2
    z = target * pred / s2
    # torch.special.i0e(z) = exp(-|z|) I_0(z); for z >= 0, log I_0(z) = z + log i0e(z)
    log_i0 = z + torch.log(torch.clamp(torch.special.i0e(z), min=1e-30))
    return ((target**2 + pred**2) / (2.0 * s2) - log_i0).mean()


def mandel_vector(D: torch.Tensor) -> torch.Tensor:
    """``xi(D) = (D11, D22, D33, sqrt2 D12, sqrt2 D13, sqrt2 D23)``.

    An isometry for the Frobenius norm, which is what lets the sliced
    Wasserstein distance over ``R^6`` be rotation invariant in expectation:
    ``D -> R D R^T`` acts on ``xi`` as an orthogonal map.
    """
    r2 = float(np.sqrt(2.0))
    return torch.stack(
        [
            D[..., 0, 0], D[..., 1, 1], D[..., 2, 2],
            r2 * D[..., 0, 1], r2 * D[..., 0, 2], r2 * D[..., 1, 2],
        ],
        dim=-1,
    )


def _w2_1d(
    xa: torch.Tensor, wa: torch.Tensor, xb: torch.Tensor, wb: torch.Tensor
) -> torch.Tensor:
    """Exact 1-D squared ``W_2`` between weighted atomic measures.

    Computed from sorted quantiles: the two quantile functions are step
    functions, so their common refinement is the union of the cumulative-weight
    breakpoints, and the integral is a finite sum over that partition.

    ``xa``: (..., Ka), ``wa``: (..., Ka) summing to 1 along the last axis.
    """
    xa, ia = torch.sort(xa, dim=-1)
    xb, ib = torch.sort(xb, dim=-1)
    wa = torch.gather(wa, -1, ia)
    wb = torch.gather(wb, -1, ib)

    ca = torch.cumsum(wa, dim=-1).clamp(max=1.0)
    cb = torch.cumsum(wb, dim=-1).clamp(max=1.0)
    # Common refinement of the two partitions of [0, 1].
    cuts = torch.cat([ca, cb], dim=-1)
    cuts, _ = torch.sort(cuts, dim=-1)
    zero = cuts.new_zeros(cuts.shape[:-1] + (1,))
    widths = torch.diff(cuts, dim=-1, prepend=zero).clamp(min=0.0)
    # Evaluate each quantile function at the midpoint of every cell.
    mid = cuts - widths * 0.5
    ja = torch.searchsorted(ca.contiguous(), mid.contiguous()).clamp(max=xa.shape[-1] - 1)
    jb = torch.searchsorted(cb.contiguous(), mid.contiguous()).clamp(max=xb.shape[-1] - 1)
    qa = torch.gather(xa, -1, ja)
    qb = torch.gather(xb, -1, jb)
    return (widths * (qa - qb) ** 2).sum(-1)


def sliced_wasserstein2(
    mu: DecodedMeasure,
    nu: DecodedMeasure,
    n_projections: int = 64,
    generator: torch.Generator | None = None,
) -> torch.Tensor:
    """Equation (29): ``SW_2^2(mu, mu')`` per voxel.

    Tensors are mapped to ``R^6`` by the Mandel vector and projected onto
    ``N_u`` directions drawn uniformly from ``S^5``; each one-dimensional
    ``W_2`` is computed exactly from sorted quantiles.

    With uniformly drawn projections this is rotation invariant in expectation,
    because ``D -> R D R^T`` acts orthogonally on ``xi``.
    """
    xa = mandel_vector(mu.tensors)                       # (V, Ka, 6)
    xb = mandel_vector(nu.tensors)                       # (V, Kb, 6)
    u = torch.randn(n_projections, 6, device=xa.device, dtype=xa.dtype,
                    generator=generator)
    u = u / u.norm(dim=-1, keepdim=True)
    pa = torch.einsum("vkd,nd->vnk", xa, u)
    pb = torch.einsum("vkd,nd->vnk", xb, u)
    wa = mu.weights.unsqueeze(1).expand(-1, n_projections, -1)
    wb = nu.weights.unsqueeze(1).expand(-1, n_projections, -1)
    return _w2_1d(pa, wa, pb, wb).mean(dim=-1)


def consistency_loss(
    mu1: DecodedMeasure, mu2: DecodedMeasure, n_projections: int = 64,
    generator: torch.Generator | None = None,
) -> torch.Tensor:
    """Equation (30): the mean over voxels of (29)."""
    return sliced_wasserstein2(mu1, mu2, n_projections, generator).mean()


def distillation_loss(
    fw_pred: torch.Tensor,
    fw_ref: torch.Tensor,
    fod_pred: torch.Tensor,
    fod_ref: torch.Tensor,
) -> torch.Tensor:
    """Equation (31): ``(f^FW - f~^FW)^2 + (1 - ACC(o, o~))``.

    Both coefficient sets must already be apodized the same way, as Section
    IV-F requires; ``equal.readouts.fod_coefficients`` applies the apodization
    by default, so reference maps must be passed through the same function.
    """
    from .readouts import angular_correlation

    acc = angular_correlation(fod_pred, fod_ref)
    return ((fw_pred - fw_ref) ** 2).mean() + (1.0 - acc).mean()


class LossWeights:
    """``lambda_rec``, ``lambda_cons``, ``lambda_sup`` of equation (32).

    Section IV-F: ``lambda_rec = 1`` and ``lambda_cons = 0.1`` throughout;
    EQUAL uses ``lambda_sup = 0`` and EQUAL-D uses 0.5.
    """

    __slots__ = ("rec", "cons", "sup")

    def __init__(self, rec: float = 1.0, cons: float = 0.1, sup: float = 0.0):
        self.rec, self.cons, self.sup = float(rec), float(cons), float(sup)

    def __repr__(self) -> str:
        return f"LossWeights(rec={self.rec}, cons={self.cons}, sup={self.sup})"


def total_loss(
    l_rice: torch.Tensor,
    l_cons: torch.Tensor,
    l_sup: torch.Tensor | None,
    weights: LossWeights,
) -> torch.Tensor:
    """Equation (32)."""
    out = weights.rec * l_rice + weights.cons * l_cons
    if l_sup is not None and weights.sup > 0:
        out = out + weights.sup * l_sup
    return out
