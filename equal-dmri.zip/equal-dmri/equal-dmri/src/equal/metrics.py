"""Evaluation metrics: equations (36) to (39).

Every signal-prediction number in this repository is scored against **raw
acquired measurements**, never against a resampled reference.  The two are not
comparable, and Section VIII-B measures the difference: that is what
:func:`optimism_gap` is for.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

__all__ = [
    "nrmse",
    "optimism_gap",
    "equivariance_error",
    "violation_rate",
    "ViolationReport",
    "validity_test_set",
]


def nrmse(pred: np.ndarray, target: np.ndarray, mask: np.ndarray | None = None) -> float:
    """Equation (36): normalised root-mean-square error over held-out measurements.

        NRMSE = sqrt( sum_{j,i in H} (nu_ij - s_ij)^2 / sum_{j,i in H} s_ij^2 )

    ``mask`` selects the held-out entries when ``pred``/``target`` are full
    arrays.  Computed separately in white matter, grey matter and CSF by the
    caller.
    """
    pred = np.asarray(pred, dtype=float)
    target = np.asarray(target, dtype=float)
    if pred.shape != target.shape:
        raise ValueError(f"shape mismatch {pred.shape} vs {target.shape}")
    if mask is not None:
        pred, target = pred[mask], target[mask]
    if target.size == 0:
        raise ValueError("no held-out measurements to score")
    den = float(np.sum(target**2))
    if den <= 0:
        raise ValueError("target energy is zero")
    return float(np.sqrt(np.sum((pred - target) ** 2) / den))


def optimism_gap(nrmse_raw: float, nrmse_grid: float) -> float:
    """Equation (37): ``G_opt = NRMSE_raw - NRMSE_grid``.

    Positive means a model's error against its own resampled reference
    understates its error against acquisitions.

    **A positive gap is not by itself evidence of leakage.**  Interpolation also
    smooths noise, so a gap is expected even for a model that cheats in no way
    at all.  Section VI-C.1 requires an oracle control -- the same gap computed
    for a predictor that returns the noise-free signal -- and H1 is the
    inequality ``G_opt > G_opt^0``.  Use :func:`leakage_decomposition`.
    """
    return float(nrmse_raw) - float(nrmse_grid)


def leakage_decomposition(gap: float, oracle_gap: float) -> dict[str, float]:
    """Split an optimism gap into smoothing and leakage, per Section VIII-B.

    Returns the two parts and the share of the gap each accounts for.  The
    oracle gap is the part interpolation smoothing alone produces; the remainder
    is the contribution of masked targets built partly from measurements the
    encoder could still see.
    """
    gap = float(gap)
    oracle_gap = float(oracle_gap)
    if gap <= 0:
        raise ValueError("optimism gap must be positive to decompose")
    leak = gap - oracle_gap
    return {
        "gap": gap,
        "smoothing": oracle_gap,
        "leakage": leak,
        "smoothing_share": oracle_gap / gap,
        "leakage_share": leak / gap,
        "ratio": gap / oracle_gap if oracle_gap > 0 else float("inf"),
    }


def equivariance_error(
    rotated_output: np.ndarray, transformed_output: np.ndarray
) -> float:
    """Equation (38).

        eps_eq = E_R || F(R.X) - R * F(X) ||_2  /  || F(X) ||_2

    ``F`` is read as the vector of FOD coefficients or of predicted signals.
    For an architecturally equivariant model this is floating-point round-off
    and should be reported as a numerical quantity, not as a model error
    (Section VII, last paragraph).
    """
    a = np.asarray(rotated_output, dtype=float)
    b = np.asarray(transformed_output, dtype=float)
    if a.shape != b.shape:
        raise ValueError(f"shape mismatch {a.shape} vs {b.shape}")
    den = float(np.linalg.norm(b))
    if den <= 0:
        raise ValueError("reference output has zero norm")
    return float(np.linalg.norm(a - b) / den)


@dataclass(frozen=True)
class ViolationReport:
    """Breakdown of equation (39) by the condition that failed."""

    rate: float
    n_voxels: int
    n_violating: int
    boundedness: int
    monotonicity: int
    convexity: int

    def __str__(self) -> str:
        return (
            f"V_rate = {self.rate:.4%} ({self.n_violating}/{self.n_voxels}); "
            f"bounds {self.boundedness}, monotonicity {self.monotonicity}, "
            f"convexity {self.convexity}"
        )


def validity_test_set(
    n_lte: int = 64, n_pte: int = 64, n_b: int = 200, b_max: float = 2.0e4, seed: int = 0
) -> tuple[np.ndarray, np.ndarray]:
    """The set ``G`` and b-grid of Section VI-C.3.

    64 LTE directions, 64 PTE axes and the STE shape, with 200 b-values in
    ``(0, 2e4]``.  Returns ``(unit_trace_B, b_grid)`` where ``unit_trace_B`` has
    shape (n_lte + n_pte + 1, 3, 3) and each entry has unit trace, so the signal
    along an encoding is ``E(b * B)``.
    """
    from .data.protocols import b_tensor, electrostatic_directions

    g_lte = electrostatic_directions(n_lte, seed=seed)
    g_pte = electrostatic_directions(n_pte, seed=seed + 1)
    Bs = [b_tensor(1.0, g, 1.0) for g in g_lte]
    Bs += [b_tensor(1.0, g, -0.5) for g in g_pte]
    Bs.append(b_tensor(1.0, np.array([0.0, 0.0, 1.0]), 0.0))
    b_grid = np.linspace(b_max / n_b, b_max, n_b)
    return np.stack(Bs), b_grid


def violation_rate(
    signal_fn,
    n_voxels: int,
    unit_B: np.ndarray | None = None,
    b_grid: np.ndarray | None = None,
    tol: float = 1e-9,
) -> ViolationReport:
    """Equation (39): the share of voxels failing validity anywhere on ``G``.

        C_j :  exists B in G, b  with  E_j(bB) not in (0, 1],
               or  Delta_b E_j > 0,  or  Delta_b^2 E_j < 0

    Complete monotonicity cannot be verified numerically, so this tests
    boundedness and the **first two orders** only, exactly as Section VI-C.3
    states.  For EQUAL the result is zero by construction (Theorem 4); it is
    measured to confirm the implementation matches the theory, and for the
    baselines it is an empirical quantity.

    Parameters
    ----------
    signal_fn : callable
        ``signal_fn(B_stack) -> (n_voxels, n_B)`` evaluating the model's signal
        at a stack of b-tensors.
    """
    if unit_B is None or b_grid is None:
        unit_B, b_grid = validity_test_set()
    n_enc = unit_B.shape[0]
    n_b = len(b_grid)

    # Evaluate on the full (encoding, b) grid.
    stack = (b_grid[:, None, None, None] * unit_B[None, :, :, :]).reshape(-1, 3, 3)
    E = np.asarray(signal_fn(stack), dtype=float).reshape(n_voxels, n_b, n_enc)

    bad_bound = np.any((E <= 0.0 - tol) | (E > 1.0 + tol), axis=(1, 2))
    d1 = np.diff(E, axis=1)
    bad_mono = np.any(d1 > tol, axis=(1, 2))
    d2 = np.diff(E, n=2, axis=1)
    bad_conv = np.any(d2 < -tol, axis=(1, 2))

    bad = bad_bound | bad_mono | bad_conv
    return ViolationReport(
        rate=float(bad.mean()),
        n_voxels=int(n_voxels),
        n_violating=int(bad.sum()),
        boundedness=int(bad_bound.sum()),
        monotonicity=int(bad_mono.sum()),
        convexity=int(bad_conv.sum()),
    )
