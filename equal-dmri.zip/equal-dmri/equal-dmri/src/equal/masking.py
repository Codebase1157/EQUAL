"""The masking distribution ``M`` of Section IV-F, and the measurement set (5).

Three operations, drawn with probabilities 0.6 / 0.3 / 0.1:

(a) **direction masking** -- remove a fraction ``zeta ~ U(0.1, 0.7)`` of the
    directions of each shell, keeping at least six per shell;
(b) **shell hold-out** -- remove one complete nonzero shell when ``P(A) >= 2``;
(c) **encoding hold-out** -- remove every measurement of one b-tensor shape when
    more than one shape is present.

The mass of an unavailable operation moves to (a).

Two properties matter and are enforced here rather than left to the caller:

* The **same mask is applied to every voxel of a patch**, so the observed subset
  ``X_O`` is a smaller but complete protocol in its own right.
* The **quadrature weights are recomputed for the observed directions**.  This
  is the step that distinguishes (9) from grid-token masking: the weights always
  describe the directions actually present, including after masking.

The held-out targets are the acquired signals themselves.  Nothing is
interpolated at any stage, so a masked target can never be built from a
measurement the encoder can still see -- which is the leakage that Section
VIII-B measures in grid-based self-supervision.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .data.protocols import Protocol, Shell

__all__ = ["MaskOutcome", "MaskingDistribution", "apply_mask"]

MIN_DIRECTIONS_PER_SHELL = 6


@dataclass(frozen=True)
class MaskOutcome:
    """Which measurements are observed and which are held out.

    ``observed`` and `held_out` index into the flattened measurement list of
    the protocol, i.e. the order of ``Protocol.b_tensors()``.
    """

    observed: np.ndarray
    held_out: np.ndarray
    operation: str

    def __post_init__(self) -> None:
        if np.intersect1d(self.observed, self.held_out).size:
            raise ValueError("observed and held-out sets overlap: the target would leak")


class MaskingDistribution:
    """``M`` of Section IV-F."""

    def __init__(
        self,
        p_direction: float = 0.6,
        p_shell: float = 0.3,
        p_encoding: float = 0.1,
        zeta_range: tuple[float, float] = (0.1, 0.7),
        min_per_shell: int = MIN_DIRECTIONS_PER_SHELL,
        operations: tuple[str, ...] = ("a", "b", "c"),
    ):
        total = p_direction + p_shell + p_encoding
        if not np.isclose(total, 1.0):
            raise ValueError(f"masking probabilities must sum to 1, got {total}")
        self.p = {"a": p_direction, "b": p_shell, "c": p_encoding}
        self.zeta_range = zeta_range
        self.min_per_shell = min_per_shell
        self.operations = operations

    def _available(self, protocol: Protocol) -> dict[str, float]:
        """Probabilities after moving the mass of unavailable operations to (a)."""
        p = {k: (self.p[k] if k in self.operations else 0.0) for k in ("a", "b", "c")}
        if protocol.n_shells < 2:
            p["a"] += p["b"]
            p["b"] = 0.0
        if len(protocol.shapes_present()) < 2:
            p["a"] += p["c"]
            p["c"] = 0.0
        s = sum(p.values())
        if s <= 0:
            raise ValueError("no masking operation is available for this protocol")
        return {k: v / s for k, v in p.items()}

    def draw(self, protocol: Protocol, rng: np.random.Generator) -> MaskOutcome:
        """Draw one mask for a patch."""
        p = self._available(protocol)
        op = rng.choice(["a", "b", "c"], p=[p["a"], p["b"], p["c"]])

        starts, n_per = [], []
        cursor = 0
        for s in protocol.shells:
            starts.append(cursor)
            n_per.append(s.n_directions)
            cursor += s.n_directions
        held: list[int] = []

        if op == "a":
            zeta = rng.uniform(*self.zeta_range)
            for idx, shell in enumerate(protocol.shells):
                if shell.is_b0:
                    continue
                n = n_per[idx]
                n_hide = int(round(zeta * n))
                n_hide = min(n_hide, max(n - self.min_per_shell, 0))
                if n_hide <= 0:
                    continue
                pick = rng.choice(n, size=n_hide, replace=False)
                held.extend(starts[idx] + pick)
        elif op == "b":
            nz = [i for i, s in enumerate(protocol.shells) if not s.is_b0]
            idx = int(rng.choice(nz))
            held.extend(range(starts[idx], starts[idx] + n_per[idx]))
        else:
            shapes = sorted(protocol.shapes_present())
            shape = str(rng.choice(shapes))
            for idx, shell in enumerate(protocol.shells):
                if shell.is_b0 or shell.shape != shape:
                    continue
                held.extend(range(starts[idx], starts[idx] + n_per[idx]))

        held_arr = np.unique(np.asarray(held, dtype=int))
        all_idx = np.arange(protocol.n_measurements)
        obs = np.setdiff1d(all_idx, held_arr)
        if obs.size == 0:
            raise ValueError("mask removed every measurement")
        return MaskOutcome(observed=obs, held_out=held_arr, operation=str(op))


def apply_mask(protocol: Protocol, outcome: MaskOutcome) -> Protocol:
    """Build the observed sub-protocol ``A_O``.

    The result is a complete protocol in its own right: shells that lose every
    direction disappear, and the rest carry only the directions that survived.
    Quadrature weights are **not** carried over -- the caller rebuilds them from
    this protocol, which is what guarantees they describe the observed set.
    """
    keep = set(int(i) for i in outcome.observed)
    shells: list[Shell] = []
    cursor = 0
    for s in protocol.shells:
        idx = [i for i in range(s.n_directions) if (cursor + i) in keep]
        cursor += s.n_directions
        if not idx:
            continue
        shells.append(Shell(s.b, s.shape, s.directions[idx]))
    if not shells:
        raise ValueError("observed protocol is empty")
    return Protocol(shells, name=f"{protocol.name}|obs")
