"""The single results store, with provenance on every value.

Audit Section 13 ("Data provenance and target construction", P0, **Fail**):
*the manuscript nowhere labels its illustrative values*.  Audit Section 2
("Numerical consistency", P0, **Fail**): *Section VIII-IX values are
illustrative, not measured*.

This module makes that distinction structural rather than editorial.  A bare
float cannot be stored: every value is a :class:`Value` carrying a
:class:`Provenance`, and :func:`ResultStore.set` rejects anything else.  So the
question "where did this number come from?" always has an answer, and
``audit.py`` can refuse to build a submission-ready artefact while any headline
number is still ``ILLUSTRATIVE``.

The provenance levels
---------------------
``ILLUSTRATIVE``
    A placeholder. **Not measured.**  It is a stand-in that keeps the pipeline
    runnable before the experiments exist.  Every value transcribed from the
    present draft of Sections VIII-IX is this.
``MEASURED``
    Produced by running the pipeline on data, with a recorded script, commit and
    date.
``DERIVED``
    Computed from other stored values by a stated formula; it inherits the
    weakest provenance of its inputs, which :meth:`ResultStore.set_derived`
    enforces so a derived number can never look firmer than its sources.
``THEORETICAL``
    Follows from a theorem with no data involved, such as the Theorem 6(ii)
    bound or the identically-zero violation rate of Theorem 4.
``EXTERNAL``
    Quoted from a published source, with a citation.

Because everything in the paper is generated from this one file, replacing an
illustrative value with a measured one regenerates every table, figure and
sentence that uses it -- which is the mechanism the audit's route to a
submittable paper (step 2) relies on.
"""

from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass, field
from datetime import date
from enum import Enum
from pathlib import Path
from typing import Any, Iterator

__all__ = [
    "Provenance",
    "Value",
    "ResultStore",
    "illustrative",
    "measured",
    "theoretical",
    "external",
]


class Provenance(str, Enum):
    ILLUSTRATIVE = "illustrative"
    MEASURED = "measured"
    DERIVED = "derived"
    THEORETICAL = "theoretical"
    EXTERNAL = "external"

    @property
    def is_evidence(self) -> bool:
        """Can this value support a claim about what EQUAL achieves?"""
        return self in (Provenance.MEASURED, Provenance.DERIVED, Provenance.THEORETICAL)


#: Ordering from weakest to strongest, used when a derived value inherits.
_STRENGTH = {
    Provenance.ILLUSTRATIVE: 0,
    Provenance.EXTERNAL: 1,
    Provenance.DERIVED: 2,
    Provenance.THEORETICAL: 3,
    Provenance.MEASURED: 3,
}


def _git_commit() -> str | None:
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True, timeout=5, check=False,
        )
        return out.stdout.strip() or None
    except Exception:
        return None


@dataclass(frozen=True)
class Value:
    """One number, with where it came from."""

    value: float | int | str | None
    provenance: Provenance
    note: str = ""
    unit_of_analysis: str | None = None
    n_units: int | None = None
    script: str | None = None
    commit: str | None = None
    recorded: str = field(default_factory=lambda: date.today().isoformat())
    citation: str | None = None
    ci: tuple[float, float] | None = None

    def __post_init__(self) -> None:
        if self.provenance is Provenance.MEASURED and not self.script:
            raise ValueError(
                "a MEASURED value must name the script that produced it; "
                "otherwise it cannot be reproduced or re-derived"
            )
        if self.provenance is Provenance.EXTERNAL and not self.citation:
            raise ValueError("an EXTERNAL value must carry a citation")
        if self.provenance is Provenance.ILLUSTRATIVE and not self.note:
            raise ValueError(
                "an ILLUSTRATIVE value must say what it is a placeholder for, "
                "so a reader can tell what running the experiment would replace"
            )

    @property
    def is_placeholder(self) -> bool:
        return self.provenance is Provenance.ILLUSTRATIVE

    def to_dict(self) -> dict[str, Any]:
        d = {
            "value": self.value,
            "provenance": self.provenance.value,
            "note": self.note,
            "recorded": self.recorded,
        }
        for k in ("unit_of_analysis", "n_units", "script", "commit", "citation"):
            v = getattr(self, k)
            if v is not None:
                d[k] = v
        if self.ci is not None:
            d["ci"] = list(self.ci)
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Value":
        d = dict(d)
        d["provenance"] = Provenance(d["provenance"])
        if "ci" in d and d["ci"] is not None:
            d["ci"] = tuple(d["ci"])
        return cls(**d)

    def __str__(self) -> str:
        tag = "" if self.provenance.is_evidence else f"  [{self.provenance.value.upper()}]"
        return f"{self.value}{tag}"


# -- convenience constructors ------------------------------------------------

def illustrative(value, note: str, **kw) -> Value:
    """A placeholder.  ``note`` must say what measuring it would replace."""
    return Value(value, Provenance.ILLUSTRATIVE, note=note, **kw)


def measured(value, script: str, unit_of_analysis: str | None = None,
             n_units: int | None = None, **kw) -> Value:
    return Value(value, Provenance.MEASURED, script=script,
                 unit_of_analysis=unit_of_analysis, n_units=n_units,
                 commit=kw.pop("commit", _git_commit()), **kw)


def theoretical(value, note: str, **kw) -> Value:
    return Value(value, Provenance.THEORETICAL, note=note, **kw)


def external(value, citation: str, note: str = "", **kw) -> Value:
    return Value(value, Provenance.EXTERNAL, citation=citation, note=note, **kw)


class ResultStore:
    """Every number the paper reports, in one place.

    Keys are dotted paths, e.g. ``table9.EQUAL.white_matter``.  The store
    refuses bare floats, so a value can never enter without a provenance.
    """

    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else None
        self._data: dict[str, Value] = {}
        self._meta: dict[str, Any] = {}
        if self.path and self.path.exists():
            self.load()

    # -- access ---------------------------------------------------------
    def set(self, key: str, value: Value) -> None:
        if not isinstance(value, Value):
            raise TypeError(
                f"{key!r}: the result store takes Value objects, not bare "
                f"{type(value).__name__}. Wrap it with illustrative(), measured(), "
                f"theoretical() or external() so its provenance is recorded."
            )
        self._data[key] = value

    def set_derived(self, key: str, value, sources: list[str], note: str) -> None:
        """Store a value computed from other stored values.

        The result inherits the **weakest** provenance among its sources, so a
        ratio of two illustrative numbers cannot present itself as derived
        evidence.
        """
        missing = [s for s in sources if s not in self._data]
        if missing:
            raise KeyError(f"{key!r}: unknown source(s) {missing}")
        weakest = min((self._data[s].provenance for s in sources), key=lambda p: _STRENGTH[p])
        prov = Provenance.DERIVED if _STRENGTH[weakest] >= _STRENGTH[Provenance.DERIVED] else weakest
        full = f"{note} (from {', '.join(sources)})"
        if prov is Provenance.ILLUSTRATIVE:
            self._data[key] = illustrative(value, note=full)
        else:
            self._data[key] = Value(value, prov, note=full)

    def get(self, key: str) -> Value:
        if key not in self._data:
            raise KeyError(f"no such result: {key!r}")
        return self._data[key]

    def value_of(self, key: str):
        return self.get(key).value

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def __len__(self) -> int:
        return len(self._data)

    def __iter__(self) -> Iterator[tuple[str, Value]]:
        return iter(sorted(self._data.items()))

    def keys(self, prefix: str = "") -> list[str]:
        return sorted(k for k in self._data if k.startswith(prefix))

    # -- provenance queries ----------------------------------------------
    def placeholders(self, prefix: str = "") -> list[str]:
        """Every key still holding an illustrative value."""
        return sorted(k for k, v in self._data.items()
                      if k.startswith(prefix) and v.is_placeholder)

    def provenance_summary(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for v in self._data.values():
            out[v.provenance.value] = out.get(v.provenance.value, 0) + 1
        return dict(sorted(out.items()))

    def is_submittable(self, prefix: str = "") -> tuple[bool, list[str]]:
        """Can results under ``prefix`` support a submission?

        False while any of them is illustrative.  This is the programmatic form
        of the audit's verdict that one fact blocks 14 of 17 applicable
        sections: EQUAL has not been implemented, trained or run, so the
        quantitative results are placeholders.
        """
        ph = self.placeholders(prefix)
        return (not ph), ph

    # -- persistence ------------------------------------------------------
    def load(self, path: str | Path | None = None) -> "ResultStore":
        p = Path(path) if path else self.path
        if p is None:
            raise ValueError("no path given")
        raw = json.loads(p.read_text())
        self._meta = raw.get("_meta", {})
        self._data = {k: Value.from_dict(v) for k, v in raw.items() if k != "_meta"}
        return self

    def save(self, path: str | Path | None = None) -> Path:
        p = Path(path) if path else self.path
        if p is None:
            raise ValueError("no path given")
        p.parent.mkdir(parents=True, exist_ok=True)
        payload: dict[str, Any] = {"_meta": {
            **self._meta,
            "written": date.today().isoformat(),
            "commit": _git_commit(),
            "provenance_summary": self.provenance_summary(),
            "n_placeholders": len(self.placeholders()),
        }}
        for k, v in sorted(self._data.items()):
            payload[k] = v.to_dict()
        p.write_text(json.dumps(payload, indent=2) + "\n")
        return p

    # -- reporting --------------------------------------------------------
    def format_value(self, key: str, fmt: str = "{:.4f}", mark: bool = True) -> str:
        """Render a value for a table, marking placeholders.

        ``mark`` adds a dagger to any illustrative value.  The audit leaves the
        decision to label in the *manuscript* to the authors; in generated
        output the default is to label, because an unlabelled placeholder in a
        table is indistinguishable from a measurement.
        """
        v = self.get(key)
        s = fmt.format(v.value) if isinstance(v.value, (int, float)) else str(v.value)
        return f"{s}†" if (mark and v.is_placeholder) else s
