# What this repository does and does not establish

This file answers one question directly: **what, of the pre-submission audit, does
this code close, and what does it not?**

## The fact that governs everything else

The audit's verdict is that *one fact blocks 14 of the 17 applicable sections:
EQUAL has not been implemented, trained or run.* This repository closes the
first of those four verbs and makes the other three executable. It does **not**
close them: no model has been trained on real data here, and

> **every quantitative value in Sections VIII–IX remains an illustrative
> placeholder.** They are stored in `results/results.json` labelled
> `provenance: illustrative`, they are marked with a dagger in every generated
> table, and `audit.py --strict` fails while any of them remain.

Nothing in this repository should be read as reproducing or supporting the
manuscript's reported numbers.

## Status by audit section

| # | Audit area | Audit verdict | What this repo changes | Now |
| --- | --- | --- | --- | --- |
| 1 | Equation-to-code verification | P0 **Fail** — only (12), (13), (26) have code | All 39 equations implemented; `docs/EQUATION_TO_CODE.md` maps each to its code and test; 83 tests | **closed for the code half**; the unit-test-as-you-go record still has to accompany a real training run |
| 2 | Numerical consistency | P0 **Fail** — values illustrative | Single generated store; `audit.py` recomputes every margin, gap and ablation change and **fails the build** on drift. Two genuine inconsistencies found (below) | gate in place; values still illustrative |
| 3 | Data splits and overlap | P0 **Fail** — no manifests, placeholder exclusion count | `data/splits.py` writes subject-level manifests with a hard overlap check and fingerprinting; HCP-YA eligibility is an arithmetic identity that a placeholder cannot satisfy | **manifest machinery closed**; real subject ids and the verified exclusion count still needed |
| 4 | Calibration protocol | P0 Not verified | Tiers (τ_r, 2τ_r), Wilson intervals and the ordinal-AUC treatment implemented | runnable; needs data |
| 5 | Guarantee vs. endpoint | P0 **Fail** — title overstates | `theorem2_scope` check enforces that only the direction axis is marked as covered by Theorem 2 | code-side closed; **title and the independent proof check are not code** |
| 6 | Fair baselines | P1 Not verified | `baselines/` implements the model-based group and `applicable_baselines()` records why each method can or cannot run on a protocol | partial — deep baselines run from authors' code by design |
| 7 | Ablation isolation | P1 Not verified | One config per ablation; `audit.py` checks every change equals the difference from the reference | runnable; needs runs |
| 8 | Uncertainty and statistical unit | P0 Not verified | `stats.py` enforces the unit of analysis, averages seeds before testing, resamples pairs as pairs, refuses p-values for spatial blocks | **closed**; needs data to apply |
| 9 | Reproducibility package | P0 **Fail** — no code, weights, manifests | This repository, plus `docs/REPRODUCIBILITY.md` | **code closed**; weights, per-case predictions and a persistent identifier outstanding |
| 10 | Real-world claim validation | P1 Not verified | — | needs runs |
| 11 | Qualitative and failure analysis | P1 Not verified | `insilico.violating_field()` builds data that leaves the model class, for Table XXI | runnable; needs runs |
| 12 | Abstract/conclusion alignment | P1 **Fail** — Contribution 4 and title overstate | `single_baseline_claims` check requires the 30.5 % margin to record QTI as its only comparator | code-side closed; **the wording is not code** |
| 13 | Data provenance | P0 **Fail** — nothing labelled | Provenance is structural: a bare float cannot enter the store, derived values inherit the weakest provenance of their inputs | **closed for generated output**; the manuscript wording is the authors' call |
| 14 | Temporal integrity | N/A | — | N/A |
| 15 | Causal identification | N/A | — | N/A |
| 16 | Threat model | P0 cond. Not verified | — | no claim made |
| 17 | Explanation faithfulness | N/A | — | N/A |
| 18 | Sensitivity | P1 Not verified | Search space in configs; `radial_rank` exposes a choice the manuscript leaves open | partial |
| 19 | System accounting | P1 Not verified | Parameter count reported; runtime/memory need a real run | partial |
| 20 | Conditional reliability | P0 cond. Not verified | Flag calibration, F1 per class, false-confident rate with Wilson intervals | runnable; needs data |

## Two inconsistencies this implementation found

Both are the defect class the audit already caught once ("summary values did not
match their own data … now computed rather than typed"), and both fail the build.

**1. Table XIV's Theorem 6(ii) bound row does not follow from equation (35).**
The formula is confirmed by the crossing points quoted in Section V and the
Fig. 5(b) caption (3.4 / 4.9 / 7.0 → 3.438 / 4.901 / 7.005). But at ε = 0.01 it
gives 0.171 / 0.342 / 0.636 / 0.853 where the table prints
0.071 / 0.134 / 0.309 / 0.561. Not a constant factor, so not a scaling slip. The
qualitative claim survives: the measured divergence stays inside the bound on
either reading. Only the stated slack changes.

**2. Table XI names the wrong comparator on CDMD.** It gives PIGMENT (0.0929) as
the best applicable baseline and reports 22.1 %. SHARD reaches 0.0914 on CDMD,
and Table X's own gain row reports 20.8 % for that source against SHARD. The
abstract carries 22.1 % with the phrase *"each against the baselines that can
process it"* — which is the clause that fails. Every other margin in both tables
is internally consistent.

## What this repository cannot do

- **It cannot make the numbers real.** Only running the experiments does that.
- **It cannot settle the title.** Dropping "Provably" is a wording decision.
- **It cannot settle Contribution 4's claim** that the tensor-valued data are
  data "that no competing model can represent". QTI represents them. The code
  records that fact; the sentence is the authors'.
- **It cannot substitute for a second mathematician** reading the proofs in
  S-I to S-VII (audit Section 5).
- **It cannot confirm the CDMD and ISMRM 2015 licences** (audit Section 13).
- **It does not reimplement the deep baselines.** UPER, D-RoPE, PIGMENT and the
  equivariant networks are run from their authors' public code, as Section VI-B
  states. Reimplementing them would make the comparison a comparison with our
  reimplementation.

## The route from here

Following the audit's own ordering:

1. Train on real data (`scripts/train.py` with `--data`), recording the
   equation-to-code map and unit tests as you go — `docs/EQUATION_TO_CODE.md`
   and `tests/` are the start of that record.
2. Run the experiments and replace the illustrative values
   (`scripts/evaluate.py --write-results`). Everything regenerates.
3. Write the real split manifests (`scripts/make_splits.py --subject-ids …`) and
   set `verified_against_release=True` once the exclusion count is re-derived.
4. Archive a release with a persistent identifier (`docs/REPRODUCIBILITY.md`).
5. Settle the title, the 30.5 % comparison, and the two findings above.
6. `python audit/audit.py --strict` must exit 0 before submission.
