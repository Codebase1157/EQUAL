# EQUAL - generated tables

Generated from `results.json` (320 values).
Provenance: {'external': 18, 'illustrative': 289, 'theoretical': 13}.

> **289 of these values are illustrative placeholders.** EQUAL has not been trained or run, so no quantitative claim below is supported by evidence yet. Placeholders are marked with a dagger. Running the experiments and re-saving the store regenerates every table here.
### Table IX - Signal prediction on HCP-YA at 30% direction masking

NRMSE against raw held-out measurements. Unit of analysis: the subject (94 test subjects).

| Method | White matter | Gray matter | CSF |
| --- | --- | --- | --- |
| SH_interp | 0.0731† | 0.0788† | 0.1216† |
| MAP_MRI | 0.0694† | 0.0742† | 0.1147† |
| SHARD | 0.0652† | 0.0699† | 0.1082† |
| SH_CNN | 0.0598† | 0.0651† | 0.1016† |
| SH_sCNN | 0.0621† | 0.0668† | 0.1043† |
| S_CNN | 0.0607† | 0.0659† | 0.1024† |
| E3xSO3 | 0.0583† | 0.0634† | 0.0987† |
| UPER | 0.0574† | 0.0628† | 0.0971† |
| D_RoPE | 0.0566† | 0.0619† | 0.0958† |
| PIGMENT | 0.0559† | 0.0611† | 0.0944† |
| EQUAL | 0.0497† | 0.0548† | 0.0863† |
| EQUAL_D | 0.0491† | 0.0541† | 0.0857† |

### Table X - White-matter NRMSE across the eight evaluation sources

"n/a" is **not** a missing measurement: it marks a method that cannot represent the input at all.

| Method | HCP_YA | MASiVar_A | MASiVar_P | ON_Harmony | CDMD | tensor_valued | in_silico |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  | *in-dist.* | *in-dist.* | *shifted* | *zero-shot* | *zero-shot* | *zero-shot* | *held-out* |
| SH_interp | 0.0731† | 0.0812† | 0.0867† | 0.0784† | 0.1104† | n/a | 0.0693† |
| MAP_MRI | 0.0694† | 0.0775† | 0.0831† | 0.0748† | 0.0968† | n/a | 0.0651† |
| SHARD | 0.0652† | 0.0731† | 0.0788† | 0.0709† | 0.0914† | n/a | 0.0612† |
| SH_CNN | 0.0598† | 0.0719† | 0.0864† | 0.0772† | n/a | n/a | 0.0587† |
| SH_sCNN | 0.0621† | 0.0724† | 0.0813† | 0.0741† | 0.1021† | n/a | 0.0601† |
| S_CNN | 0.0607† | 0.0708† | 0.0796† | 0.0726† | 0.0994† | n/a | 0.0589† |
| E3xSO3 | 0.0583† | 0.0681† | 0.0749† | 0.0693† | 0.0947† | n/a | 0.0564† |
| UPER | 0.0574† | 0.0673† | 0.0781† | 0.0718† | 0.1086† | n/a | 0.0558† |
| D_RoPE | 0.0566† | 0.0664† | 0.0763† | 0.0702† | 0.1037† | n/a | 0.0549† |
| PIGMENT | 0.0559† | 0.0652† | 0.0734† | 0.0681† | 0.0929† | n/a | 0.0541† |
| EQUAL | 0.0497† | 0.0571† | 0.0608† | 0.0563† | 0.0724† | 0.0612† | 0.0452† |
| EQUAL_D | 0.0491† | 0.0566† | 0.0604† | 0.0559† | 0.0719† | 0.0608† | 0.0449† |
| QTI | n/a | n/a | n/a | n/a | n/a | 0.0881† | 0.0738† |
| *applicable baselines* | 10 of 11 | 10 of 11 | 10 of 11 | 10 of 11 | 9 of 11 | 1 of 11 | 11 of 11 |
| *best baseline* | PIGMENT | PIGMENT | PIGMENT | PIGMENT | PIGMENT | QTI | PIGMENT |
| *gain of EQUAL (%)* | 11.1 | 12.4 | 17.2 | 17.3 | 22.1 | 30.5 | 16.5 |

The gain row is **computed** from the two values above it, never typed.

### Table XI - Generalization reported one acquisition axis at a time

Only the first row holds everything else fixed, and only the first row is a test of Theorem 2. The other three are extrapolation in the continuous descriptor (14), about which the theory says nothing.

| Axis | What changes | Reduction (%) | 95% CI | Cohen's d | Comparator | Thm 2 covers it? |
| --- | --- | --- | --- | --- | --- | --- |
| New directions | directions, shells fixed | 11.1† | (9.4, 12.8) | 1.42† | PIGMENT | yes |
| Unseen b-values | b beyond the training range | 22.1† | (18.3, 25.6) | 1.88† | PIGMENT | no |
| Encoding shape | planar and spherical b-tensors | 30.5† | (25.1, 35.4) | 2.31† | QTI | no |
| Scanner and site | vendor, site, gradient hardware | 17.3† | (11.8, 22.9) | 1.67† | PIGMENT | no |

### Table XII - The optimism of grid-referenced self-supervision

| Model | vs. own resampled reference | vs. raw held-out | Optimism gap | Share of reported error |
| --- | --- | --- | --- | --- |
| UPER | 0.0346† | 0.0574† | 0.0228† | 39.7% |
| D_RoPE | 0.0359† | 0.0566† | 0.0207† | 36.6% |
| SH_sCNN | 0.0418† | 0.0621† | 0.0203† | 32.7% |
| *oracle (noise-free)* | -- | 0.0062† | 0.0062† | -- |
| **EQUAL** | not applicable | 0.0497† | 0 | -- |

Decomposition for UPER: 27% of the gap is interpolation smoothing, the remaining 73% is leakage; a margin of 3.7 to one. EQUAL builds no resampled reference at any stage, so no gap is defined for it.

### Table XIV - Physical validity and extrapolation

| Method | Violation rate (39), % |
| --- | --- |
| SH_interp | 14.90† |
| MAP_MRI | 2.40† |
| SHARD | 3.10† |
| UPER | 11.70† |
| D_RoPE | 9.80† |
| PIGMENT | 4.20† |
| EQUAL_direct_mlp | 6.41† |
| EQUAL | 0.00 |

**Extrapolation beyond the acquired b-range**

| b*/b_max | 1.5 | 2.0 | 3.0 | 4.0 |
| --- | --- | --- | --- | --- |
| EQUAL NRMSE | 0.061† | 0.079† | 0.118† | 0.162† |
| divergence of two half-protocol fits | 0.028† | 0.049† | 0.097† | 0.171† |
| **Thm 6(ii) bound, eps=0.01, computed from (35)** | 0.171 | 0.342 | 0.636 | 0.853 |

The bound row is evaluated from equation (35), not transcribed. It reads `2^(1-omega) eps^omega` with `omega = (2/pi) arcsin(b_max/b*)`, the formula whose crossing points (3.438, 4.901, 7.005) reproduce the 3.4 / 4.9 / 7.0 quoted in Section V and Fig. 5(b). **This disagrees with the bound row printed in the manuscript's Table XIV** (0.071 / 0.134 / 0.309 / 0.561); see `audit/audit.py`, check `thm6_bound_row`. The measured divergence stays inside the bound either way.

### Table XVII - Quality of the identifiability flag beyond its AUC

| Readout | AUC | 95% CI | False-confident rate | Wilson 95% CI |
| --- | --- | --- | --- | --- |
| FW | 0.951† | (0.935, 0.965) | 6 / 268 = 0.022 | (0.010, 0.048) |
| MD | 0.931† | (0.912, 0.949) | 9 / 252 = 0.036 | (0.019, 0.066) |
| muFA | 0.967† | (0.954, 0.978) | 4 / 306 = 0.013 | (0.005, 0.033) |
| FOD | 0.918† | (0.896, 0.938) | 12 / 238 = 0.050 | (0.029, 0.086) |

The Wilson intervals are **computed** from the counts beside them.

### Table XX - Ablations: one study per design choice

The change column is **computed** as the difference from the reference model (0.0497).

| Component | Variant | NRMSE | Change | Targeted metric | Value |
| --- | --- | --- | --- | --- | --- |
| Input | icosahedral resampling | 0.0569† | +0.0072 | optimism gap | 0.0191† |
|  | raw lifting (ref.) | 0.0497† | ref. | optimism gap | 0† |
| Quadrature | uniform | 0.0528† | +0.0031 | sw slope | -1.12† |
|  | exact rule (ref.) | 0.0497† | ref. | sw slope | -2.19† |
| Encoding | one hot | 0.0541† | +0.0044 | cdmd zero shot | 0.0983† |
|  | continuous (ref.) | 0.0497† | ref. | cdmd zero shot | 0.0724† |
| Linear channel | removed | 0.0514† | +0.0017 | band limited recovery error | 0.0073† |
|  | kept (ref.) | 0.0497† | ref. | band limited recovery error | 0† |
| Shell pooling | mean | 0.0519† | +0.0022 | shell holdout nrmse | 0.0714† |
|  | attention (ref.) | 0.0497† | ref. | shell holdout nrmse | 0.0649† |
| Backbone | non equivariant | 0.0556† | +0.0059 | equivariance error | 0.0941† |
|  | equivariant (ref.) | 0.0497† | ref. | equivariance error | 2.7e-06† |
| Symmetry group | product | 0.0523† | +0.0026 | on harmony fw cov pct | 5.8† |
|  | joint (ref.) | 0.0497† | ref. | on harmony fw cov pct | 3.6† |
| Decoder | direct mlp | 0.0491† | -0.0006 | violation rate pct | 6.41† |
|  | laplace measure (ref.) | 0.0497† | ref. | violation rate pct | 0† |
| Free-water atom | none | 0.0503† | +0.0006 | scan rescan icc fw | 0.871† |
|  | fixed (ref.) | 0.0497† | ref. | scan rescan icc fw | 0.934† |
| Data term | mse adc | 0.0534† | +0.0037 | nrmse b3000 | 0.0812† |
|  | rician nll (ref.) | 0.0497† | ref. | nrmse b3000 | 0.0702† |
| Consistency | zero | 0.0505† | +0.0008 | sw at L4 | 4.18† |
|  | positive (ref.) | 0.0497† | ref. | sw at L4 | 2.41† |
| Supervision | distilled | 0.0491† | -0.0006 | fod acc hcp | 0.902† |
|  | none (ref.) | 0.0497† | ref. | fod acc hcp | 0.897† |
