# Reproducibility package

**Audit Section 9 (P0, Fail):** *no code, weights, manifests or per-case
predictions; archive identifier is a placeholder.* This file is the checklist for
closing it. Items marked ☐ are outstanding.

## Contents of the archive

- ☑ **Code** — this repository, MIT licensed.
- ☐ **Trained weights** — for EQUAL and EQUAL-D, all three seeds.
- ☑ **Configuration files** — `configs/`, one per ablation.
- ☑ **Split manifests** — `results/splits/`, subject-level, with an overlap
  check and a fingerprint. Currently built from *synthetic* identifiers; rerun
  `scripts/make_splits.py --subject-ids …` with the real lists.
- ☐ **Per-case predictions** behind every table and figure.
- ☐ **Persistent identifier** — a DOI from Zenodo or similar. The manuscript
  currently reads "[to be inserted before submission]".

## Environment

```
Python   >= 3.10
numpy    >= 1.24
scipy    >= 1.10
torch    >= 2.0
pyyaml   >= 6.0
```

Developed and tested on Python 3.13, numpy 2.5, scipy 1.18, torch 2.14, CPU.

`pip install -e ".[dev]"` then `make check`.

## Determinism

- Quadrature weights are a **deterministic function of the direction set**: the
  minimiser of (12) is unique, which is the hypothesis Theorem 1 rests on. The
  test suite asserts a rotated protocol receives the rotated rule to 4e-15.
- The slice, the regions of interest and the random seed for every figure are
  fixed in code, as Section VI-F requires.
- `generate_field(..., seed=k)` is reproducible.
- `sliced_wasserstein2` takes an explicit `torch.Generator` so a consistency
  value can be reproduced exactly.
- Three training seeds are **averaged within a unit before any test**
  (`stats.aggregate_seeds`), so a seed is never counted as an independent
  observation. The function refuses an axis that looks like the unit axis.

## What a reader can reproduce today, with no download

```bash
make test        # 83 tests, ~55 s
make audit       # the build gate
python scripts/train.py --steps 50
python scripts/evaluate.py --fields 8
```

These exercise the structural guarantees — equivariance, validity, the
quadrature construction, the identifiability rule, the Theorem 6(ii) bound — on
in-silico data generated from the signal model itself. **They do not reproduce
any number in Sections VIII–IX**, which are illustrative placeholders.

## Replacing the placeholders

1. Prepare the data (see `docs/DATA_PROVENANCE.md`) and write the real manifests.
2. `python scripts/train.py --config configs/equal_base.yaml --data <dir>` for
   each of the three seeds; repeat with `configs/equal_d.yaml` for EQUAL-D.
3. `python scripts/evaluate.py --checkpoint <ckpt> --write-results`. Values are
   written with `provenance: measured`, naming the script and commit.
4. `python scripts/build_tables.py --out docs/TABLES.md` — every table
   regenerates, and daggers disappear as placeholders are replaced.
5. `./final_check.sh` — the full gate, including `audit.py --strict`.

`evaluate.py` refuses to write results from an untrained model, so an
exploratory run cannot quietly overwrite labelled placeholders with labelled
nonsense.

## Cost

Section VI-F reports 21 GPU-days on 3 cards for a full training run, and Table
XIX reports 94 s per whole brain at inference. Neither has been reproduced here.
This implementation reaches 15.9 M parameters at the default `radial_rank=4`
against the 18.4 M of Table XIX; the count depends on how the SO(2) radial
weights are factorized, which the manuscript does not specify.
