# Equation-to-code map

**Audit Section 1 — Equation-to-code verification (P0).** The audit records
*"No implementation: only (12), (13) and (26) have code."* This file is the map
it asks for: every numbered equation in the manuscript, where it is implemented,
and the test that checks it.

Run the checks with `make test`, or `python -m pytest tests/ -q`.

---

## Reading this table

- **Status** — `exact` means the code reproduces the equation to machine
  precision and a test asserts it; `implemented` means the code follows the
  equation but there is no closed form to check it against; `partial` means the
  implementation makes a choice the equation leaves open, documented below.
- A **convention note** marks the three places where the manuscript's notation
  and this implementation's differ for a reason worth stating.

---

## III. Problem statement

| Eq. | What it says | Code | Test | Status |
| --- | --- | --- | --- | --- |
| (1) | `B = b[(1-bΔ)/3 I + bΔ gg^T]` | `data/protocols.py::b_tensor` | `test_components.py::TestDescriptor` | exact |
| (2) | `E(B) = ∫ exp(-⟨B,D⟩) dμ(D)` | `signal_model.py::TensorDistribution.signal` | `test_theorems.py::TestTheorem5Identifiability` | exact |
| (3) | Rician density | `signal_model.py::rician_pdf` | `test_components.py::TestLosses` | exact |
| (4) | `Y_ℓ(Rg) = D_ℓ(R) Y_ℓ(g)` | `sh.py::wigner_D` | `test_theorems.py::test_sh_transforms_by_wigner_blocks` | exact (1e-12) |
| (5) | Measurement set `X` | `data/protocols.py::Protocol` | `test_components.py::TestMasking` | implemented |
| (6) | `F_Θ : X ↦ (μ_1,…,μ_V)` | `model.py::EQUAL` | `test_theorems.py` (all) | implemented |
| (7) | Action of `(R,t)` on `X` and `μ` | `data/protocols.py::Protocol.rotated` | `test_theorems.py::test_joint_rotation_equivariance` | exact |
| (8) | The three exact constraints | `model.py::EQUAL` (by construction) | `TestTheorem1ExactSymmetry` (6 tests) | exact (<1e-5, float32) |
| (9) | The training objective | `scripts/train.py` | smoke-tested | implemented |
| (10) | `ρ(A)`, the identifiability map | `identifiability.py::identifiability_map` | `test_theorems.py::test_rule_matches_table_iii` | exact |

## IV. Method

| Eq. | What it says | Code | Test | Status |
| --- | --- | --- | --- | --- |
| (11) | `F_Θ = K_ψ ∘ B_θ ∘ Q_φ` | `model.py::EQUAL.forward` | — | implemented |
| (12) | Min-norm nonnegative quadrature | `quadrature.py::solve_minimum_norm_weights` | `test_theorems.py::test_rule_is_exact_to_its_degree` | exact (1e-15) ⚠️ **convention note 1** |
| (13) | Exact degree `L_p` | `quadrature.py::exact_degree` | `test_degree_8_needs_45_moment_conditions` | exact |
| (14) | Continuous b-tensor descriptor `γ` | `lifting.py::b_tensor_descriptor` | `test_components.py::TestDescriptor` | exact |
| (15) | Per-shell steerable lift | `lifting.py::QSpaceLifting.forward` | `test_theorems.py::TestTheorem3` | exact ⚠️ **convention note 2** |
| (16) | The integral (15) discretizes | — (the continuum limit) | `test_rule_is_exact_to_its_degree` | n/a |
| (17) | Attention pooling over shells | `lifting.py::QSpaceLifting.forward` | `test_permutation_invariance` | implemented |
| (18) | SO(2)-reduced message | `equivariance.py::SO2Linear`, `backbone.py::_EquivariantBlock` | `test_joint_rotation_equivariance` | exact ⚠️ **convention note 3** |
| (19) | Graph attention, invariant scores | `backbone.py::_EquivariantBlock.forward` | `test_joint_rotation_equivariance` | implemented |
| (20) | Residual update | `backbone.py::_EquivariantBlock.forward` | — | implemented |
| (21) | `μ_j = π_0 δ_{d_fw I} + Σ π_k δ_{D_k}` | `decoder.py::LaplaceMeasureDecoder` | `test_decoded_measure_is_a_probability_measure_on_T` | exact |
| (22) | `π = softmax(W_π h^0)` | `decoder.py::LaplaceMeasureDecoder.forward` | same | exact |
| (23) | `M = uI + Σ v_m U_m`, `D = d_t Q sig(Λ) Q^T` | `decoder.py` + `decoder.py::u_basis` | `test_u_basis_intertwines_conjugation` | exact (2.4e-15) |
| (24) | Closed-form Laplace transform | `decoder.py::signal_from_measure` | `test_signal_is_bounded_and_decays` | exact |
| (25) | `f^FW`, `MD` | `readouts.py` | `test_theorems.py::TestTheorem5` | exact |
| (26) | `μFA²` | `readouts.py::micro_fa` | `test_mufa_is_one_for_sticks_and_zero_for_isotropic` | exact (1e-6) |
| (27) | FOD coefficients | `readouts.py::fod_coefficients` | `test_equivariance_error_on_cubic_lattice_rotations` | implemented ⚠️ **apodization, below** |
| (28) | Rician NLL | `losses.py::rician_nll_loss` | `test_rician_loss_agrees_with_the_numpy_reference` | exact |
| (29) | Sliced Wasserstein | `losses.py::sliced_wasserstein2` | `test_w2_matches_brute_force_on_equal_weights` | exact (1e-12) |
| (30) | `L_cons` | `losses.py::consistency_loss` | `test_consistency_loss_is_invariant_to_atom_order` | exact |
| (31) | `L_sup`, ACC | `losses.py::distillation_loss`, `readouts.py::angular_correlation` | — | implemented |
| (32) | `L = λ_rec L_Rice + λ_cons L_cons + λ_sup L_sup` | `losses.py::total_loss` | smoke-tested | exact |

## V. Theory

| Eq. | What it says | Code | Test | Status |
| --- | --- | --- | --- | --- |
| (33) | Theorem 2 bound | `theory.py::quadrature_consistency_rate` | `test_discrepancy_falls_with_degree` | implemented |
| (34) | Complete monotonicity | `metrics.py::violation_rate` (first two orders) | `test_violation_rate_is_identically_zero` | exact |
| (35) | Theorem 6(ii) divergence bound | `theory.py::divergence_bound` | `test_crossing_points_match_the_manuscript` | exact ⚠️ **see finding 1** |

## VI. Metrics

| Eq. | What it says | Code | Test | Status |
| --- | --- | --- | --- | --- |
| (36) | NRMSE against raw measurements | `metrics.py::nrmse` | `test_nrmse_is_zero_for_a_perfect_prediction` | exact |
| (37) | Optimism gap `G_opt` | `metrics.py::optimism_gap` | `test_optimism_gap_and_its_decomposition` | exact |
| (38) | Equivariance error `ε_eq` | `metrics.py::equivariance_error` | `test_equivariance_error_on_cubic_lattice_rotations` | exact |
| (39) | Violation rate `V_rate` | `metrics.py::violation_rate` | `test_violation_rate_is_identically_zero` | exact |

---

## Convention notes

### 1. The right-hand side of equation (12)

The manuscript writes the quadrature constraint as `Φ^T w = 4π e₁`. With the
**orthonormal** real SH basis used throughout (and stated in Section III-C via
the Descoteaux reference), `Y₀₀ = 1/√(4π)`, so

```
Σᵢ wᵢ Y₀₀(gᵢ) = ∫ Y₀₀ dΩ = √(4π),   which gives   Σᵢ wᵢ = 4π.
```

The correct right-hand side in this convention is therefore `√(4π) e₁`, not
`4π e₁`. The two agree only under the unnormalised convention `Y₀₀ = 1`. The
implementation uses `√(4π) e₁` (`sh.py::sh_integral_vector`) and the tests
assert that the weights sum to `4π`, which is the quantity that actually
matters: it makes `Σᵢ wᵢ f(gᵢ)` approximate `∫ f dΩ` rather than a multiple of
it. **This is a notational matter, not an error in the method** — but it would
silently rescale every lifted feature by `√(4π)` if implemented literally.

### 2. The spherical-shell term in Section IV-B

The same factor appears in the STE expression. The manuscript writes
`z_{j,p,00,c} = 4π |I_p|⁻¹ Σ φ_c`. In the orthonormal convention the lift gives

```
Σᵢ wᵢ φ_c Y₀₀ = (1/√(4π)) · (4π/|I_p|) · Σ φ_c = √(4π) |I_p|⁻¹ Σ φ_c.
```

`lifting.py` implements the orthonormal form, consistently with note 1.

### 3. The gauge freedom in equation (18)

`R_{jj'}` is described as *"a rotation that maps r/‖r‖ to the z-axis"*. There is
a one-parameter family of such rotations, differing by a rotation **about** z.
Equivariance therefore requires the inner map `W^{SO(2)}` to commute with every
rotation about z — otherwise an arbitrary gauge choice reaches the output and
`F(R·X) = R ⋆ F(X)` fails for a reason that has nothing to do with round-off.

A rotation about z by `ψ` acts on the real SH pair `(Y_{ℓ,+m}, Y_{ℓ,−m})` as a
planar rotation by `mψ`. The linear maps commuting with all of them are exactly
the complex-linear ones, so `SO2Linear` stores a real pair `(A, B)` per `|m|` and
applies

```
out₊ₘ = A x₊ₘ − B x₋ₘ,     out₋ₘ = B x₊ₘ + A x₋ₘ
```

with a single real matrix at `m = 0`. `test_components` checks both directions:
the map commutes with z-rotations to 1e-14, and does **not** commute with a
general rotation (which would make it trivially invariant rather than
equivariant).

### Other implementation decisions

- **Even degrees only.** By (1) the b-tensor sees `g` only through `gg^T`, so
  every signal of the form (2) is antipodally symmetric and odd degrees vanish.
  The edge direction enters the message through `D(R_{jj'})` and the invariant
  radial basis, so no odd degree is needed to represent it.
- **FOD apodization.** Section IV-E specifies *"a fixed Gaussian apodization that
  scales degree 8 by 0.25"* without giving the functional form. We use
  `a(ℓ) = exp(−s ℓ(ℓ+1)/2)` with `s` fixed by `a(8) = 0.25`, so `a(0) = 1` and
  the factor is deterministic (`readouts.py::fod_apodization`).
- **Degrees above `L_p` are held at zero.** Section VII-C says step (13)
  *"stops the lifting from claiming a degree the protocol cannot support"*;
  writing a coefficient the rule cannot integrate exactly would void Theorem 2's
  hypothesis silently.
- **`ℓ_A` is capped at 8.** Equation (27) projects onto even harmonics up to
  degree 8, so a protocol dense enough to support degree 10 still produces an
  output carrying only degree 8. The cap changes no flag (the threshold is
  `ℓ_A ≥ 6`). Pass `l_max=None` for the uncapped quantity.
- **Parameter count.** Table XIX reports 18.4 M. This implementation reaches
  15.9 M at the default `radial_rank=4` and 61.9 M unfactorised. The count is a
  function of how the SO(2) radial weights are factorized, which the manuscript
  does not specify; `radial_rank` exposes the choice rather than hiding it.

---

## Findings

### Finding 1 — Table XIV's Theorem 6(ii) bound row does not follow from (35)

Equation (35) reads `|h(b*)| ≤ 2^{1−ω} ε^ω` with `ω = (2/π) arcsin(b_max/b*)`.

That formula is **confirmed** by the manuscript itself: the crossing points at
which the bound reaches the trivial value 1 are quoted as 3.4, 4.9 and 7.0 for
`ε = 0.05, 0.01, 0.001` in both the Section V remark and the Fig. 5(b) caption,
and the formula gives 3.438, 4.901 and 7.005.

But at `ε = 0.01` the same formula gives

| `b*/b_max` | 1.5 | 2.0 | 3.0 | 4.0 |
| --- | --- | --- | --- | --- |
| equation (35) | 0.171 | 0.342 | 0.636 | 0.853 |
| Table XIV prints | 0.071 | 0.134 | 0.309 | 0.561 |

The discrepancy is not a constant factor, so it is not a units or scaling slip.
This is the same defect class the audit already caught in Table XVII (*"summary
values did not match their own data … all are now computed rather than typed"*):
the row appears to be typed rather than evaluated.

**The qualitative claim survives.** The measured divergence of two half-protocol
fits (0.028 / 0.049 / 0.097 / 0.171) stays inside the bound on either reading.
What changes is the stated slack.

Enforced by `audit/audit.py`, check `thm6_bound_row`, which fails the build.

### Finding 2 — Table XI names the wrong comparator on CDMD

Table XI's unseen-b row gives the best applicable baseline on CDMD as PIGMENT
(0.0929) and reports a 22.1 % reduction. In Table X, **SHARD reaches 0.0914 on
CDMD**, which is better, and Table X's own gain row reports **20.8 %** for that
source — computed against SHARD.

So the manuscript reports two different reductions for the same comparison:
20.8 % (Table X) and 22.1 % (Table XI and the abstract). The abstract phrases it
as *"17.3, 22.1 and 30.5 percent … each against the baselines that can process
it"*, and that is the clause that fails: SHARD can process CDMD and does better
than PIGMENT.

Every other margin in both tables is internally consistent; `audit.py` verifies
all seven of Table X's gains and all four of Table XI's axes.

Enforced by `audit/audit.py`, check `table11_comparator`, which fails the build.
