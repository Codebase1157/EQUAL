"""Shared fixtures.

The model fixtures are deliberately small: the theorems these tests check are
exact identities that hold for *every* value of Theta and every admissible
input, so a two-block network at L=4 tests them as sharply as the full
configuration and keeps the suite runnable in CI.  Where a test depends on the
full degree L=8, it says so and builds its own.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from equal.data.protocols import (  # noqa: E402
    Protocol, Shell, electrostatic_directions, hcp_ya_protocol, tensor_valued_protocol,
)
from equal.model import EQUAL, EqualConfig, prepare_input  # noqa: E402


@pytest.fixture(scope="session")
def rng() -> np.random.Generator:
    return np.random.default_rng(20261020)


@pytest.fixture(scope="session")
def small_config() -> EqualConfig:
    return EqualConfig(
        l_max=4, lift_channels=8, pool_heads=2, c_invariant=16, c_steerable=8,
        n_blocks=2, n_attention_heads=2, n_radial=4, n_atoms=4, r_cut=3.0,
    )


@pytest.fixture(scope="session")
def small_model(small_config) -> EQUAL:
    torch.manual_seed(0)
    m = EQUAL(small_config)
    m.eval()
    return m


@pytest.fixture(scope="session")
def patch_positions() -> np.ndarray:
    """A 3x3x3 patch at 1.25 mm, as coordinates in millimetres."""
    axes = [np.arange(3) * 1.25] * 3
    return np.stack(np.meshgrid(*axes, indexing="ij"), axis=-1).reshape(-1, 3)


@pytest.fixture(scope="session")
def hcp_protocol() -> Protocol:
    return hcp_ya_protocol(n_dir=30, seed=0)


@pytest.fixture(scope="session")
def tensor_protocol() -> Protocol:
    return tensor_valued_protocol(b_values=(700.0, 1400.0), n_lte=20, n_pte=20, n_ste=6)


@pytest.fixture
def signals(hcp_protocol, patch_positions):
    torch.manual_seed(1)
    return [
        torch.rand(len(patch_positions), s.n_directions) * 0.5 + 0.3
        for s in hcp_protocol.shells if not s.is_b0
    ]


def forward(model, config, protocol, positions, sigs):
    """Run the model, returning the decoded measure."""
    prep = prepare_input(protocol, config)
    geo = model.build_geometry(positions)
    with torch.no_grad():
        return model(sigs, prep, geo)
