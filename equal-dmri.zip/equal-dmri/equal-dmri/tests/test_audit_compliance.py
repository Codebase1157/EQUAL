"""Tests for the audit's own requirements.

These are not tests of the method; they are tests that the repository keeps the
promises the pre-submission audit asks for.  Each class names the audit section
it serves.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest

from equal.data.splits import (
    HCP_YA_ACCOUNTING, HCPAccounting, SplitManifest, check_overlap,
    load_manifest, make_subject_split, verify_hcp_accounting, write_manifest,
)
from equal.results import (
    Provenance, ResultStore, Value, external, illustrative, measured, theoretical,
)

ROOT = Path(__file__).resolve().parents[1]


class TestAuditSection3Splits:
    """Audit Section 3: data splits and overlap (P0, Fail)."""

    def test_overlap_between_splits_raises(self):
        with pytest.raises(ValueError, match="both train and test"):
            SplitManifest(dataset="x", train=["a", "b"], val=["c"], test=["b"])

    def test_duplicate_within_a_split_raises(self):
        with pytest.raises(ValueError, match="duplicate"):
            SplitManifest(dataset="x", train=["a", "a"], val=["b"], test=["c"])

    def test_split_is_at_subject_level(self):
        ids = [f"s{i:04d}" for i in range(100)]
        m = make_subject_split(ids, dataset="t", seed=0)
        assert m.n_subjects == 100
        assert not (set(m.train) & set(m.test))
        assert m.unit == "subject"

    def test_retest_subjects_fall_inside_the_test_set(self):
        """Section VIII-A: constrained to fall inside the 94, not added to them."""
        ids = [f"s{i:04d}" for i in range(940)]
        retest = ids[:46]
        m = make_subject_split(ids, (0.8, 0.1, 0.1), seed=0,
                               constrain_to_test=retest, dataset="HCP-YA")
        assert set(retest) <= set(m.test)
        assert len(m.test) == 94
        assert m.n_subjects == 940
        assert not (set(retest) & (set(m.train) | set(m.val)))

    def test_constrained_subject_not_in_test_raises(self):
        m = SplitManifest(dataset="x", train=["a"], val=["b"], test=["c"])
        m.constrained_to_test = ["a"]
        with pytest.raises(ValueError, match="constrained"):
            check_overlap(m)

    def test_hcp_accounting_chain_closes(self):
        d = verify_hcp_accounting()
        acc = HCP_YA_ACCOUNTING
        assert acc.with_complete_dwi - acc.excluded_qc_or_preproc == acc.eligible
        assert acc.n_train + acc.n_val + acc.n_test == acc.eligible
        assert d["n_test_scans"] == 140          # 94 subjects + 46 second scans

    def test_a_placeholder_exclusion_count_cannot_pass(self):
        """The audit records the exclusion count as a placeholder.

        Any value that does not make the chain close must fail, which is what
        stops a placeholder sitting there unnoticed.
        """
        bad = HCPAccounting(
            release_total=1206, with_complete_dwi=1065,
            excluded_qc_or_preproc=0,          # a placeholder
            eligible=940, n_train=752, n_val=94, n_test=94, n_retest_subjects=46,
        )
        with pytest.raises(ValueError, match="chain does not close"):
            bad.verify()

    def test_retest_cannot_exceed_test_set(self):
        bad = HCPAccounting(
            release_total=1206, with_complete_dwi=1065, excluded_qc_or_preproc=125,
            eligible=940, n_train=752, n_val=94, n_test=94, n_retest_subjects=200,
        )
        with pytest.raises(ValueError, match="cannot fit inside"):
            bad.verify()

    def test_manifest_roundtrip_detects_tampering(self, tmp_path):
        ids = [f"s{i}" for i in range(50)]
        m = make_subject_split(ids, dataset="t", seed=1)
        p = write_manifest(m, tmp_path / "t.json")
        assert load_manifest(p).fingerprint() == m.fingerprint()

        d = json.loads(p.read_text())
        d["test"].append(d["train"].pop())          # move a subject across
        p.write_text(json.dumps(d))
        with pytest.raises(ValueError):
            load_manifest(p)


class TestAuditSection13Provenance:
    """Audit Section 13: data provenance (P0, Fail) -- label every value."""

    def test_bare_floats_are_rejected(self):
        s = ResultStore()
        with pytest.raises(TypeError, match="provenance"):
            s.set("table9.EQUAL.white_matter", 0.0497)

    def test_illustrative_must_say_what_it_stands_for(self):
        with pytest.raises(ValueError, match="placeholder for"):
            Value(0.05, Provenance.ILLUSTRATIVE)

    def test_measured_must_name_its_script(self):
        with pytest.raises(ValueError, match="script"):
            Value(0.05, Provenance.MEASURED)

    def test_external_must_carry_a_citation(self):
        with pytest.raises(ValueError, match="citation"):
            Value(0.05, Provenance.EXTERNAL)

    def test_derived_inherits_the_weakest_provenance(self):
        """A ratio of two placeholders is still a placeholder."""
        s = ResultStore()
        s.set("a", illustrative(2.0, note="placeholder"))
        s.set("b", measured(1.0, script="evaluate.py"))
        s.set_derived("c", 2.0, ["a", "b"], note="a / b")
        assert s.get("c").provenance is Provenance.ILLUSTRATIVE
        assert s.get("c").is_placeholder

    def test_derived_from_evidence_is_evidence(self):
        s = ResultStore()
        s.set("a", measured(2.0, script="evaluate.py"))
        s.set("b", theoretical(1.0, note="from (35)"))
        s.set_derived("c", 2.0, ["a", "b"], note="a / b")
        assert s.get("c").provenance.is_evidence

    def test_store_reports_unsubmittable_while_placeholders_remain(self):
        s = ResultStore()
        s.set("x", illustrative(1.0, note="placeholder"))
        ok, ph = s.is_submittable()
        assert not ok and ph == ["x"]

    def test_placeholders_are_marked_in_formatted_output(self):
        """An unlabelled placeholder in a table is indistinguishable from data."""
        s = ResultStore()
        s.set("x", illustrative(0.0497, note="placeholder"))
        s.set("y", measured(0.0497, script="evaluate.py"))
        assert s.format_value("x").endswith("†")
        assert not s.format_value("y").endswith("†")

    def test_delivered_store_labels_every_value(self):
        p = ROOT / "results" / "results.json"
        if not p.exists():
            pytest.skip("results.json not built")
        s = ResultStore(p)
        assert len(s) > 0
        for _, v in s:
            assert isinstance(v.provenance, Provenance)

    def test_section_viii_ix_values_are_not_claimed_as_measured(self):
        """The audit's central fact: EQUAL has not been implemented, trained or run.

        Until it is, nothing under the result tables may claim MEASURED.
        """
        p = ROOT / "results" / "results.json"
        if not p.exists():
            pytest.skip("results.json not built")
        s = ResultStore(p)
        offenders = [
            k for k in s.keys()
            if k.split(".")[0].startswith("table")
            and s.get(k).provenance is Provenance.MEASURED
        ]
        if offenders:
            # This is legitimate once the experiments have been run; the test
            # then requires each to name the script that produced it.
            for k in offenders:
                assert s.get(k).script, f"{k} claims MEASURED with no script"


class TestAuditSection2NumericalConsistency:
    """Audit Section 2: values computed rather than typed (P0, Fail)."""

    def test_audit_script_runs_and_reports(self):
        r = subprocess.run(
            [sys.executable, "-I", str(ROOT / "audit" / "audit.py")],
            capture_output=True, text=True, cwd=ROOT, timeout=300,
        )
        assert "EQUAL build audit" in r.stdout
        assert r.returncode in (0, 1)

    def test_audit_exits_non_zero_when_a_check_fails(self):
        """The audit found that audit.py always exited zero; it must not."""
        r = subprocess.run(
            [sys.executable, "-I", str(ROOT / "audit" / "audit.py"), "--strict"],
            capture_output=True, text=True, cwd=ROOT, timeout=300,
        )
        # With placeholders present, --strict must fail.
        assert r.returncode == 1, "strict audit must fail while placeholders remain"

    def test_table_x_margins_follow_from_the_values(self):
        """Each gain must equal the reduction over the best applicable baseline."""
        p = ROOT / "results" / "results.json"
        if not p.exists():
            pytest.skip("results.json not built")
        s = ResultStore(p)
        baselines = ["SH_interp", "MAP_MRI", "SHARD", "QTI", "SH_CNN", "SH_sCNN",
                     "S_CNN", "E3xSO3", "UPER", "D_RoPE", "PIGMENT"]
        expected = {"HCP_YA": 11.1, "MASiVar_A": 12.4, "MASiVar_P": 17.2,
                    "ON_Harmony": 17.3, "CDMD": 20.8, "tensor_valued": 30.5,
                    "in_silico": 16.5}
        for src, claimed in expected.items():
            vals = {m: float(s.value_of(f"table10.{m}.{src}"))
                    for m in baselines
                    if f"table10.{m}.{src}" in s
                    and s.value_of(f"table10.{m}.{src}") != "n/a"}
            best = min(vals.values())
            e = float(s.value_of(f"table10.EQUAL.{src}"))
            assert abs((best - e) / best * 100 - claimed) < 0.06, src


class TestAuditSection12ScopeOfClaims:
    """Audit Section 12: abstract/conclusion alignment (P1, Fail)."""

    def test_single_baseline_sources_record_that_fact(self):
        p = ROOT / "results" / "results.json"
        if not p.exists():
            pytest.skip("results.json not built")
        s = ResultStore(p)
        n = int(s.value_of("table10.applicable_baselines.tensor_valued"))
        assert n == 1
        note = s.get("abstract.reduction_encoding_shape_pct").note.lower()
        assert "qti" in note, "the 30.5% margin must name its single comparator"

    def test_theorem2_covers_only_the_direction_axis(self):
        p = ROOT / "results" / "results.json"
        if not p.exists():
            pytest.skip("results.json not built")
        s = ResultStore(p)
        covered = {a: bool(s.value_of(f"table11.{a}.theorem2_covers"))
                   for a in ("new_directions", "unseen_b",
                             "encoding_shape", "scanner_site")}
        assert covered["new_directions"] is True
        assert not any(v for k, v in covered.items() if k != "new_directions")
