"""One test class per theorem, paired as Table VI pairs them.

Table VI's last column names the experiment that checks each result.  Two of
its eight rows are "checked only by construction, because an exact architectural
identity has nothing to measure beyond floating-point round-off" -- those are
Theorems 1 and 4, and the corresponding tests assert that the round-off is at
float32 level rather than that some trained quantity is small.

Theorem 3(i)'s hypothesis (a band-limited shell signal) is not verifiable on
real data, but it *is* constructible in a test, so the implication is checked
directly here even though Table VI records it as "not directly testable" on
acquisitions.
"""

from __future__ import annotations

import numpy as np
import pytest
import torch

from conftest import forward
from equal.data.protocols import (
    Protocol, Shell, b_tensor, electrostatic_directions, single_shell_protocol,
)
from equal.decoder import u_basis
from equal.identifiability import identifiability_map
from equal.metrics import equivariance_error, validity_test_set, violation_rate
from equal.model import prepare_input
from equal.quadrature import build_rule, exact_degree, solve_minimum_norm_weights
from equal.readouts import fod_coefficients, micro_fa
from equal.sh import (
    cubic_lattice_rotations, n_coeff, random_rotation, real_sh,
    rotate_sh_coefficients, wigner_D,
)
from equal.signal_model import D_FREE_WATER, TensorDistribution
from equal.theory import divergence_bound, trivial_crossing_ratio

FLOAT32_ROUNDOFF = 1e-5


# ---------------------------------------------------------------- Theorem 1
class TestTheorem1ExactSymmetry:
    """Exact symmetry: holds for every value of Theta, by construction."""

    def test_quadrature_rule_is_a_function_of_the_direction_set(self, rng):
        """The hypothesis Theorem 1 rests on (Section VII-A).

        Uniqueness of the minimiser in (12) is what makes the weights a function
        of the directions rather than a choice.  Without it a rotated protocol
        could receive a different rule and the lifted features would no longer
        transform by the Wigner blocks.
        """
        g = electrostatic_directions(46, seed=1)
        base = build_rule(g, l_max=8)
        for _ in range(5):
            R = random_rotation(rng)
            rot = build_rule(g @ R.T, l_max=8)
            assert rot.degree == base.degree
            assert np.allclose(rot.weights, base.weights, atol=1e-10)

    def test_sh_transforms_by_wigner_blocks(self, rng):
        """Equation (4), the identity the lift inherits."""
        for ell in (0, 2, 4, 6, 8):
            R = random_rotation(rng)
            D = wigner_D(ell, R)
            off = sum(2 * k + 1 for k in range(0, ell, 2))
            dim = 2 * ell + 1
            g = rng.normal(size=(40, 3))
            g /= np.linalg.norm(g, axis=1, keepdims=True)
            lhs = real_sh(ell, g @ R.T)[:, off : off + dim]
            rhs = real_sh(ell, g)[:, off : off + dim] @ D.T
            assert np.abs(lhs - rhs).max() < 1e-12
            assert np.abs(D @ D.T - np.eye(dim)).max() < 1e-12

    def test_u_basis_intertwines_conjugation(self, rng):
        """``v -> sum_m v_m U_m`` intertwines ``D_2(R)`` with ``D -> R D R^T``.

        This is what carries equivariance through equation (23).
        """
        U = u_basis()
        assert np.abs(U - U.transpose(0, 2, 1)).max() < 1e-12       # symmetric
        assert np.abs(np.einsum("mii->m", U)).max() < 1e-12         # traceless
        assert np.abs(np.einsum("mij,nij->mn", U, U) - np.eye(5)).max() < 1e-12
        for _ in range(20):
            R = random_rotation(rng)
            v = rng.normal(size=5)
            lhs = R @ np.einsum("m,mij->ij", v, U) @ R.T
            rhs = np.einsum("m,mij->ij", wigner_D(2, R) @ v, U)
            assert np.abs(lhs - rhs).max() < 1e-12

    def test_joint_rotation_equivariance(
        self, small_model, small_config, hcp_protocol, patch_positions, signals, rng
    ):
        """``F(R.X) = R * F(X)`` for the assembled operator -- equation (8)."""
        mu = forward(small_model, small_config, hcp_protocol, patch_positions, signals)
        for _ in range(3):
            R = random_rotation(rng)
            mu_r = forward(
                small_model, small_config, hcp_protocol.rotated(R),
                patch_positions @ R.T, signals,
            )
            Rt = torch.as_tensor(R, dtype=torch.float32)
            expect = torch.einsum("ab,vkbc,dc->vkad", Rt, mu.tensors, Rt)
            rel = float((mu_r.tensors - expect).abs().max() / expect.abs().max())
            assert rel < FLOAT32_ROUNDOFF, f"equivariance error {rel:.2e}"
            assert float((mu_r.weights - mu.weights).abs().max()) < FLOAT32_ROUNDOFF

    def test_equivariance_error_on_cubic_lattice_rotations(
        self, small_model, small_config, hcp_protocol, patch_positions, signals
    ):
        """Equation (38) over the 24 rotations every model can accept exactly.

        Section VIII-C averages over these so that a lattice-based model can be
        rotated without image interpolation.  For EQUAL the result is round-off,
        which Table VI records as the only thing there is to measure.
        """
        L = small_config.l_max
        mu = forward(small_model, small_config, hcp_protocol, patch_positions, signals)
        base = fod_coefficients(mu, l_max=L).numpy()
        errs = []
        for R in cubic_lattice_rotations():
            mu_r = forward(
                small_model, small_config, hcp_protocol.rotated(R),
                patch_positions @ R.T, signals,
            )
            got = fod_coefficients(mu_r, l_max=L).numpy()
            # R * F(X): the coefficients of the rotated FOD, not the unrotated ones.
            expect = rotate_sh_coefficients(base, R, L)
            errs.append(equivariance_error(got, expect))
        eps = float(np.mean(errs))
        assert eps < FLOAT32_ROUNDOFF, f"eps_eq = {eps:.2e}"

    def test_model_is_not_rotation_invariant(
        self, small_model, small_config, hcp_protocol, patch_positions, signals, rng
    ):
        """The control for the test above.

        Equivariance is only meaningful if the output actually moves under
        rotation: a model that ignored orientation entirely would pass an
        equivariance test written against the unrotated reference.  The FOD must
        change by a large amount when the head rotates.
        """
        L = small_config.l_max
        mu = forward(small_model, small_config, hcp_protocol, patch_positions, signals)
        base = fod_coefficients(mu, l_max=L).numpy()
        R = random_rotation(rng)
        mu_r = forward(
            small_model, small_config, hcp_protocol.rotated(R),
            patch_positions @ R.T, signals,
        )
        got = fod_coefficients(mu_r, l_max=L).numpy()
        assert equivariance_error(got, base) > 1e-2, (
            "the FOD barely moved under rotation, so the equivariance test above "
            "would pass trivially"
        )

    def test_permutation_invariance(
        self, small_model, small_config, hcp_protocol, patch_positions, signals, rng
    ):
        """``X`` is a set: storage order must not reach the output."""
        mu = forward(small_model, small_config, hcp_protocol, patch_positions, signals)
        shells = [s for s in hcp_protocol.shells if not s.is_b0]
        perms = [rng.permutation(s.n_directions) for s in shells]
        permuted = Protocol(
            [Shell(0.0, "LTE", np.array([[0.0, 0.0, 1.0]]))]
            + [Shell(s.b, s.shape, s.directions[p]) for s, p in zip(shells, perms)]
        )
        mu_p = forward(
            small_model, small_config, permuted, patch_positions,
            [s[:, torch.as_tensor(p)] for s, p in zip(signals, perms)],
        )
        assert float((mu_p.tensors - mu.tensors).abs().max()) < FLOAT32_ROUNDOFF

    def test_sign_flip_invariance(
        self, small_model, small_config, hcp_protocol, patch_positions, signals, rng
    ):
        """``g -> -g`` leaves ``B`` unchanged by (1), so it must leave mu unchanged."""
        mu = forward(small_model, small_config, hcp_protocol, patch_positions, signals)
        shells = [s for s in hcp_protocol.shells if not s.is_b0]
        flipped = Protocol(
            [Shell(0.0, "LTE", np.array([[0.0, 0.0, 1.0]]))]
            + [
                Shell(s.b, s.shape,
                      s.directions * np.where(rng.random((s.n_directions, 1)) < 0.5, -1.0, 1.0))
                for s in shells
            ]
        )
        mu_f = forward(small_model, small_config, flipped, patch_positions, signals)
        assert float((mu_f.tensors - mu.tensors).abs().max()) < FLOAT32_ROUNDOFF


# ---------------------------------------------------------------- Theorem 2
class TestTheorem2AcquisitionConsistency:
    """Approximate, with rate ``L^{-r}``.  Its hypothesis is narrow."""

    def test_rule_is_exact_to_its_degree(self):
        """Exactness and nonnegativity: the two properties (33) relies on."""
        for n in (20, 30, 46, 64, 90):
            g = electrostatic_directions(n, seed=1)
            rule = build_rule(g, l_max=8)
            assert np.all(rule.weights >= 0.0)
            assert rule.residual < 1e-9
            assert abs(rule.weights.sum() - 4 * np.pi) < 1e-9
            # integrates every even harmonic up to L_p exactly
            c = np.random.default_rng(n).normal(size=n_coeff(rule.degree))
            f = real_sh(rule.degree, g) @ c
            assert abs(rule.integrate(f) - np.sqrt(4 * np.pi) * c[0]) < 1e-9

    def test_degree_is_a_property_of_geometry_not_count(self):
        """Section VII-C: "Feasibility is a property of the geometry".

        Ten directions drawn at random support no angular information, while a
        well-spread set of the same size can.  This is why step (13) does real
        work: it stops the lifting claiming a degree the protocol cannot support.
        """
        rng = np.random.default_rng(3)
        random_degrees = []
        for _ in range(6):
            g = rng.normal(size=(10, 3))
            g /= np.linalg.norm(g, axis=1, keepdims=True)
            random_degrees.append(exact_degree(g, l_max=8))
        assert max(random_degrees) <= 2
        assert exact_degree(electrostatic_directions(90, seed=1), l_max=8) == 8

    def test_degree_8_needs_45_moment_conditions(self):
        """Section VII-C: exactness to degree 8 requires 45 moment conditions."""
        assert n_coeff(8) == 45
        assert exact_degree(electrostatic_directions(46, seed=1), l_max=8) == 8

    def test_bound_is_governed_by_the_smallest_degree(self, tensor_protocol, small_config):
        """Section VII-C: the bound follows ``min_p L_p``, not the measurement count.

        A protocol can be far better sampled than its guarantee suggests when one
        of its shells is sparse, so the quadrature degree is what belongs beside
        a result.
        """
        prep = prepare_input(tensor_protocol, small_config)
        assert prep.min_degree == min(prep.degrees)
        assert prep.min_degree <= max(prep.degrees)

    def test_discrepancy_falls_with_degree(self, small_model, small_config, patch_positions):
        """The falsifiable part: discrepancy decreases as quadrature degree rises.

        Compares estimates from direction subsets against the full 90-direction
        estimate, on noise-free data, as Section VIII-C does.
        """
        from equal.data.insilico import generate_field
        from equal.data.protocols import hcp_ya_protocol
        from equal.losses import sliced_wasserstein2

        full = hcp_ya_protocol(n_dir=90, seed=0)
        field = generate_field(full, shape=(3, 3, 3), snr=None, seed=0)
        geo = small_model.build_geometry(field.positions)

        def estimate(proto, idxs):
            prep = prepare_input(proto, small_config)
            sigs, c, k = [], 0, 0
            for s in full.shells:
                if s.is_b0:
                    c += s.n_directions
                    continue
                sigs.append(torch.as_tensor(
                    field.signals[:, c : c + s.n_directions][:, idxs[k]],
                    dtype=torch.float32))
                c += s.n_directions
                k += 1
            with torch.no_grad():
                return small_model(sigs, prep, geo)

        from equal.data.protocols import farthest_point_subset

        nz = [s for s in full.shells if not s.is_b0]
        ref = estimate(full, [np.arange(s.n_directions) for s in nz])
        discrepancies, degrees = [], []
        for n in (10, 28, 45):
            # Select for spread, and PER SHELL: an arbitrary slice can be
            # clustered, in which case its quadrature degree is lower than a
            # smaller spread subset's, and indices chosen on one shell are an
            # arbitrary selection on another shell's different gradient table.
            idxs = [farthest_point_subset(s.directions, n, seed=0) for s in nz]
            sub = Protocol(
                [Shell(0.0, "LTE", np.array([[0.0, 0.0, 1.0]]))]
                + [Shell(s.b, s.shape, s.directions[i]) for s, i in zip(nz, idxs)]
            )
            prep = prepare_input(sub, small_config)
            degrees.append(prep.min_degree)
            with torch.no_grad():
                d = sliced_wasserstein2(estimate(sub, idxs), ref, n_projections=128).mean()
            discrepancies.append(float(d))

        assert degrees == sorted(degrees), f"degrees not monotone: {degrees}"
        assert degrees[-1] > degrees[0], f"degree did not vary: {degrees}"
        # Theorem 2's falsifiable content: the discrepancy from the full-protocol
        # estimate does not grow as the quadrature degree rises.
        assert discrepancies[-1] <= discrepancies[0] * 1.5, (
            f"discrepancy {discrepancies} rose with degree {degrees}"
        )


# ---------------------------------------------------------------- Theorem 3
class TestTheorem3Recoverability:
    def test_band_limited_shell_signal_is_recovered(self):
        """(i): the linear channel recovers a signal band-limited to ``L_p/2``.

        With ``phi_1(s, gamma) = s`` and an exact rule to degree ``L_p``, a shell
        signal of degree at most ``floor(L_p/2)`` has ``s Y_lm`` of degree at
        most ``L_p``, so the rule returns its SH coefficients without error --
        and those determine the signal.
        """
        g = electrostatic_directions(90, seed=1)
        rule = build_rule(g, l_max=8)
        assert rule.degree == 8
        half = rule.degree // 2
        rng = np.random.default_rng(0)
        c = rng.normal(size=n_coeff(half))
        s = real_sh(half, g) @ c                       # band-limited to degree 4
        # The lift at l <= half, with the linear channel, is sum_i w_i s_i Y_lm(g_i)
        Y = real_sh(rule.degree, g)
        recovered = np.einsum("i,i,ic->c", rule.weights, s, Y)[: n_coeff(half)]
        assert np.abs(recovered - c).max() < 1e-9

    def test_finite_atoms_approximate_a_continuous_measure(self):
        """(ii): an existence statement, with no rate.

        The decoder fixes ``K = 8``, so the theorem is not a statement about the
        implemented model; Section VII-D measures the gap instead of assuming it
        away.  Here we check the direction of the statement: more atoms cannot
        do worse at matching a continuous measure's signal.
        """
        rng = np.random.default_rng(0)
        n = rng.normal(size=(2000, 3))
        n /= np.linalg.norm(n, axis=1, keepdims=True)
        d = 2.0e-3
        target = TensorDistribution(np.full(2000, 1 / 2000), d * np.einsum("ki,kj->kij", n, n))
        B = np.stack([b_tensor(b, gi, s)
                      for b in (700.0, 1400.0, 2000.0)
                      for gi in electrostatic_directions(20, seed=2)
                      for s in (1.0, -0.5, 0.0)])
        ref = target.signal(B)

        errs = {}
        for K in (1, 4, 16):
            idx = np.linspace(0, 1999, K).astype(int)
            approx = TensorDistribution(np.full(K, 1 / K), target.tensors[idx])
            errs[K] = float(np.abs(approx.signal(B) - ref).max())
        assert errs[16] < errs[1]

    def test_no_universality_claim_at_fixed_degree(self):
        """Section VII-A is explicit that the encoder is not claimed universal.

        Available universality results for equivariant point-cloud networks
        require the degree or the width to grow, so nothing here should assert
        exact representation at fixed ``L``.  Guarded by reading the docstring,
        which is the only place such a claim could creep back in.
        """
        from equal import model

        assert "universal" not in model.EQUAL.__doc__.lower()


# ---------------------------------------------------------------- Theorem 4
class TestTheorem4PhysicalValidity:
    """Exact, for every value of Theta.  Nothing here is trained."""

    def test_decoded_measure_is_a_probability_measure_on_T(
        self, small_model, small_config, hcp_protocol, patch_positions, signals
    ):
        mu = forward(small_model, small_config, hcp_protocol, patch_positions, signals)
        assert float((mu.weights.sum(1) - 1).abs().max()) < 1e-5
        assert float(mu.weights.min()) >= 0.0
        ev = torch.linalg.eigvalsh(mu.tensors)
        assert float(ev.min()) >= -1e-9
        assert float(ev.max()) <= D_FREE_WATER + 1e-9

    def test_violation_rate_is_identically_zero(
        self, small_model, small_config, hcp_protocol, patch_positions, signals
    ):
        """Equation (39) on the test set of Section VI-C.3.

        Zero is an arithmetic consequence of (24) being a convex combination of
        completely monotone exponentials, not an empirical finding.
        """
        mu = forward(small_model, small_config, hcp_protocol, patch_positions, signals)
        unit_B, b_grid = validity_test_set(n_lte=16, n_pte=16, n_b=60)

        def signal_fn(B_stack):
            with torch.no_grad():
                return mu.signal(torch.as_tensor(B_stack, dtype=torch.float32)).numpy()

        rep = violation_rate(signal_fn, mu.n_voxels, unit_B, b_grid)
        assert rep.rate == 0.0, str(rep)

    def test_signal_is_bounded_and_decays(self, rng):
        """``E(0) = 1`` and ``0 < E(B) <= 1``, with complete monotonicity in b."""
        K = 6
        w = rng.random(K)
        w /= w.sum()
        D = []
        for _ in range(K):
            A = rng.normal(size=(3, 3))
            S = A @ A.T
            S *= 2.0e-3 / np.linalg.eigvalsh(S).max()
            D.append(S)
        mu = TensorDistribution(w, np.stack(D))
        assert abs(mu.signal(np.zeros((3, 3))) - 1.0) < 1e-12
        for shape in (1.0, -0.5, 0.0):
            bs = np.linspace(0, 2e4, 400)
            E = np.array([mu.signal(b_tensor(b, np.array([0.0, 0.0, 1.0]), shape)) for b in bs])
            assert np.all(E > 0) and np.all(E <= 1.0 + 1e-12)
            assert np.all(np.diff(E) <= 1e-12)            # first order
            assert np.all(np.diff(E, 2) >= -1e-12)        # second order

    def test_unconstrained_decoder_can_violate(self, rng):
        """The ablation that carries the information (Table XIV).

        An unconstrained signal head has nothing stopping it from rising with b;
        this is what puts 6.41% of voxels outside the admissible set when only
        the decoder is replaced.
        """
        bs = np.linspace(0, 2e4, 200)
        # A direct MLP is free to produce any smooth curve, e.g. one that rises.
        unconstrained = 0.4 + 0.1 * np.sin(bs / 2e3)
        assert np.any(np.diff(unconstrained) > 0)


# ---------------------------------------------------------------- Theorem 5
class TestTheorem5Identifiability:
    """Exact, but conditional on the signal model (2) and noise-free data."""

    def test_sticks_and_isotropic_spreads_share_every_lte_signal(self):
        """(ii), the closed-form example, with the STE signals the paper gives.

        ``mu_s`` (sticks ``d n n^T``, n uniform) and ``mu_i`` (isotropic
        ``lambda I``, ``lambda = d u^2``, ``u ~ U(0,1)``) produce identical LTE
        signals for every b and g, but STE signals ``e^{-bd/3}`` and
        ``int_0^1 e^{-b d u^2} du`` respectively.
        """
        from scipy.integrate import quad

        d, K = 2.0e-3, 40000
        rng = np.random.default_rng(0)
        n = rng.normal(size=(K, 3))
        n /= np.linalg.norm(n, axis=1, keepdims=True)
        mu_s = TensorDistribution(np.full(K, 1 / K), d * np.einsum("ki,kj->kij", n, n))
        u = rng.uniform(0, 1, K)
        mu_i = TensorDistribution(np.full(K, 1 / K),
                                  np.einsum("k,ij->kij", d * u**2, np.eye(3)))

        g = electrostatic_directions(60, seed=2)
        for b in (500.0, 1000.0, 2000.0, 3000.0):
            B_lte = np.stack([b_tensor(b, gi, 1.0) for gi in g])
            # Equal up to Monte Carlo error at K samples.
            assert abs(mu_s.signal(B_lte).mean() - mu_i.signal(B_lte).mean()) < 5e-3
            B_ste = b_tensor(b, g[0], 0.0)
            assert abs(mu_s.signal(B_ste) - np.exp(-b * d / 3)) < 1e-12
            closed = quad(lambda x: np.exp(-b * d * x * x), 0, 1)[0]
            assert abs(mu_i.signal(B_ste) - closed) < 5e-3

    def test_mufa_is_one_for_sticks_and_zero_for_isotropic(self):
        """Equation (26) at its two defining limits."""
        from equal.decoder import DecodedMeasure

        rng = np.random.default_rng(1)
        K = 2000
        n = rng.normal(size=(K, 3))
        n /= np.linalg.norm(n, axis=1, keepdims=True)
        sticks = torch.as_tensor(2.0e-3 * np.einsum("ki,kj->kij", n, n))[None]
        iso = torch.as_tensor(
            np.einsum("k,ij->kij", rng.uniform(0.2e-3, 2e-3, K), np.eye(3)))[None]
        w = torch.full((1, K), 1.0 / K, dtype=torch.float64)
        assert abs(float(micro_fa(DecodedMeasure(w, sticks))) - 1.0) < 1e-6
        assert abs(float(micro_fa(DecodedMeasure(w, iso)))) < 1e-6

    def test_single_shell_free_water_is_not_identifiable(self):
        """(iii): a continuum of ``(f, lambda)`` matches one shell exactly."""
        b, d_fw = 1000.0, D_FREE_WATER
        E = 0.5
        matches = []
        for f in np.linspace(0.05, 0.45, 9):
            inner = (E - f * np.exp(-b * d_fw)) / (1 - f)
            if 0 < inner < 1:
                lam = -np.log(inner) / b
                if 0 < lam < d_fw:
                    got = f * np.exp(-b * d_fw) + (1 - f) * np.exp(-b * lam)
                    assert abs(got - E) < 1e-12
                    matches.append((f, lam))
        assert len(matches) >= 5, "expected a continuum of exact matches"

    def test_rule_matches_table_iii(self, hcp_protocol, tensor_protocol):
        """The flags Table III and Section VIII-E state for each protocol class."""
        hcp = identifiability_map(hcp_protocol).as_dict()
        assert hcp["FW"] == "identified"
        assert hcp["MD"] == "identified"
        assert hcp["muFA"] == "prior-driven"      # LTE only, at any density

        tv = identifiability_map(tensor_protocol).as_dict()
        assert tv["muFA"] == "identified"         # LTE + PTE/STE at >= 2 b-values

        clinical = identifiability_map(single_shell_protocol(1000.0, 30)).as_dict()
        assert clinical["FW"] == "prior-driven"
        assert clinical["MD"] == "approximate"

    def test_rule_reads_the_protocol_alone(self, hcp_protocol):
        """It must be evaluable before a scan exists, so it takes no image data."""
        with pytest.raises(TypeError):
            identifiability_map({"b": [1000.0]})
        # and it has no trainable parameters to carry state between calls
        a = identifiability_map(hcp_protocol).as_dict()
        b = identifiability_map(hcp_protocol).as_dict()
        assert a == b


# ---------------------------------------------------------------- Theorem 6
class TestTheorem6Extrapolation:
    def test_exponential_sum_zero_count(self, rng):
        """(i): an m-term exponential sum has at most m-1 real zeros."""
        for m in (2, 3, 4):
            lam = np.sort(rng.uniform(0.1, 3.0, m))
            c = rng.normal(size=m)
            b = np.linspace(0, 20, 20000)
            f = (c * np.exp(-np.outer(b, lam))).sum(1)
            crossings = int(np.sum(np.sign(f[:-1]) != np.sign(f[1:])))
            assert crossings <= m - 1

    def test_bound_equals_eps_at_bmax(self):
        for eps in (0.05, 0.01, 0.001):
            assert abs(float(divergence_bound(1.0, eps, mask_trivial=False)) - eps) < 1e-12

    def test_crossing_points_match_the_manuscript(self):
        """3.4, 4.9 and 7.0, quoted in the Section V remark and Fig. 5(b).

        These fix the reading of (35); ``audit/audit.py`` separately records that
        Table XIV's bound row does not follow from the same formula.
        """
        for eps, want in ((0.05, 3.4), (0.01, 4.9), (0.001, 7.0)):
            assert abs(trivial_crossing_ratio(eps) - want) < 0.05

    def test_bound_is_masked_where_it_is_trivial(self):
        """Past the crossing the bound exceeds 1 and says nothing, so it is not
        reported -- Section VIII-D plots it only below that value."""
        assert np.isnan(float(divergence_bound(6.0, 0.01)))
        assert not np.isnan(float(divergence_bound(3.0, 0.01)))

    def test_bound_is_monotone_in_ratio_and_eps(self):
        r = np.linspace(1.0, 4.5, 40)
        v = divergence_bound(r, 0.01, mask_trivial=False)
        assert np.all(np.diff(v) > 0)                     # grows with b*
        assert float(divergence_bound(2.0, 0.001, mask_trivial=False)) < float(
            divergence_bound(2.0, 0.05, mask_trivial=False))
