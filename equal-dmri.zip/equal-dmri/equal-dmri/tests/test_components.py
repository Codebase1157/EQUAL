"""Component tests: quadrature, lifting, losses, metrics, statistics, masking."""

from __future__ import annotations

import numpy as np
import pytest
import torch

from equal.data.protocols import (
    Protocol, Shell, b_tensor, electrostatic_directions, hcp_ya_protocol,
    single_shell_protocol, tensor_valued_protocol,
)
from equal.decoder import DecodedMeasure
from equal.lifting import B_REF, b_tensor_descriptor, descriptor_dim
from equal.losses import _w2_1d, mandel_vector, rician_nll_loss, sliced_wasserstein2
from equal.masking import MaskingDistribution, apply_mask
from equal.metrics import leakage_decomposition, nrmse, optimism_gap
from equal.quadrature import build_rule, is_degree_feasible, solve_minimum_norm_weights
from equal.sh import n_coeff, random_rotation, real_sh
from equal.sh_torch import fit_residual, real_sh_torch
from equal.signal_model import D_FREE_WATER, TensorDistribution, rician_nll
from equal.stats import (
    aggregate_seeds, bootstrap_ci, holm_bonferroni, ordinal_auc,
    paired_comparison, wilson_interval,
)


class TestQuadrature:
    def test_weights_are_nonnegative_and_sum_to_sphere_area(self):
        for n in (10, 30, 90):
            r = build_rule(electrostatic_directions(n, seed=0), l_max=8)
            assert np.all(r.weights >= 0)
            assert abs(r.weights.sum() - 4 * np.pi) < 1e-9

    def test_dual_matches_a_general_purpose_qp(self):
        """Cross-check the dual solver against SLSQP on the same problem."""
        from scipy.optimize import minimize

        from equal.sh import sh_integral_vector

        g = electrostatic_directions(46, seed=1)
        ell = 6
        w, _ = solve_minimum_norm_weights(g, ell)
        Phi, t = real_sh(ell, g), sh_integral_vector(ell)
        res = minimize(
            lambda x: x @ x, np.full(46, 4 * np.pi / 46), jac=lambda x: 2 * x,
            bounds=[(0, None)] * 46, method="SLSQP",
            constraints=[{"type": "eq", "fun": lambda x: Phi.T @ x - t,
                          "jac": lambda x: Phi.T}],
            options={"maxiter": 1000, "ftol": 1e-16},
        )
        assert abs(float(w @ w) - float(res.x @ res.x)) < 1e-9

    def test_infeasible_degree_raises_rather_than_returning_garbage(self):
        """An inexact rule would void Theorem 2's hypothesis silently."""
        rng = np.random.default_rng(0)
        g = rng.normal(size=(8, 3))
        g /= np.linalg.norm(g, axis=1, keepdims=True)
        assert not is_degree_feasible(g, 8)
        with pytest.raises(RuntimeError, match="Theorem 2"):
            solve_minimum_norm_weights(g, 8, tol=1e-9)

    def test_spherical_shell_gets_degree_zero(self):
        """STE has no direction, so it contributes only to l = 0."""
        r = build_rule(electrostatic_directions(20, seed=0), l_max=8,
                       shape_is_spherical=True)
        assert r.degree == 0 and r.is_isotropic_only
        assert np.allclose(r.weights, r.weights[0])


class TestDescriptor:
    def test_shape_and_reference(self):
        g = b_tensor_descriptor(1000.0, 1.0)
        assert g.shape == (1, descriptor_dim(8))
        assert abs(g[0, 0] - 1000.0 / B_REF) < 1e-12
        assert abs(g[0, 1] - 1.0) < 1e-12

    def test_continuity_in_b_and_shape(self):
        """An unseen b-value is a nearby point, not an absent symbol."""
        a = b_tensor_descriptor(1999.0, 1.0)
        b = b_tensor_descriptor(2001.0, 1.0)
        assert np.abs(a - b).max() < 0.05
        for shape in (-0.5, 0.0, 1.0):
            assert np.isfinite(b_tensor_descriptor(5000.0, shape)).all()

    def test_distinguishes_the_three_encodings_at_equal_b(self):
        """Fig. 15: three images at identical b and tissue differ by shape alone."""
        d = [b_tensor_descriptor(2000.0, s)[0] for s in (1.0, -0.5, 0.0)]
        for i in range(3):
            for j in range(i + 1, 3):
                assert np.abs(d[i] - d[j]).max() > 0.1


class TestTorchSH:
    def test_matches_the_numpy_basis_exactly(self):
        assert fit_residual(8) < 1e-9
        rng = np.random.default_rng(0)
        g = rng.normal(size=(200, 3))
        g /= np.linalg.norm(g, axis=1, keepdims=True)
        a = real_sh(8, g)
        b = real_sh_torch(8, torch.as_tensor(g, dtype=torch.float64)).numpy()
        assert np.abs(a - b).max() < 1e-9

    def test_is_differentiable(self):
        g = torch.randn(5, 3, dtype=torch.float64, requires_grad=True)
        real_sh_torch(8, g).sum().backward()
        assert g.grad is not None and torch.isfinite(g.grad).all()


class TestLosses:
    def test_w2_matches_brute_force_on_equal_weights(self):
        rng = np.random.default_rng(0)
        for _ in range(5):
            a = np.sort(rng.normal(size=6))
            b = np.sort(rng.normal(size=6))
            w = torch.full((1, 6), 1 / 6, dtype=torch.float64)
            got = float(_w2_1d(torch.tensor(a)[None], w, torch.tensor(b)[None], w)[0])
            assert abs(got - float(((a - b) ** 2).mean())) < 1e-12

    def test_w2_matches_exact_optimal_transport_with_unequal_weights(self):
        """Cross-check against the linear program the transport problem really is.

        The quantile construction in ``_w2_1d`` is exact only if the sorted
        coupling is optimal, which it is in one dimension.  Solving the full
        transport LP independently -- with unequal weights *and* unequal atom
        counts, where a sorted pairing is not even well defined -- is the
        strongest available check that the implementation is not quietly
        computing something else.
        """
        from scipy.optimize import linprog

        rng = np.random.default_rng(5)
        for _ in range(4):
            na, nb = 4, 5
            a, b = np.sort(rng.normal(size=na)), np.sort(rng.normal(size=nb))
            wa = rng.random(na); wa /= wa.sum()
            wb = rng.random(nb); wb /= wb.sum()
            C = ((a[:, None] - b[None, :]) ** 2).ravel()
            rows, rhs = [], []
            for i in range(na):
                r = np.zeros((na, nb)); r[i, :] = 1
                rows.append(r.ravel()); rhs.append(wa[i])
            for j in range(nb):
                r = np.zeros((na, nb)); r[:, j] = 1
                rows.append(r.ravel()); rhs.append(wb[j])
            lp = linprog(C, A_eq=np.array(rows), b_eq=np.array(rhs),
                         bounds=[(0, None)] * (na * nb), method="highs")
            got = float(_w2_1d(torch.tensor(a)[None], torch.tensor(wa)[None],
                               torch.tensor(b)[None], torch.tensor(wb)[None])[0])
            assert abs(got - lp.fun) < 1e-12

    def test_w2_of_a_translation(self):
        rng = np.random.default_rng(1)
        a, w = rng.normal(size=5), rng.random(5)
        w /= w.sum()
        got = float(_w2_1d(torch.tensor(a)[None], torch.tensor(w)[None],
                           torch.tensor(a + 0.7)[None], torch.tensor(w)[None])[0])
        assert abs(got - 0.49) < 1e-10

    def test_mandel_is_an_isometry(self):
        rng = np.random.default_rng(2)
        D = rng.normal(size=(20, 3, 3))
        D = torch.as_tensor(D + D.transpose(0, 2, 1))
        assert float((mandel_vector(D).pow(2).sum(-1)
                      - D.pow(2).sum((-1, -2))).abs().max()) < 1e-10

    def test_consistency_loss_is_invariant_to_atom_order(self):
        """(30) is defined on measures, so relabelling must not change it."""
        rng = np.random.default_rng(3)
        w = torch.as_tensor(rng.dirichlet(np.ones(5))[None])
        D = torch.as_tensor(rng.normal(size=(1, 5, 3, 3)) * 1e-3)
        D = D + D.transpose(-1, -2)
        w2 = torch.as_tensor(rng.dirichlet(np.ones(5))[None])
        D2 = torch.as_tensor(rng.normal(size=(1, 5, 3, 3)) * 1e-3)
        D2 = D2 + D2.transpose(-1, -2)
        p = torch.randperm(5)
        g = lambda s: torch.Generator().manual_seed(s)
        base = float(sliced_wasserstein2(DecodedMeasure(w, D), DecodedMeasure(w2, D2),
                                         512, g(0)).mean())
        perm = float(sliced_wasserstein2(DecodedMeasure(w[:, p], D[:, p]),
                                         DecodedMeasure(w2, D2), 512, g(0)).mean())
        assert abs(base - perm) < 1e-12

    def test_rician_loss_is_finite_at_high_snr(self):
        """log I_0 must stay finite for large arguments (Section IV-F)."""
        p = torch.full((2, 3), 0.9)
        t = torch.full((2, 3), 0.9)
        v = rician_nll_loss(p, t, torch.full((2, 1), 1e-4))
        assert torch.isfinite(v)

    def test_rician_loss_agrees_with_the_numpy_reference(self):
        rng = np.random.default_rng(4)
        s = rng.uniform(0.1, 0.9, (3, 5))
        nu = rng.uniform(0.1, 0.9, (3, 5))
        sig = np.full((3, 1), 0.05)
        a = float(rician_nll(s, nu, sig).mean())
        b = float(rician_nll_loss(torch.as_tensor(nu), torch.as_tensor(s),
                                  torch.as_tensor(sig)))
        assert abs(a - b) < 1e-9


class TestMasking:
    def test_observed_and_held_out_never_overlap(self):
        """The property that makes (9) leakage-free."""
        rng = np.random.default_rng(0)
        m = MaskingDistribution()
        proto = tensor_valued_protocol(b_values=(700.0, 1400.0), n_lte=12,
                                       n_pte=12, n_ste=6)
        for _ in range(60):
            out = m.draw(proto, rng)
            assert not set(out.observed) & set(out.held_out)
            assert out.held_out.size > 0

    def test_direction_masking_keeps_six_per_shell(self):
        rng = np.random.default_rng(1)
        m = MaskingDistribution(1.0, 0.0, 0.0)
        proto = hcp_ya_protocol(n_dir=30, seed=0)
        for _ in range(30):
            obs = apply_mask(proto, m.draw(proto, rng))
            for s in obs.nonzero_shells():
                assert s.n_directions >= 6

    def test_unavailable_operations_move_their_mass(self):
        """A single-shell LTE protocol supports direction masking only."""
        rng = np.random.default_rng(2)
        m = MaskingDistribution()
        proto = single_shell_protocol(1000.0, 30)
        ops = {m.draw(proto, rng).operation for _ in range(50)}
        assert ops == {"a"}

    def test_observed_subset_is_a_complete_protocol(self):
        """``X_O`` must be a smaller but complete protocol in its own right."""
        rng = np.random.default_rng(3)
        proto = hcp_ya_protocol(n_dir=30, seed=0)
        obs = apply_mask(proto, MaskingDistribution().draw(proto, rng))
        assert obs.n_shells >= 1
        build_rule(obs.nonzero_shells()[0].directions, l_max=8)   # must not raise


class TestMetrics:
    def test_nrmse_is_zero_for_a_perfect_prediction(self):
        x = np.array([0.5, 0.3, 0.8])
        assert nrmse(x, x) == 0.0

    def test_optimism_gap_and_its_decomposition(self):
        """Section VIII-B: 0.0228 gap, 27% smoothing, 3.7:1 margin."""
        gap = optimism_gap(0.0574, 0.0346)
        assert abs(gap - 0.0228) < 1e-9
        d = leakage_decomposition(gap, 0.0062)
        assert abs(d["smoothing_share"] - 0.272) < 0.01
        assert abs(d["ratio"] - 3.68) < 0.02

    def test_a_positive_gap_alone_is_not_leakage(self):
        """An oracle gap equal to the measured gap leaves no leakage."""
        d = leakage_decomposition(0.0062, 0.0062)
        assert abs(d["leakage"]) < 1e-12


class TestStatistics:
    def test_seeds_are_averaged_before_testing(self):
        v = np.array([[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]])     # (3 seeds, 2 units)
        assert np.allclose(aggregate_seeds(v), [3.0, 4.0])

    def test_seed_axis_guard(self):
        """Passing the unit axis by mistake must fail loudly."""
        with pytest.raises(ValueError, match="unit axis"):
            aggregate_seeds(np.zeros((94, 3)))

    def test_wilson_reproduces_table_xvii(self):
        for k, n, lo_w, hi_w in [(4, 306, 0.005, 0.033), (12, 238, 0.029, 0.086),
                                 (6, 268, 0.010, 0.048), (9, 252, 0.019, 0.066)]:
            lo, hi = wilson_interval(k, n)
            assert abs(lo - lo_w) < 0.002 and abs(hi - hi_w) < 0.002

    def test_ordinal_auc_counts_ties_one_half(self):
        scores = np.array([0, 1, 2, 1, 0])
        labels = np.array([False, True, True, False, False])
        pos, neg = scores[labels], scores[~labels]
        brute = sum((1.0 if p > n else 0.5 if p == n else 0.0)
                    for p in pos for n in neg) / (len(pos) * len(neg))
        assert abs(ordinal_auc(scores, labels) - brute) < 1e-12

    def test_no_significance_claim_for_spatial_blocks(self):
        rng = np.random.default_rng(0)
        r = paired_comparison(rng.normal(size=64), rng.normal(size=64),
                              "tensor-valued", unit="spatial_block")
        assert r.p_value is None and not r.significance_claimed
        assert r.ci[0] < r.ci[1]

    def test_holm_is_monotone_and_never_decreases_p(self):
        rng = np.random.default_rng(1)
        res = [paired_comparison(np.full(20, 0.05),
                                 np.full(20, 0.05) + d + rng.normal(0, 1e-4, 20), f"m{i}")
               for i, d in enumerate([0.001, 0.005, 0.0001, 0.02])]
        adj = holm_bonferroni(res)
        for r in adj:
            assert r.p_adjusted >= r.p_value - 1e-12
            assert r.p_adjusted <= 1.0

    def test_paired_bootstrap_resamples_pairs(self):
        """The 46 retest pairs must be resampled as pairs, not as scans."""
        rng = np.random.default_rng(2)
        a = rng.normal(size=46)
        b = a + 0.1                                 # a perfectly constant difference
        lo, hi = bootstrap_ci(np.stack([b, a], axis=1), paired=True, seed=0)
        assert abs(lo - 0.1) < 1e-9 and abs(hi - 0.1) < 1e-9
