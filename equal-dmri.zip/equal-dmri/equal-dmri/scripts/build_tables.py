#!/usr/bin/env python3
"""Regenerate every table from results/results.json.

Everything in the paper is generated from one file, so replacing an illustrative
value with a measured one regenerates the tables that use it.  This script is
that regeneration step.

Placeholders are marked with a dagger.  The audit leaves the decision to label
illustrative values *in the manuscript* to the authors; in generated output the
default is to label them, because an unmarked placeholder in a table is
indistinguishable from a measurement.  ``--no-marks`` removes them, and prints a
warning saying what has just been hidden.

    python scripts/build_tables.py                 # markdown to stdout
    python scripts/build_tables.py --out docs/TABLES.md
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from equal.results import ResultStore  # noqa: E402
from equal.theory import divergence_bound  # noqa: E402

METHODS = ["SH_interp", "MAP_MRI", "SHARD", "SH_CNN", "SH_sCNN", "S_CNN",
           "E3xSO3", "UPER", "D_RoPE", "PIGMENT", "EQUAL", "EQUAL_D"]
SOURCES = ["HCP_YA", "MASiVar_A", "MASiVar_P", "ON_Harmony", "CDMD",
           "tensor_valued", "in_silico"]
SOURCE_ROLE = {"HCP_YA": "in-dist.", "MASiVar_A": "in-dist.", "MASiVar_P": "shifted",
               "ON_Harmony": "zero-shot", "CDMD": "zero-shot",
               "tensor_valued": "zero-shot", "in_silico": "held-out"}


def _row(cells: list[str]) -> str:
    return "| " + " | ".join(cells) + " |"


def _sep(n: int) -> str:
    return "|" + "|".join([" --- "] * n) + "|"


def table9(s: ResultStore, mark: bool) -> str:
    out = ["### Table IX - Signal prediction on HCP-YA at 30% direction masking",
           "",
           "NRMSE against raw held-out measurements. Unit of analysis: the subject "
           "(94 test subjects).",
           "",
           _row(["Method", "White matter", "Gray matter", "CSF"]), _sep(4)]
    for m in METHODS:
        k = f"table9.{m}"
        if f"{k}.white_matter" not in s:
            continue
        out.append(_row([m] + [s.format_value(f"{k}.{t}", "{:.4f}", mark)
                               for t in ("white_matter", "gray_matter", "csf")]))
    return "\n".join(out)


def table10(s: ResultStore, mark: bool) -> str:
    out = ["### Table X - White-matter NRMSE across the eight evaluation sources",
           "",
           '"n/a" is **not** a missing measurement: it marks a method that cannot '
           "represent the input at all.",
           "",
           _row(["Method"] + SOURCES), _sep(1 + len(SOURCES)),
           _row([""] + [f"*{SOURCE_ROLE[x]}*" for x in SOURCES])]
    for m in METHODS + ["QTI"]:
        cells = []
        any_present = False
        for src in SOURCES:
            k = f"table10.{m}.{src}"
            if k in s:
                any_present = True
                v = s.value_of(k)
                cells.append("n/a" if v == "n/a" else s.format_value(k, "{:.4f}", mark))
            else:
                cells.append("")
        if any_present:
            out.append(_row([m] + cells))
    out.append(_row(["*applicable baselines*"]
                    + [str(s.value_of(f"table10.applicable_baselines.{x}"))
                       + " of 11" for x in SOURCES]))
    out.append(_row(["*best baseline*"]
                    + [str(s.value_of(f"table10.best_baseline.{x}")) for x in SOURCES]))
    gains = []
    for src in SOURCES:
        best = s.value_of(f"table10.best_baseline.{src}")
        bv = float(s.value_of(f"table10.{best}.{src}"))
        e = float(s.value_of(f"table10.EQUAL.{src}"))
        gains.append(f"{(bv - e) / bv * 100:.1f}")
    out.append(_row(["*gain of EQUAL (%)*"] + gains))
    out.append("")
    out.append("The gain row is **computed** from the two values above it, never typed.")
    return "\n".join(out)


def table11(s: ResultStore, mark: bool) -> str:
    axes = [("new_directions", "New directions", "directions, shells fixed"),
            ("unseen_b", "Unseen b-values", "b beyond the training range"),
            ("encoding_shape", "Encoding shape", "planar and spherical b-tensors"),
            ("scanner_site", "Scanner and site", "vendor, site, gradient hardware")]
    out = ["### Table XI - Generalization reported one acquisition axis at a time",
           "",
           "Only the first row holds everything else fixed, and only the first row "
           "is a test of Theorem 2. The other three are extrapolation in the "
           "continuous descriptor (14), about which the theory says nothing.",
           "",
           _row(["Axis", "What changes", "Reduction (%)", "95% CI", "Cohen's d",
                 "Comparator", "Thm 2 covers it?"]), _sep(7)]
    for key, label, change in axes:
        v = s.get(f"table11.{key}.reduction_pct")
        ci = f"({v.ci[0]}, {v.ci[1]})" if v.ci else "--"
        out.append(_row([
            label, change,
            s.format_value(f"table11.{key}.reduction_pct", "{:.1f}", mark), ci,
            s.format_value(f"table11.{key}.cohens_d", "{:.2f}", mark),
            str(s.value_of(f"table11.{key}.comparator")),
            "yes" if s.value_of(f"table11.{key}.theorem2_covers") else "no",
        ]))
    return "\n".join(out)


def table12(s: ResultStore, mark: bool) -> str:
    out = ["### Table XII - The optimism of grid-referenced self-supervision",
           "",
           _row(["Model", "vs. own resampled reference", "vs. raw held-out",
                 "Optimism gap", "Share of reported error"]), _sep(5)]
    for m in ("UPER", "D_RoPE", "SH_sCNN"):
        raw = float(s.value_of(f"table12.{m}.vs_raw"))
        gap = float(s.value_of(f"table12.{m}.optimism_gap"))
        out.append(_row([
            m, s.format_value(f"table12.{m}.vs_own_reference", "{:.4f}", mark),
            s.format_value(f"table12.{m}.vs_raw", "{:.4f}", mark),
            s.format_value(f"table12.{m}.optimism_gap", "{:.4f}", mark),
            f"{gap / raw * 100:.1f}%",
        ]))
    out.append(_row(["*oracle (noise-free)*", "--",
                     s.format_value("table12.oracle.gap", "{:.4f}", mark),
                     s.format_value("table12.oracle.gap", "{:.4f}", mark), "--"]))
    out.append(_row(["**EQUAL**", "not applicable",
                     s.format_value("table12.EQUAL.vs_raw", "{:.4f}", mark),
                     "0", "--"]))
    gap = float(s.value_of("table12.UPER.optimism_gap"))
    orc = float(s.value_of("table12.oracle.gap"))
    out += ["", f"Decomposition for UPER: {orc / gap:.0%} of the gap is interpolation "
                f"smoothing, the remaining {1 - orc / gap:.0%} is leakage; a margin of "
                f"{gap / orc:.1f} to one. EQUAL builds no resampled reference at any "
                f"stage, so no gap is defined for it."]
    return "\n".join(out)


def table14(s: ResultStore, mark: bool) -> str:
    ratios = [1.5, 2.0, 3.0, 4.0]
    out = ["### Table XIV - Physical validity and extrapolation",
           "",
           _row(["Method", "Violation rate (39), %"]), _sep(2)]
    for m in ("SH_interp", "MAP_MRI", "SHARD", "UPER", "D_RoPE", "PIGMENT",
              "EQUAL_direct_mlp", "EQUAL"):
        k = f"table14.{m}.violation_rate_pct"
        if k in s:
            out.append(_row([m, s.format_value(k, "{:.2f}", mark)]))
    out += ["", "**Extrapolation beyond the acquired b-range**", "",
            _row(["b*/b_max"] + [str(r) for r in ratios]), _sep(1 + len(ratios))]
    out.append(_row(["EQUAL NRMSE"]
                    + [s.format_value(f"table14.EQUAL.nrmse_at_ratio_{r}", "{:.3f}", mark)
                       for r in ratios]))
    out.append(_row(["divergence of two half-protocol fits"]
                    + [s.format_value(f"table14.half_protocol_divergence.ratio_{r}",
                                      "{:.3f}", mark) for r in ratios]))
    out.append(_row(["**Thm 6(ii) bound, eps=0.01, computed from (35)**"]
                    + [f"{float(divergence_bound(r, 0.01, mask_trivial=False)):.3f}"
                       for r in ratios]))
    out += ["",
            "The bound row is evaluated from equation (35), not transcribed. "
            "It reads `2^(1-omega) eps^omega` with `omega = (2/pi) arcsin(b_max/b*)`, "
            "the formula whose crossing points (3.438, 4.901, 7.005) reproduce the "
            "3.4 / 4.9 / 7.0 quoted in Section V and Fig. 5(b). "
            "**This disagrees with the bound row printed in the manuscript's Table XIV** "
            "(0.071 / 0.134 / 0.309 / 0.561); see `audit/audit.py`, check "
            "`thm6_bound_row`. The measured divergence stays inside the bound either way."]
    return "\n".join(out)


def table17(s: ResultStore, mark: bool) -> str:
    from equal.stats import wilson_interval

    out = ["### Table XVII - Quality of the identifiability flag beyond its AUC",
           "",
           _row(["Readout", "AUC", "95% CI", "False-confident rate",
                 "Wilson 95% CI"]), _sep(5)]
    for r in ("FW", "MD", "muFA", "FOD"):
        auc = s.get(f"table15.{r}.auc")
        k = int(s.value_of(f"table17.{r}.false_confident_count"))
        n = int(s.value_of(f"table17.{r}.false_confident_total"))
        lo, hi = wilson_interval(k, n)
        out.append(_row([
            r, s.format_value(f"table15.{r}.auc", "{:.3f}", mark),
            f"({auc.ci[0]}, {auc.ci[1]})" if auc.ci else "--",
            f"{k} / {n} = {k / n:.3f}", f"({lo:.3f}, {hi:.3f})",
        ]))
    out += ["", "The Wilson intervals are **computed** from the counts beside them."]
    return "\n".join(out)


def table20(s: ResultStore, mark: bool) -> str:
    ref = float(s.value_of("table20.input.raw_lifting.nrmse"))
    groups = [
        ("Input", "input.icosahedral_resampling", "input.raw_lifting", "optimism_gap"),
        ("Quadrature", "quadrature.uniform", "quadrature.exact_rule", "sw_slope"),
        ("Encoding", "encoding.one_hot", "encoding.continuous", "cdmd_zero_shot"),
        ("Linear channel", "linear_channel.removed", "linear_channel.kept",
         "band_limited_recovery_error"),
        ("Shell pooling", "pooling.mean", "pooling.attention", "shell_holdout_nrmse"),
        ("Backbone", "backbone.non_equivariant", "backbone.equivariant",
         "equivariance_error"),
        ("Symmetry group", "symmetry.product", "symmetry.joint",
         "on_harmony_fw_cov_pct"),
        ("Decoder", "decoder.direct_mlp", "decoder.laplace_measure",
         "violation_rate_pct"),
        ("Free-water atom", "fw_atom.none", "fw_atom.fixed", "scan_rescan_icc_fw"),
        ("Data term", "data_term.mse_adc", "data_term.rician_nll", "nrmse_b3000"),
        ("Consistency", "consistency.zero", "consistency.positive", "sw_at_L4"),
        ("Supervision", "supervision.distilled", "supervision.none", "fod_acc_hcp"),
    ]
    out = ["### Table XX - Ablations: one study per design choice",
           "",
           "The change column is **computed** as the difference from the reference "
           f"model ({ref:.4f}).",
           "",
           _row(["Component", "Variant", "NRMSE", "Change", "Targeted metric",
                 "Value"]), _sep(6)]
    for label, var, base, metric in groups:
        for key, tag in ((var, "variant"), (base, "**reference**")):
            v = float(s.value_of(f"table20.{key}.nrmse"))
            change = "ref." if tag.startswith("**") else f"{v - ref:+.4f}"
            out.append(_row([
                label if tag == "variant" else "",
                key.split(".", 1)[1].replace("_", " ") + (" (ref.)" if tag.startswith("**") else ""),
                s.format_value(f"table20.{key}.nrmse", "{:.4f}", mark), change,
                metric.replace("_", " "),
                s.format_value(f"table20.{key}.{metric}", "{:g}", mark),
            ]))
    return "\n".join(out)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--results", type=Path, default=ROOT / "results" / "results.json")
    ap.add_argument("--out", type=Path, default=None)
    ap.add_argument("--no-marks", action="store_true",
                    help="do not mark illustrative values (prints a warning)")
    a = ap.parse_args()

    if not a.results.exists():
        print(f"{a.results} not found. Run: python scripts/init_results.py")
        return 2
    s = ResultStore(a.results)
    mark = not a.no_marks
    ok, ph = s.is_submittable()

    header = [
        "# EQUAL - generated tables",
        "",
        f"Generated from `{a.results.name}` ({len(s)} values).",
        f"Provenance: {s.provenance_summary()}.",
        "",
    ]
    if not ok:
        header += [
            f"> **{len(ph)} of these values are illustrative placeholders.** EQUAL has "
            "not been trained or run, so no quantitative claim below is supported by "
            "evidence yet. Placeholders are marked with a dagger. Running the "
            "experiments and re-saving the store regenerates every table here.",
            "",
        ]
    if a.no_marks:
        header += ["> **Marks are suppressed.** "
                   f"{len(ph)} placeholders are now indistinguishable from "
                   "measurements in this document.", ""]

    body = "\n\n".join([
        table9(s, mark), table10(s, mark), table11(s, mark), table12(s, mark),
        table14(s, mark), table17(s, mark), table20(s, mark),
    ])
    text = "\n".join(header) + body + "\n"

    if a.out:
        a.out.parent.mkdir(parents=True, exist_ok=True)
        a.out.write_text(text)
        print(f"wrote {a.out}")
        if a.no_marks:
            print(f"WARNING: {len(ph)} placeholders were written unmarked.")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
