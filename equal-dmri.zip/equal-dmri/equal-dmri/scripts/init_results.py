#!/usr/bin/env python3
"""Create results/results.json with every value the manuscript reports.

Each value is labelled by where it came from.  The ones transcribed from the
present draft of Sections VIII and IX are labelled ILLUSTRATIVE, because the
audit records that EQUAL has not been implemented, trained or run and that those
numbers are placeholders held in a single file rather than measurements.

Running the experiments replaces the placeholders in place; everything in the
paper is generated from this file, so the tables, figures and sentences follow.

    python scripts/init_results.py            # write results/results.json
    python scripts/init_results.py --summary  # print the provenance breakdown
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from equal.results import ResultStore, external, illustrative, measured, theoretical  # noqa: E402
from equal.theory import divergence_bound, trivial_crossing_ratio  # noqa: E402

PLACEHOLDER = (
    "Placeholder transcribed from the current draft; EQUAL has not been trained "
    "or run, so this is not a measurement. Replaced by scripts/evaluate.py."
)

# Methods of Table IX / Table X, in the order the tables list them.
_METHODS = [
    "SH_interp", "MAP_MRI", "SHARD", "SH_CNN", "SH_sCNN", "S_CNN",
    "E3xSO3", "UPER", "D_RoPE", "PIGMENT", "EQUAL", "EQUAL_D",
]

# Table IX: NRMSE on HCP-YA at 30% direction masking, by tissue class.
_TABLE9 = {
    "SH_interp": (0.0731, 0.0788, 0.1216),
    "MAP_MRI":   (0.0694, 0.0742, 0.1147),
    "SHARD":     (0.0652, 0.0699, 0.1082),
    "SH_CNN":    (0.0598, 0.0651, 0.1016),
    "SH_sCNN":   (0.0621, 0.0668, 0.1043),
    "S_CNN":     (0.0607, 0.0659, 0.1024),
    "E3xSO3":    (0.0583, 0.0634, 0.0987),
    "UPER":      (0.0574, 0.0628, 0.0971),
    "D_RoPE":    (0.0566, 0.0619, 0.0958),
    "PIGMENT":   (0.0559, 0.0611, 0.0944),
    "EQUAL":     (0.0497, 0.0548, 0.0863),
    "EQUAL_D":   (0.0491, 0.0541, 0.0857),
}

# Table X: white-matter NRMSE across the eight evaluation sources.
# None marks "n/a": a method that cannot represent the input at all.
_SOURCES = ["HCP_YA", "MASiVar_A", "MASiVar_P", "ON_Harmony", "CDMD",
            "tensor_valued", "in_silico"]
_TABLE10 = {
    "SH_interp": (0.0731, 0.0812, 0.0867, 0.0784, 0.1104, None, 0.0693),
    "MAP_MRI":   (0.0694, 0.0775, 0.0831, 0.0748, 0.0968, None, 0.0651),
    "SHARD":     (0.0652, 0.0731, 0.0788, 0.0709, 0.0914, None, 0.0612),
    "QTI":       (None, None, None, None, None, 0.0881, 0.0738),
    "SH_CNN":    (0.0598, 0.0719, 0.0864, 0.0772, None, None, 0.0587),
    "SH_sCNN":   (0.0621, 0.0724, 0.0813, 0.0741, 0.1021, None, 0.0601),
    "S_CNN":     (0.0607, 0.0708, 0.0796, 0.0726, 0.0994, None, 0.0589),
    "E3xSO3":    (0.0583, 0.0681, 0.0749, 0.0693, 0.0947, None, 0.0564),
    "UPER":      (0.0574, 0.0673, 0.0781, 0.0718, 0.1086, None, 0.0558),
    "D_RoPE":    (0.0566, 0.0664, 0.0763, 0.0702, 0.1037, None, 0.0549),
    "PIGMENT":   (0.0559, 0.0652, 0.0734, 0.0681, 0.0929, None, 0.0541),
    "EQUAL":     (0.0497, 0.0571, 0.0608, 0.0563, 0.0724, 0.0612, 0.0452),
    "EQUAL_D":   (0.0491, 0.0566, 0.0604, 0.0559, 0.0719, 0.0608, 0.0449),
}

# The unit of analysis for each source, from Table VIII.  This is what every
# interval and paired test is computed over.
_UNITS = {
    "HCP_YA": ("subject", 94),
    "MASiVar_A": ("subject", 4),
    "MASiVar_P": ("subject", 83),
    "ON_Harmony": ("subject", 10),
    "CDMD": ("subject", 26),
    "tensor_valued": ("spatial_block", 64),
    "in_silico": ("field", 200),
}

# How many of the eleven baselines can be run on each source at all.  A margin
# on a source where most read n/a is a margin over the few that remain, not
# over the field -- which is the correction audit Section 12 asks for.
_APPLICABLE = {
    "HCP_YA": 10, "MASiVar_A": 10, "MASiVar_P": 10, "ON_Harmony": 10,
    "CDMD": 9, "tensor_valued": 1, "in_silico": 11,
}

_BEST_BASELINE = {
    "HCP_YA": "PIGMENT", "MASiVar_A": "PIGMENT", "MASiVar_P": "PIGMENT",
    "ON_Harmony": "PIGMENT", "CDMD": "PIGMENT", "tensor_valued": "QTI",
    "in_silico": "PIGMENT",
}

# Table XX: one ablation per design choice.  (variant NRMSE, targeted metric).
_ABLATIONS = {
    "input.icosahedral_resampling": (0.0569, "optimism_gap", 0.0191),
    "input.raw_lifting": (0.0497, "optimism_gap", 0.0),
    "quadrature.uniform": (0.0528, "sw_slope", -1.12),
    "quadrature.exact_rule": (0.0497, "sw_slope", -2.19),
    "encoding.one_hot": (0.0541, "cdmd_zero_shot", 0.0983),
    "encoding.continuous": (0.0497, "cdmd_zero_shot", 0.0724),
    "linear_channel.removed": (0.0514, "band_limited_recovery_error", 0.0073),
    "linear_channel.kept": (0.0497, "band_limited_recovery_error", 0.0),
    "pooling.mean": (0.0519, "shell_holdout_nrmse", 0.0714),
    "pooling.attention": (0.0497, "shell_holdout_nrmse", 0.0649),
    "backbone.non_equivariant": (0.0556, "equivariance_error", 0.0941),
    "backbone.equivariant": (0.0497, "equivariance_error", 2.7e-6),
    "symmetry.product": (0.0523, "on_harmony_fw_cov_pct", 5.8),
    "symmetry.joint": (0.0497, "on_harmony_fw_cov_pct", 3.6),
    "decoder.direct_mlp": (0.0491, "violation_rate_pct", 6.41),
    "decoder.laplace_measure": (0.0497, "violation_rate_pct", 0.0),
    "fw_atom.none": (0.0503, "scan_rescan_icc_fw", 0.871),
    "fw_atom.fixed": (0.0497, "scan_rescan_icc_fw", 0.934),
    "data_term.mse_adc": (0.0534, "nrmse_b3000", 0.0812),
    "data_term.rician_nll": (0.0497, "nrmse_b3000", 0.0702),
    "consistency.zero": (0.0505, "sw_at_L4", 4.18),
    "consistency.positive": (0.0497, "sw_at_L4", 2.41),
    "masking.a": (0.0521, "shell_holdout_nrmse", 0.0793),
    "masking.ab": (0.0503, "shell_holdout_nrmse", 0.0661),
    "masking.abc": (0.0497, "shell_holdout_nrmse", 0.0649),
    "supervision.distilled": (0.0491, "fod_acc_hcp", 0.902),
    "supervision.none": (0.0497, "fod_acc_hcp", 0.897),
}


def build(store: ResultStore) -> ResultStore:
    # -- Table IX --------------------------------------------------------
    for m, (wm, gm, csf) in _TABLE9.items():
        for tissue, v in (("white_matter", wm), ("gray_matter", gm), ("csf", csf)):
            store.set(
                f"table9.{m}.{tissue}",
                illustrative(v, note=PLACEHOLDER, unit_of_analysis="subject", n_units=94),
            )

    # -- Table X ---------------------------------------------------------
    for m, row in _TABLE10.items():
        for src, v in zip(_SOURCES, row):
            unit, n = _UNITS[src]
            if v is None:
                store.set(
                    f"table10.{m}.{src}",
                    illustrative(
                        "n/a",
                        note="Not a missing measurement: this method cannot represent "
                             "this input at all. Reason in Table VIII.",
                    ),
                )
            else:
                store.set(
                    f"table10.{m}.{src}",
                    illustrative(v, note=PLACEHOLDER, unit_of_analysis=unit, n_units=n),
                )
    for src, k in _APPLICABLE.items():
        store.set(
            f"table10.applicable_baselines.{src}",
            external(
                k, citation="Table VIII of the manuscript",
                note="Count of the eleven baselines that can process this source. "
                     "A margin here is a margin over these, not over the field.",
            ),
        )
        store.set(
            f"table10.best_baseline.{src}",
            external(_BEST_BASELINE[src], citation="Table X of the manuscript",
                     note="The comparator behind the reported margin."),
        )

    # -- Table XI: one acquisition axis at a time -------------------------
    axes = {
        "new_directions": (11.1, (9.4, 12.8), 1.42, True, "HCP_YA", "PIGMENT"),
        "unseen_b": (22.1, (18.3, 25.6), 1.88, False, "CDMD", "PIGMENT"),
        "encoding_shape": (30.5, (25.1, 35.4), 2.31, False, "tensor_valued", "QTI"),
        "scanner_site": (17.3, (11.8, 22.9), 1.67, False, "ON_Harmony", "PIGMENT"),
    }
    for axis, (red, ci, d, covered, src, comp) in axes.items():
        unit, n = _UNITS[src]
        store.set(
            f"table11.{axis}.reduction_pct",
            illustrative(red, note=PLACEHOLDER, unit_of_analysis=unit, n_units=n, ci=ci),
        )
        store.set(f"table11.{axis}.cohens_d", illustrative(d, note=PLACEHOLDER))
        store.set(
            f"table11.{axis}.theorem2_covers",
            theoretical(
                covered,
                note="Theorem 2 assumes the two acquisitions share their shells and "
                     "differ only in their directions. Only the direction axis meets "
                     "that hypothesis; the other three are extrapolation in the "
                     "continuous descriptor (14), for which no bound is offered.",
            ),
        )
        store.set(f"table11.{axis}.comparator", external(
            comp, citation="Table X", note="Best baseline able to process this input."))

    # -- Table XII: the optimism of grid-referenced self-supervision -------
    for m, (grid, raw) in {"UPER": (0.0346, 0.0574), "D_RoPE": (0.0359, 0.0566),
                           "SH_sCNN": (0.0418, 0.0621)}.items():
        store.set(f"table12.{m}.vs_own_reference", illustrative(grid, note=PLACEHOLDER))
        store.set(f"table12.{m}.vs_raw", illustrative(raw, note=PLACEHOLDER))
        store.set_derived(
            f"table12.{m}.optimism_gap", round(raw - grid, 4),
            [f"table12.{m}.vs_raw", f"table12.{m}.vs_own_reference"],
            note="Equation (37): G_opt = NRMSE_raw - NRMSE_grid",
        )
    store.set("table12.oracle.gap", illustrative(
        0.0062,
        note="Oracle control of Section VI-C.1: the part of the gap that "
             "interpolation smoothing alone produces. " + PLACEHOLDER))
    store.set("table12.EQUAL.vs_raw", illustrative(0.0497, note=PLACEHOLDER))
    store.set("table12.EQUAL.optimism_gap", theoretical(
        0.0, note="EQUAL builds no resampled reference at any stage, so no gap is "
                  "defined for it. This is a property of the objective (9), not a "
                  "measurement."))

    # -- Table XIII: symmetry and consistency -----------------------------
    store.set("table13.EQUAL.equivariance_error", illustrative(
        2.7e-6, note="Reported as float32 round-off. " + PLACEHOLDER))
    store.set("table13.UPER.equivariance_error", illustrative(1.1e-1, note=PLACEHOLDER))
    store.set("table13.D_RoPE.equivariance_error", illustrative(8.4e-2, note=PLACEHOLDER))
    store.set("table13.E3xSO3.equivariance_error", illustrative(3.1e-6, note=PLACEHOLDER))
    store.set("table13.EQUAL.sw_at_L2", illustrative(14.60, note=PLACEHOLDER))
    store.set("table13.EQUAL.sw_at_L8", illustrative(3.60, note=PLACEHOLDER))
    store.set("table13.scan_rescan_floor.sw", illustrative(
        3.40, note="Measurement floor from the 46 retest subjects. " + PLACEHOLDER))
    store.set("table13.EQUAL.on_harmony_fw_cov_pct", illustrative(3.6, note=PLACEHOLDER))
    store.set("table13.UPER.on_harmony_fw_cov_pct", illustrative(7.9, note=PLACEHOLDER))
    store.set("table13.within_scanner_floor.fw_cov_pct", illustrative(2.1, note=PLACEHOLDER))

    # -- Table XIV: validity and extrapolation ----------------------------
    store.set("table14.EQUAL.violation_rate_pct", theoretical(
        0.0, note="Zero by construction: (24) is a convex combination of completely "
                  "monotone exponentials, so Theorem 4 holds for every parameter "
                  "value. Measured only to confirm the implementation matches."))
    for m, v in {"SH_interp": 14.90, "MAP_MRI": 2.40, "SHARD": 3.10, "UPER": 11.70,
                 "D_RoPE": 9.80, "PIGMENT": 4.20, "EQUAL_direct_mlp": 6.41}.items():
        store.set(f"table14.{m}.violation_rate_pct", illustrative(v, note=PLACEHOLDER))
    for ratio, v in {1.5: 0.061, 2.0: 0.079, 3.0: 0.118, 4.0: 0.162, 6.0: 0.247}.items():
        store.set(f"table14.EQUAL.nrmse_at_ratio_{ratio}",
                  illustrative(v, note=PLACEHOLDER))
    for ratio, v in {1.5: 0.028, 2.0: 0.049, 3.0: 0.097, 4.0: 0.171}.items():
        store.set(f"table14.half_protocol_divergence.ratio_{ratio}",
                  illustrative(v, note=PLACEHOLDER))

    # The bound is a theorem, not a measurement, so it is computed here rather
    # than transcribed.  See audit.py check `thm6_bound_row`.
    for ratio in (1.5, 2.0, 3.0, 4.0):
        store.set(
            f"table14.thm6_bound_eps0.01.ratio_{ratio}",
            theoretical(
                round(float(divergence_bound(ratio, 0.01, mask_trivial=False)), 4),
                note="Equation (35) evaluated directly: 2^(1-omega) eps^omega with "
                     "omega = (2/pi) arcsin(b_max/b*). Computed, never typed.",
            ),
        )
    for eps in (0.05, 0.01, 0.001):
        store.set(
            f"theory.thm6_trivial_crossing.eps_{eps}",
            theoretical(round(trivial_crossing_ratio(eps), 3),
                        note="b*/b_max at which (35) reaches the trivial value 1."),
        )

    # -- Table XV / XVII: the identifiability flag -------------------------
    flag_rows = {
        "FW":   (0.021, 0.047, 0.118, 0.951, (0.935, 0.965), 6, 268),
        "MD":   (0.34, 0.71, 1.92, 0.931, (0.912, 0.949), 9, 252),
        "muFA": (0.028, 0.063, 0.171, 0.967, (0.954, 0.978), 4, 306),
        "FOD":  (0.941, 0.887, 0.762, 0.918, (0.896, 0.938), 12, 238),
    }
    for r, (ident, approx, prior, auc, ci, k, n) in flag_rows.items():
        store.set(f"table15.{r}.error_identified", illustrative(ident, note=PLACEHOLDER))
        store.set(f"table15.{r}.error_approximate", illustrative(approx, note=PLACEHOLDER))
        store.set(f"table15.{r}.error_prior_driven", illustrative(prior, note=PLACEHOLDER))
        store.set(f"table15.{r}.auc", illustrative(auc, note=PLACEHOLDER, ci=ci))
        store.set(f"table17.{r}.false_confident_count", illustrative(k, note=PLACEHOLDER))
        store.set(f"table17.{r}.false_confident_total", illustrative(n, note=PLACEHOLDER))
    store.set("table15.macro_auc", illustrative(
        0.942, note="Macro average over the four readouts. " + PLACEHOLDER))

    # -- Table XIX: reproducibility and cost -------------------------------
    for m, (icc_fw, icc_md, icc_mufa, par, mem, inf) in {
        "EQUAL": (0.934, 0.961, 0.908, 18.4, 9.2, 94.0),
        "EQUAL_D": (0.936, 0.962, 0.911, 18.4, 9.2, 94.0),
        "UPER": (0.871, 0.927, None, 24.7, 11.6, 142.0),
        "D_RoPE": (0.879, 0.933, None, 31.2, 13.4, 168.0),
        "PIGMENT": (0.894, 0.948, 0.831, 46.5, 17.2, 221.0),
    }.items():
        for name, v in (("icc_fw", icc_fw), ("icc_md", icc_md), ("icc_mufa", icc_mufa),
                        ("parameters_M", par), ("peak_gpu_gb", mem),
                        ("inference_s", inf)):
            if v is None:
                continue
            store.set(f"table19.{m}.{name}", illustrative(v, note=PLACEHOLDER))

    # -- Table XX: ablations ------------------------------------------------
    for key, (nrmse, metric, mval) in _ABLATIONS.items():
        store.set(f"table20.{key}.nrmse", illustrative(nrmse, note=PLACEHOLDER))
        store.set(f"table20.{key}.{metric}", illustrative(mval, note=PLACEHOLDER))

    # -- Abstract figures, which are drawn from the tables above -----------
    store.set_derived(
        "abstract.reduction_in_distribution_pct", 11.1,
        ["table10.EQUAL.HCP_YA", "table10.PIGMENT.HCP_YA"],
        note="Relative reduction of EQUAL over the strongest baseline on HCP-YA",
    )
    store.set_derived(
        "abstract.reduction_encoding_shape_pct", 30.5,
        ["table10.EQUAL.tensor_valued", "table10.QTI.tensor_valued"],
        note="Margin over QTI, the ONE applicable baseline on this source. Not a "
             "margin over competing methods, and not evidence that no competing "
             "model can represent the data: QTI represents it",
    )
    store.set_derived(
        "abstract.uper_optimism_share_pct", 39.7,
        ["table12.UPER.optimism_gap", "table12.UPER.vs_raw"],
        note="The gap as a share of the error UPER should be reporting",
    )
    store.set("abstract.flag_auc", illustrative(0.942, note=PLACEHOLDER))
    store.set("abstract.equivariance_error", illustrative(2.7e-6, note=PLACEHOLDER))

    # -- Section VII-D: what the finite-atomic decoder gives up -------------
    for k, v in {1: 0.0865, 8: 0.0046, 16: 0.0037}.items():
        store.set(f"section7d.sup_error_K{k}", illustrative(
            v, note="Best K-atom approximation error on three closed-form ensembles. "
                    "No network involved. " + PLACEHOLDER))

    # -- Section VII-C: quadrature feasibility on real directions -----------
    store.set("section7c.min_degree_tensor_valued", illustrative(
        2, note="Smallest L_p across the shells of the tensor-valued acquisition; "
               "this, not the measurement count, is what Theorem 2 depends on. "
               + PLACEHOLDER))
    store.set("section7c.max_degree_tensor_valued", illustrative(
        8, note="L_p on the 46-direction shell at b=2000. " + PLACEHOLDER))

    return store


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", default=str(ROOT / "results" / "results.json"))
    ap.add_argument("--summary", action="store_true")
    args = ap.parse_args()

    store = build(ResultStore())
    path = store.save(args.out)
    ok, ph = store.is_submittable()

    print(f"wrote {path}  ({len(store)} values)")
    print("provenance:", store.provenance_summary())
    print(f"submittable on these results: {ok}")
    if not ok:
        print(f"  {len(ph)} value(s) are still illustrative placeholders.")
        print("  Running the experiments and re-saving the store clears this.")
    if args.summary:
        print("\nplaceholders by table:")
        counts: dict[str, int] = {}
        for k in ph:
            counts[k.split(".")[0]] = counts.get(k.split(".")[0], 0) + 1
        for k, v in sorted(counts.items()):
            print(f"  {k:12s} {v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
