#!/usr/bin/env python3
"""Write subject-level split manifests (audit Section 3).

The audit records that no subject-level split manifests exist and that the
HCP-YA exclusion count is a placeholder.  This script writes the manifests and
checks them; the exclusion count is read from
``equal.data.splits.HCP_YA_ACCOUNTING``, whose chain must close arithmetically.

With ``--subject-ids`` the manifests are built from the real subject lists.
Without it, synthetic identifiers of the right *counts* are used, so the
structure, the overlap check and the fingerprinting can be exercised before any
data are in hand -- but the manifest is then marked ``synthetic`` and
``scripts/evaluate.py`` will not treat it as a real split.

    python scripts/make_splits.py
    python scripts/make_splits.py --subject-ids hcp_subjects.txt --retest-ids retest.txt
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from equal.data.splits import (  # noqa: E402
    HCP_YA_ACCOUNTING, make_subject_split, verify_hcp_accounting, write_manifest,
)


def _read_ids(path: Path | None) -> list[str] | None:
    if path is None:
        return None
    return [ln.strip() for ln in path.read_text().splitlines() if ln.strip()]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", type=Path, default=ROOT / "results" / "splits")
    ap.add_argument("--subject-ids", type=Path, default=None,
                    help="one HCP-YA subject id per line, the eligible population")
    ap.add_argument("--retest-ids", type=Path, default=None,
                    help="one id per line; these are constrained into the test set")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    derived = verify_hcp_accounting()
    acc = HCP_YA_ACCOUNTING
    print("HCP-YA eligibility chain (Section VIII-A):")
    print(f"  {acc.release_total} in the S1200 release")
    print(f"  {acc.with_complete_dwi} with the complete 3 T diffusion acquisition")
    print(f"  - {acc.excluded_qc_or_preproc} excluded (QC flag or incomplete preprocessing)")
    print(f"  = {acc.eligible} eligible  ->  {acc.n_train}/{acc.n_val}/{acc.n_test}")
    print(f"  {acc.n_retest_subjects} retest subjects inside the test set "
          f"-> {derived['n_test_scans']} test scans")
    if not acc.verified_against_release:
        print("  NOTE: this chain has NOT been re-derived from the released "
              "quality-control tables. Until it is, the exclusion count remains "
              "the audit's placeholder, and audit.py says so.")

    ids = _read_ids(a.subject_ids)
    retest = _read_ids(a.retest_ids)
    synthetic = ids is None
    if synthetic:
        ids = [f"SYNTH{i:05d}" for i in range(acc.eligible)]
        retest = ids[: acc.n_retest_subjects]
        print(f"\nno --subject-ids given: using {len(ids)} synthetic identifiers")
    elif retest is None:
        retest = []

    if len(ids) != acc.eligible:
        print(f"\nWARNING: {len(ids)} subject ids given but the accounting says "
              f"{acc.eligible} are eligible. The manifest will describe the ids "
              f"given; reconcile the two before using it.")

    m = make_subject_split(
        ids, (0.8, 0.1, 0.1), seed=a.seed, constrain_to_test=retest,
        dataset="HCP-YA",
        notes=("Subject-level 80/10/10 of the eligible population. Retest subjects "
               "are constrained INTO the test set, not added to it. "
               + ("SYNTHETIC IDENTIFIERS - not a real split." if synthetic else "")),
    )
    p = write_manifest(m, a.out / "hcp_ya.json")
    print(f"\nwrote {p}")
    print(f"  train/val/test = {len(m.train)}/{len(m.val)}/{len(m.test)}")
    print(f"  {len(m.constrained_to_test)} retest subjects inside the test set")
    print(f"  fingerprint {m.fingerprint()}")

    # Test-only sources: every subject goes to test, which the manifest records
    # explicitly rather than leaving implicit.
    for name, n in [("ON-Harmony", 10), ("CDMD", 26), ("MASiVar-P", 83),
                    ("tensor-valued", 1)]:
        ids_t = [f"{name}-{i:03d}" for i in range(n)]
        mt = make_subject_split(ids_t, (0.0, 0.0, 1.0), seed=a.seed, dataset=name,
                                notes="Test only: never seen during training or "
                                      "model selection (Section VI-A.3).")
        write_manifest(mt, a.out / f"{name.lower().replace('-', '_')}.json")
        print(f"wrote {name}: {len(mt.test)} test subjects, 0 train, 0 val")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
