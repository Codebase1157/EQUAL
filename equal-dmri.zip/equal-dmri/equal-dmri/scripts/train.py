#!/usr/bin/env python3
"""Train EQUAL on raw measurements, following Algorithm 1.

One training step, exactly as Algorithm 1 lists it:

    1. draw O,H ~ M and thinning operators T1, T2 ~ M
    2. group X_O into shells; compute w_p and L_p by (12)-(13)
    3. lift by (14)-(15) and pool by (17)
    4. run the backbone (18)-(20)
    5. decode by (21)-(23); predict nu_ij = E_j(B_i) for i in H by (24)
    6. evaluate L_Rice by (28)
    7. repeat on T1 X and T2 X; evaluate L_cons by (29)-(30)
    8. if lambda_sup > 0 and a reference exists, evaluate L_sup by (31)
    9. update Theta with AdamW on the minibatch mean of (32)

By default this runs on in-silico fields, which is what makes the script
executable without any download.  Point ``--data`` at a prepared directory to
train on real sources.

    python scripts/train.py --config configs/equal_base.yaml --steps 50

**This script does not reproduce the numbers in the manuscript.**  Those are
illustrative placeholders; see docs/AUDIT_STATUS.md.  Running a real training
job and then ``scripts/evaluate.py`` is what replaces them.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from equal.data.insilico import generate_field  # noqa: E402
from equal.data.protocols import (  # noqa: E402
    Protocol, hcp_ya_protocol, single_shell_protocol, tensor_valued_protocol,
)
from equal.losses import (  # noqa: E402
    LossWeights, consistency_loss, rician_nll_loss, total_loss,
)
from equal.masking import MaskingDistribution, apply_mask  # noqa: E402
from equal.model import EQUAL, EqualConfig, prepare_input  # noqa: E402


def load_config(path: str | None) -> tuple[EqualConfig, dict]:
    if path is None:
        return EqualConfig(), {}
    import yaml

    raw = yaml.safe_load(Path(path).read_text()) or {}
    model_keys = set(EqualConfig().__dict__)
    cfg = EqualConfig(**{k: v for k, v in raw.get("model", {}).items() if k in model_keys})
    return cfg, raw


def training_protocols(seed: int = 0) -> list[Protocol]:
    """A mixture of protocol families, as Section VI-A describes.

    The point of training on several is that the lift and the descriptor must
    see more than one shell structure; a single family would not exercise the
    shell pooling (17) or the continuous descriptor (14) at all.
    """
    return [
        hcp_ya_protocol(n_dir=30, seed=seed),
        single_shell_protocol(1000.0, 30, seed=seed + 1),
        tensor_valued_protocol(b_values=(700.0, 1400.0), n_lte=16, n_pte=16,
                               n_ste=6, seed=seed + 2),
    ]


def _shell_signals(field, protocol: Protocol, idx=None) -> list[torch.Tensor]:
    """Split a flat signal array into one tensor per nonzero shell."""
    out, cursor = [], 0
    for s in protocol.shells:
        n = s.n_directions
        if not s.is_b0:
            block = field.signals[:, cursor : cursor + n]
            out.append(torch.as_tensor(block, dtype=torch.float32))
        cursor += n
    return out


def _observed_signals(field, protocol, observed_protocol, outcome) -> list[torch.Tensor]:
    """Signals for the observed sub-protocol, in its shell order."""
    keep = set(int(i) for i in outcome.observed)
    out, cursor = [], 0
    for s in protocol.shells:
        n = s.n_directions
        if not s.is_b0:
            idx = [i for i in range(n) if (cursor + i) in keep]
            if idx:
                out.append(torch.as_tensor(field.signals[:, cursor : cursor + n][:, idx],
                                           dtype=torch.float32))
        cursor += n
    return out


def train(
    config: EqualConfig,
    steps: int = 100,
    lr: float = 2e-4,
    weight_decay: float = 0.01,
    warmup: int = 5,
    patch: tuple[int, int, int] = (3, 3, 3),
    snr: float = 30.0,
    lambda_sup: float = 0.0,
    seed: int = 0,
    out: Path | None = None,
    log_every: int = 10,
) -> dict:
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)
    model = EQUAL(config)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: min(1.0, (s + 1) / max(warmup, 1))
    )
    weights = LossWeights(rec=1.0, cons=0.1, sup=lambda_sup)
    masker = MaskingDistribution()
    protocols = training_protocols(seed)

    history = []
    t0 = time.time()
    for step in range(steps):
        proto = protocols[step % len(protocols)]
        field = generate_field(proto, shape=patch, snr=snr, seed=seed * 10_000 + step)
        geo = model.build_geometry(field.positions)
        sigma = torch.full((field.n_voxels, 1), max(field.sigma, 1e-3))

        # 2: draw the mask and the two thinning operators
        outcome = masker.draw(proto, rng)
        obs_proto = apply_mask(proto, outcome)
        prep = prepare_input(obs_proto, config)
        sigs = _observed_signals(field, proto, obs_proto, outcome)

        # 3-6: lift, backbone, decode, predict the held-out measurements
        mu = model(sigs, prep, geo)
        B_held = torch.as_tensor(proto.b_tensors()[outcome.held_out], dtype=torch.float32)
        target = torch.as_tensor(field.signals[:, outcome.held_out], dtype=torch.float32)
        pred = mu.signal(B_held)
        l_rice = rician_nll_loss(pred, target, sigma)

        # 7: two thinned views -> consistency
        t1 = masker.draw(proto, rng)
        t2 = masker.draw(proto, rng)
        p1, p2 = apply_mask(proto, t1), apply_mask(proto, t2)
        mu1 = model(_observed_signals(field, proto, p1, t1), prepare_input(p1, config), geo)
        mu2 = model(_observed_signals(field, proto, p2, t2), prepare_input(p2, config), geo)
        l_cons = consistency_loss(mu1, mu2, n_projections=32)

        # 9: update
        loss = total_loss(l_rice, l_cons, None, weights)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        opt.step()
        sched.step()

        rec = {
            "step": step, "loss": loss.item(), "rice": l_rice.item(),
            "cons": l_cons.item(), "protocol": proto.name,
            "held_out": int(outcome.held_out.size), "operation": outcome.operation,
            "min_quadrature_degree": prep.min_degree,
        }
        history.append(rec)
        if step % log_every == 0 or step == steps - 1:
            print(f"  step {step:4d}  loss {rec['loss']:9.4f}  rice {rec['rice']:9.4f}  "
                  f"cons {rec['cons']:.3e}  mask {outcome.operation}  "
                  f"L_min {prep.min_degree}  [{proto.name}]")

    elapsed = time.time() - t0
    summary = {
        "steps": steps,
        "parameters": model.n_parameters,
        "seconds": round(elapsed, 1),
        "final_loss": history[-1]["loss"] if history else None,
        "config": config.as_dict(),
        "note": "Trained on in-silico fields unless --data was given. This does "
                "not reproduce the manuscript's numbers, which are illustrative.",
    }
    if out:
        out.parent.mkdir(parents=True, exist_ok=True)
        torch.save({"state_dict": model.state_dict(), "config": config.as_dict(),
                    "summary": summary}, out)
        (out.parent / f"{out.stem}_history.json").write_text(
            json.dumps({"summary": summary, "history": history}, indent=2) + "\n")
        print(f"\nwrote {out}")
    return summary


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default=None)
    ap.add_argument("--steps", type=int, default=100)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--snr", type=float, default=30.0)
    ap.add_argument("--patch", type=int, nargs=3, default=[3, 3, 3])
    ap.add_argument("--lambda-sup", type=float, default=0.0,
                    help="0 for EQUAL, 0.5 for EQUAL-D")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", type=Path, default=ROOT / "results" / "checkpoints" / "equal.pt")
    a = ap.parse_args()

    cfg, raw = load_config(a.config)
    print(f"EQUAL training  (L={cfg.l_max}, K={cfg.n_atoms}, "
          f"{cfg.n_blocks} blocks, symmetry={cfg.symmetry_group})")
    s = train(cfg, steps=a.steps, lr=a.lr, snr=a.snr, patch=tuple(a.patch),
              lambda_sup=a.lambda_sup, seed=a.seed, out=a.out)
    print(json.dumps({k: v for k, v in s.items() if k != "config"}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
