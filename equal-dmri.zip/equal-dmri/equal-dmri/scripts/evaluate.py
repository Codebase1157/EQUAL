#!/usr/bin/env python3
"""Evaluate EQUAL and write MEASURED values into the result store.

This is the script that converts illustrative placeholders into evidence.  Every
value it writes carries ``provenance = measured``, names this script, records the
commit, and states the unit of analysis and the number of units -- so a reader
can tell a measurement from a placeholder without reading the surrounding prose.

What it computes
----------------
* **Signal prediction (RQ1)** -- NRMSE (36) against raw held-out measurements.
* **Symmetry (RQ2)** -- the equivariance error (38) over the 24 cubic-lattice
  rotations, which every model can accept exactly, and over Haar-drawn rotations
  applied to coordinates and gradients together.
* **Consistency (RQ2)** -- the SW2 discrepancy against quadrature degree, and the
  fitted power-law slope Theorem 2 predicts.
* **Validity (RQ3)** -- the violation rate (39) on the test set of Section VI-C.3.
* **Identifiability (RQ4)** -- the flag's AUC as an ordinal detector, its
  calibration, and the false-confident rate with Wilson intervals.

Usage::

    python scripts/evaluate.py --checkpoint results/checkpoints/equal.pt \\
                               --write-results            # update results.json
    python scripts/evaluate.py --dry-run                  # print, write nothing

Without ``--write-results`` nothing is written, so an exploratory run cannot
quietly promote a placeholder.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from equal.data.insilico import generate_field  # noqa: E402
from equal.data.protocols import (  # noqa: E402
    Protocol, Shell, farthest_point_subset, hcp_ya_protocol, single_shell_protocol,
    tensor_valued_protocol,
)
from equal.identifiability import identifiability_map  # noqa: E402
from equal.losses import sliced_wasserstein2  # noqa: E402
from equal.masking import MaskingDistribution, apply_mask  # noqa: E402
from equal.metrics import (  # noqa: E402
    equivariance_error, nrmse, validity_test_set, violation_rate,
)
from equal.model import EQUAL, EqualConfig, prepare_input  # noqa: E402
from equal.readouts import fod_coefficients, micro_fa  # noqa: E402
from equal.results import ResultStore, measured  # noqa: E402
from equal.sh import cubic_lattice_rotations, random_rotation, rotate_sh_coefficients  # noqa: E402
from equal.stats import ordinal_auc, wilson_interval  # noqa: E402
from equal.theory import quadrature_consistency_rate  # noqa: E402

SCRIPT = "scripts/evaluate.py"


def load_model(path: Path | None) -> tuple[EQUAL, EqualConfig, bool]:
    """Load a checkpoint, or build an untrained model.

    An untrained model is still the right object for the structural checks --
    Theorems 1 and 4 hold for **every** value of Theta -- but it cannot produce
    an accuracy number worth recording, so ``trained`` is returned and the
    accuracy sections are skipped when it is False.
    """
    if path is None or not Path(path).exists():
        cfg = EqualConfig(l_max=4, lift_channels=8, pool_heads=2, c_invariant=16,
                          c_steerable=8, n_blocks=2, n_attention_heads=2,
                          n_radial=4, n_atoms=4, r_cut=3.0)
        torch.manual_seed(0)
        m = EQUAL(cfg)
        m.eval()
        return m, cfg, False
    ck = torch.load(path, map_location="cpu", weights_only=False)
    cfg = EqualConfig(**ck["config"])
    m = EQUAL(cfg)
    m.load_state_dict(ck["state_dict"])
    m.eval()
    return m, cfg, True


def _signals_for(field, protocol) -> list[torch.Tensor]:
    out, cursor = [], 0
    for s in protocol.shells:
        n = s.n_directions
        if not s.is_b0:
            out.append(torch.as_tensor(field.signals[:, cursor : cursor + n],
                                       dtype=torch.float32))
        cursor += n
    return out


def _observed(field, protocol, outcome) -> list[torch.Tensor]:
    keep = set(int(i) for i in outcome.observed)
    out, cursor = [], 0
    for s in protocol.shells:
        n = s.n_directions
        if not s.is_b0:
            idx = [i for i in range(n) if (cursor + i) in keep]
            if idx:
                out.append(torch.as_tensor(
                    field.signals[:, cursor : cursor + n][:, idx], dtype=torch.float32))
        cursor += n
    return out


# -- RQ1 ---------------------------------------------------------------------

def eval_signal_prediction(model, cfg, n_fields: int = 8, seed: int = 0) -> dict:
    """NRMSE (36) against raw held-out measurements, per in-silico field.

    The unit of analysis is the **field** (Table VIII), so error is averaged
    within a field before anything is aggregated across fields.
    """
    proto = hcp_ya_protocol(n_dir=30, seed=0)
    masker = MaskingDistribution(1.0, 0.0, 0.0)       # direction masking only
    rng = np.random.default_rng(seed)
    per_field = []
    for k in range(n_fields):
        field = generate_field(proto, shape=(3, 3, 3), snr=30.0, seed=1000 + k)
        geo = model.build_geometry(field.positions)
        out = masker.draw(proto, rng)
        obs = apply_mask(proto, out)
        with torch.no_grad():
            mu = model(_observed(field, proto, out), prepare_input(obs, cfg), geo)
            B = torch.as_tensor(proto.b_tensors()[out.held_out], dtype=torch.float32)
            pred = mu.signal(B).numpy()
        target = field.signals[:, out.held_out]
        per_field.append(nrmse(pred, target))
    a = np.array(per_field)
    return {"nrmse_mean": float(a.mean()), "nrmse_std": float(a.std()),
            "n_units": len(a), "unit": "field", "per_unit": per_field}


# -- RQ2 ---------------------------------------------------------------------

def eval_equivariance(model, cfg, seed: int = 0) -> dict:
    """Equation (38), over cubic-lattice and Haar rotations."""
    proto = hcp_ya_protocol(n_dir=30, seed=0)
    field = generate_field(proto, shape=(3, 3, 3), snr=None, seed=7)
    sigs = _signals_for(field, proto)
    L = cfg.l_max

    def run(p, pos):
        with torch.no_grad():
            return model(sigs, prepare_input(p, cfg), model.build_geometry(pos))

    base = fod_coefficients(run(proto, field.positions), l_max=L).numpy()

    cubic = []
    for R in cubic_lattice_rotations():
        got = fod_coefficients(run(proto.rotated(R), field.positions @ R.T),
                               l_max=L).numpy()
        cubic.append(equivariance_error(got, rotate_sh_coefficients(base, R, L)))

    rng = np.random.default_rng(seed)
    haar = []
    for _ in range(24):
        R = random_rotation(rng)
        got = fod_coefficients(run(proto.rotated(R), field.positions @ R.T),
                               l_max=L).numpy()
        haar.append(equivariance_error(got, rotate_sh_coefficients(base, R, L)))

    return {"cubic_mean": float(np.mean(cubic)), "cubic_max": float(np.max(cubic)),
            "haar_mean": float(np.mean(haar)), "n_cubic": len(cubic), "n_haar": len(haar)}


def eval_consistency(model, cfg, seed: int = 0) -> dict:
    """SW2 discrepancy against quadrature degree, and the fitted rate."""
    full = hcp_ya_protocol(n_dir=90, seed=0)
    field = generate_field(full, shape=(3, 3, 3), snr=None, seed=11)
    geo = model.build_geometry(field.positions)

    def estimate(proto, idxs):
        sigs, cursor, k = [], 0, 0
        for s in full.shells:
            n = s.n_directions
            if not s.is_b0:
                sigs.append(torch.as_tensor(
                    field.signals[:, cursor : cursor + n][:, idxs[k]],
                    dtype=torch.float32))
                k += 1
            cursor += n
        with torch.no_grad():
            return model(sigs, prepare_input(proto, cfg), geo)

    ref = estimate(full, [np.arange(s.n_directions)
                          for s in full.shells if not s.is_b0])
    degrees, disc = [], []
    for n in (6, 10, 15, 28, 45):
        # One spread subset PER SHELL: the shells carry different gradient
        # tables, so indices chosen on one of them are an arbitrary -- possibly
        # clustered -- selection on the others, which would lower the degree for
        # a reason that has nothing to do with the subset size.
        idxs = [farthest_point_subset(s.directions, n, seed=0)
                for s in full.shells if not s.is_b0]
        sub = Protocol(
            [Shell(0.0, "LTE", np.array([[0.0, 0.0, 1.0]]))]
            + [Shell(s.b, s.shape, s.directions[i])
               for s, i in zip([x for x in full.shells if not x.is_b0], idxs)]
        )
        prep = prepare_input(sub, cfg)
        with torch.no_grad():
            d = sliced_wasserstein2(estimate(sub, idxs), ref, n_projections=256).mean()
        degrees.append(prep.min_degree)
        disc.append(float(d) * 1e4)          # units of 1e-4 mm^2/s, as Table XIII
    out = {"degrees": degrees, "discrepancy_1e4": disc}
    try:
        out["rate"] = quadrature_consistency_rate(np.array(degrees, float), np.array(disc))
    except ValueError as e:
        out["rate_error"] = str(e)
    return out


# -- RQ3 ---------------------------------------------------------------------

def eval_validity(model, cfg) -> dict:
    """Equation (39).  Zero by Theorem 4; measured to confirm the code matches."""
    proto = hcp_ya_protocol(n_dir=30, seed=0)
    field = generate_field(proto, shape=(3, 3, 3), snr=30.0, seed=13)
    with torch.no_grad():
        mu = model(_signals_for(field, proto),
                   prepare_input(proto, cfg), model.build_geometry(field.positions))
    unit_B, b_grid = validity_test_set(n_lte=64, n_pte=64, n_b=200)

    def signal_fn(B):
        with torch.no_grad():
            return mu.signal(torch.as_tensor(B, dtype=torch.float32)).numpy()

    rep = violation_rate(signal_fn, mu.n_voxels, unit_B, b_grid)
    return {"rate_pct": rep.rate * 100.0, "n_voxels": rep.n_voxels,
            "boundedness": rep.boundedness, "monotonicity": rep.monotonicity,
            "convexity": rep.convexity}


# -- RQ4 ---------------------------------------------------------------------

def eval_identifiability(model, cfg, n_cases: int = 120, seed: int = 0) -> dict:
    """The flag as an ordinal detector of an unreliable readout.

    The unit is the independently drawn case of tissue parameters and protocol
    (Table VIII).  Ground truth for muFA comes from the generator's own measure,
    which is the only place it exists.
    """
    rng = np.random.default_rng(seed)
    tau_mufa = 0.07                                  # Section VI-C.4 tolerance
    flags, errors = [], []
    families = [
        lambda s: hcp_ya_protocol(n_dir=int(rng.integers(20, 60)), seed=s),
        lambda s: single_shell_protocol(1000.0, int(rng.integers(12, 60)), seed=s),
        lambda s: tensor_valued_protocol(b_values=(700.0, 1400.0), n_lte=16,
                                         n_pte=16, n_ste=6, seed=s),
        lambda s: tensor_valued_protocol(b_values=(1400.0,), n_lte=16,
                                         n_pte=16, n_ste=6, seed=s),
    ]
    for c in range(n_cases):
        proto = families[c % len(families)](c)
        flag = identifiability_map(proto)
        field = generate_field(proto, shape=(2, 2, 2), snr=30.0, seed=5000 + c)
        with torch.no_grad():
            mu = model(_signals_for(field, proto), prepare_input(proto, cfg),
                       model.build_geometry(field.positions))
            est = micro_fa(mu).numpy()
        truth = np.array([_true_mufa(m) for m in field.measures])
        err = float(np.abs(est - truth).mean())
        flags.append(flag.ordinal("muFA"))
        errors.append(err)

    flags = np.array(flags)
    errors = np.array(errors)
    unreliable = errors > 2 * tau_mufa
    out = {"n_cases": int(len(flags)), "tolerance": tau_mufa,
           "unreliable_fraction": float(unreliable.mean())}
    if unreliable.any() and (~unreliable).any():
        out["auc"] = ordinal_auc(flags, unreliable)
    else:
        out["auc"] = None
        out["auc_note"] = ("only one class present, so no AUC is defined; this "
                           "needs a wider spread of protocols or a trained model")
    ident = flags == 0
    if ident.any():
        k = int((unreliable & ident).sum())
        n = int(ident.sum())
        out["false_confident"] = {"count": k, "total": n, "rate": k / n,
                                  "wilson": wilson_interval(k, n)}
    return out


def _true_mufa(measure) -> float:
    """Equation (26) evaluated on a known measure."""
    w, D = measure.weights, measure.tensors
    tr = np.einsum("kii->k", D)
    dev = D - tr[:, None, None] / 3.0 * np.eye(3)
    num = float(np.einsum("k,kij,kij->", w, dev, dev))
    den = measure.second_moment_frobenius()
    return float(np.sqrt(max(1.5 * num / max(den, 1e-20), 0.0)))


# -- driver ------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--checkpoint", type=Path, default=None)
    ap.add_argument("--write-results", action="store_true",
                    help="write MEASURED values into results/results.json")
    ap.add_argument("--results", type=Path, default=ROOT / "results" / "results.json")
    ap.add_argument("--out", type=Path, default=ROOT / "results" / "evaluation.json")
    ap.add_argument("--fields", type=int, default=8)
    ap.add_argument("--cases", type=int, default=40)
    a = ap.parse_args()

    model, cfg, trained = load_model(a.checkpoint)
    print(f"model: {'checkpoint ' + str(a.checkpoint) if trained else 'UNTRAINED (structural checks only)'}")
    print(f"       L={cfg.l_max} K={cfg.n_atoms} blocks={cfg.n_blocks} "
          f"params={model.n_parameters/1e6:.2f}M\n")

    report: dict = {"trained": trained, "config": cfg.as_dict()}

    print("RQ2  equivariance (38)")
    report["equivariance"] = eval_equivariance(model, cfg)
    e = report["equivariance"]
    print(f"     cubic-lattice mean {e['cubic_mean']:.3e}  max {e['cubic_max']:.3e}")
    print(f"     Haar mean          {e['haar_mean']:.3e}   "
          f"-> float32 round-off, as Theorem 1 predicts\n")

    print("RQ3  physical validity (39)")
    report["validity"] = eval_validity(model, cfg)
    v = report["validity"]
    print(f"     violation rate {v['rate_pct']:.4f}% over {v['n_voxels']} voxels "
          f"(Theorem 4 forces 0)\n")

    print("RQ2  acquisition consistency (Theorem 2)")
    report["consistency"] = eval_consistency(model, cfg)
    c = report["consistency"]
    print(f"     degrees      {c['degrees']}")
    print(f"     SW2 (1e-4)   {[f'{x:.3e}' for x in c['discrepancy_1e4']]}")
    if "rate" in c:
        r = c["rate"]
        print(f"     fitted slope {r['slope']:.3f}  95% CI "
              f"({r['ci_low']:.3f}, {r['ci_high']:.3f})\n")

    print("RQ1  signal prediction (36)")
    report["signal"] = eval_signal_prediction(model, cfg, n_fields=a.fields)
    s = report["signal"]
    print(f"     NRMSE {s['nrmse_mean']:.4f} +/- {s['nrmse_std']:.4f} "
          f"over {s['n_units']} {s['unit']}s\n")

    print("RQ4  identifiability flag")
    report["identifiability"] = eval_identifiability(model, cfg, n_cases=a.cases)
    i = report["identifiability"]
    print(f"     {i['n_cases']} cases, {i['unreliable_fraction']:.1%} unreliable, "
          f"AUC {i['auc'] if i['auc'] is None else round(i['auc'], 3)}")
    if "false_confident" in i:
        f = i["false_confident"]
        print(f"     false-confident {f['count']}/{f['total']} = {f['rate']:.3f} "
              f"Wilson ({f['wilson'][0]:.3f}, {f['wilson'][1]:.3f})")

    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(json.dumps(report, indent=2, default=float) + "\n")
    print(f"\nwrote {a.out}")

    if a.write_results:
        if not trained:
            print("\nrefusing to write results from an UNTRAINED model: the accuracy "
                  "values would be meaningless and would overwrite labelled "
                  "placeholders with labelled nonsense.")
            return 2
        store = ResultStore(a.results)
        store.set("table13.EQUAL.equivariance_error",
                  measured(round(e["cubic_mean"], 12), script=SCRIPT,
                           unit_of_analysis="rotation", n_units=e["n_cubic"],
                           note="Equation (38) over the 24 cubic-lattice rotations."))
        store.set("table14.EQUAL.violation_rate_measured_pct",
                  measured(v["rate_pct"], script=SCRIPT, unit_of_analysis="voxel",
                           n_units=v["n_voxels"],
                           note="Confirms the implementation matches Theorem 4."))
        store.save(a.results)
        print(f"wrote MEASURED values into {a.results}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
