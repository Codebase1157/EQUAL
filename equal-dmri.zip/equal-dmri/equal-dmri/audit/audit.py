#!/usr/bin/env python3
"""The build gate: numerical consistency, provenance and equation-to-code.

The audit report records that two faults in the build's own checks were found
and fixed -- ``audit.py`` always exited zero, and ``final_check.sh`` ignored
failures inside pipes, so a failed audit could not stop the build.  This file
therefore **exits non-zero on failure**, and ``final_check.sh`` sets
``pipefail``.

What this gate enforces
-----------------------
1. **Provenance** (audit Sec. 13).  Every value carries a label; nothing is
   silently unlabelled; headline claims are reported as unsubmittable while
   their inputs are illustrative.
2. **Numerical consistency** (audit Sec. 2).  Every reported margin, gap and
   ablation change is recomputed from the values it is supposed to follow from.
   A number that is typed rather than computed fails here.
3. **Theory** (audit Sec. 1, 5).  The Theorem 6(ii) bound is evaluated from
   (35) rather than transcribed, and the Wilson intervals of Table XVII are
   recomputed from their counts.
4. **Splits** (audit Sec. 3).  The HCP-YA eligibility chain must close, and no
   subject may appear in two splits.
5. **Scope of claims** (audit Sec. 12).  A margin on a source where only one
   baseline is applicable must record that fact beside it.

Two checks currently FAIL on the delivered manuscript values, and both are
genuine defects of the same class the audit already caught elsewhere
("summary values did not match their own data"):

``thm6_bound_row``
    Table XIV's bound row does not follow from equation (35).  The formula is
    confirmed by the crossing points quoted in the Section V remark and the
    Fig. 5(b) caption (3.4, 4.9, 7.0 -> 3.438, 4.901, 7.005), but at eps = 0.01
    the formula gives 0.171/0.342/0.636/0.853 where the table prints
    0.071/0.134/0.309/0.561.  The qualitative claim survives either way, since
    the measured divergence stays below both.

``table11_comparator``
    Table XI's unseen-b row names PIGMENT (0.0929) as the best applicable
    baseline on CDMD and reports a 22.1% reduction.  SHARD (0.0914) is strictly
    better on CDMD, and Table X reports 20.8% for the same comparison using it.
    The abstract carries the 22.1 figure, with the phrase "each against the
    baselines that can process it" -- which is the claim that fails, since SHARD
    can process CDMD.

Usage::

    python audit/audit.py                 # run every check
    python audit/audit.py --strict        # placeholders also fail
    python audit/audit.py --list          # names of the checks
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import numpy as np  # noqa: E402

from equal.data.splits import HCP_YA_ACCOUNTING, verify_hcp_accounting  # noqa: E402
from equal.results import Provenance, ResultStore  # noqa: E402
from equal.stats import wilson_interval  # noqa: E402
from equal.theory import divergence_bound, trivial_crossing_ratio  # noqa: E402

TOL = 0.06          # percentage points, for a figure quoted to one decimal
ATOL = 5e-5         # absolute, for NRMSE-scale quantities


@dataclass
class CheckResult:
    name: str
    passed: bool
    detail: str
    advisory: bool = False      # reported, but does not fail the build

    @property
    def status(self) -> str:
        if self.passed:
            return "PASS"
        return "WARN" if self.advisory else "FAIL"


_CHECKS: list = []


def check(name: str, advisory: bool = False):
    def deco(fn):
        fn._check_name = name
        fn._advisory = advisory
        _CHECKS.append(fn)
        return fn
    return deco


# -- 1. provenance -----------------------------------------------------------

@check("provenance_labels")
def _provenance_labels(store: ResultStore, strict: bool) -> CheckResult:
    """Every value carries a provenance, and placeholders say what they stand for."""
    bad = []
    for k, v in store:
        if not isinstance(v.provenance, Provenance):
            bad.append(f"{k}: no provenance")
        if v.is_placeholder and not v.note:
            bad.append(f"{k}: illustrative with no note")
    if bad:
        return CheckResult("provenance_labels", False, "; ".join(bad[:5]))
    return CheckResult("provenance_labels", True,
                       f"all {len(store)} values labelled: {store.provenance_summary()}")


@check("no_unlabelled_placeholders", advisory=True)
def _placeholders(store: ResultStore, strict: bool) -> CheckResult:
    """Headline results must not rest on placeholders.

    Advisory by default: the repository is *expected* to carry placeholders
    until the experiments are run, and the point of labelling them is that this
    state is visible rather than hidden.  ``--strict`` turns it into a failure,
    which is the gate to use before submission.
    """
    ok, ph = store.is_submittable()
    if ok:
        return CheckResult("no_unlabelled_placeholders", True, "no placeholders remain")
    detail = (f"{len(ph)} value(s) are illustrative placeholders, so no quantitative "
              f"claim in Sections VIII-IX is supported by evidence yet. "
              f"e.g. {', '.join(ph[:3])}")
    return CheckResult("no_unlabelled_placeholders", False, detail, advisory=not strict)


# -- 2. numerical consistency ------------------------------------------------

_SOURCES = ["HCP_YA", "MASiVar_A", "MASiVar_P", "ON_Harmony", "CDMD",
            "tensor_valued", "in_silico"]
_BASELINES = ["SH_interp", "MAP_MRI", "SHARD", "QTI", "SH_CNN", "SH_sCNN",
              "S_CNN", "E3xSO3", "UPER", "D_RoPE", "PIGMENT"]
_PAPER_GAIN = {"HCP_YA": 11.1, "MASiVar_A": 12.4, "MASiVar_P": 17.2,
               "ON_Harmony": 17.3, "CDMD": 20.8, "tensor_valued": 30.5,
               "in_silico": 16.5}


def _best_baseline(store: ResultStore, src: str) -> tuple[str, float]:
    cand = {}
    for m in _BASELINES:
        key = f"table10.{m}.{src}"
        if key not in store:
            continue
        v = store.value_of(key)
        if v != "n/a":
            cand[m] = float(v)
    if not cand:
        raise ValueError(f"no applicable baseline on {src}")
    bm = min(cand, key=cand.get)
    return bm, cand[bm]


@check("table10_margins")
def _table10(store: ResultStore, strict: bool) -> CheckResult:
    """Each reported gain must follow from EQUAL and the best applicable baseline."""
    bad = []
    for src, claimed in _PAPER_GAIN.items():
        bm, bv = _best_baseline(store, src)
        e = float(store.value_of(f"table10.EQUAL.{src}"))
        got = (bv - e) / bv * 100.0
        if abs(got - claimed) > TOL:
            bad.append(f"{src}: claims {claimed}%, computes {got:.2f}% (vs {bm} {bv})")
    if bad:
        return CheckResult("table10_margins", False, "; ".join(bad))
    return CheckResult("table10_margins", True,
                       "all 7 source gains follow from the best applicable baseline")


@check("table11_comparator")
def _table11(store: ResultStore, strict: bool) -> CheckResult:
    """Table XI must name the best applicable baseline, and agree with Table X."""
    axes = {"new_directions": "HCP_YA", "unseen_b": "CDMD",
            "encoding_shape": "tensor_valued", "scanner_site": "ON_Harmony"}
    bad = []
    for axis, src in axes.items():
        claimed = float(store.value_of(f"table11.{axis}.reduction_pct"))
        named = str(store.value_of(f"table11.{axis}.comparator"))
        bm, bv = _best_baseline(store, src)
        e = float(store.value_of(f"table10.EQUAL.{src}"))
        best_red = (bv - e) / bv * 100.0
        if named != bm:
            named_v = store.value_of(f"table10.{named}.{src}")
            bad.append(
                f"{axis} on {src}: names {named} ({named_v}) as the best applicable "
                f"baseline, but {bm} ({bv}) is better; Table X reports "
                f"{best_red:.1f}% for this source against {bm} while Table XI "
                f"claims {claimed}%"
            )
        elif abs(best_red - claimed) > TOL:
            bad.append(f"{axis}: claims {claimed}%, computes {best_red:.2f}%")
    if bad:
        return CheckResult("table11_comparator", False, " | ".join(bad))
    return CheckResult("table11_comparator", True,
                       "all 4 axes name the best applicable baseline and agree with Table X")


@check("table12_optimism_gaps")
def _table12(store: ResultStore, strict: bool) -> CheckResult:
    """G_opt must equal NRMSE_raw - NRMSE_grid, and the share must follow."""
    bad = []
    shares = {"UPER": 39.7, "D_RoPE": 36.6, "SH_sCNN": 32.7}
    for m, share in shares.items():
        raw = float(store.value_of(f"table12.{m}.vs_raw"))
        grid = float(store.value_of(f"table12.{m}.vs_own_reference"))
        gap = float(store.value_of(f"table12.{m}.optimism_gap"))
        if abs(gap - (raw - grid)) > ATOL:
            bad.append(f"{m}: gap {gap} != {raw} - {grid}")
        got = gap / raw * 100.0
        if abs(got - share) > TOL:
            bad.append(f"{m}: share {got:.2f}% != {share}%")
    # The oracle decomposition quoted in Section VIII-B: 27% smoothing, 73% leakage.
    gap = float(store.value_of("table12.UPER.optimism_gap"))
    oracle = float(store.value_of("table12.oracle.gap"))
    smooth = oracle / gap * 100.0
    if abs(smooth - 27.0) > 0.6:
        bad.append(f"oracle share {smooth:.1f}% != 27%")
    ratio = gap / oracle
    if abs(ratio - 3.7) > 0.06:
        bad.append(f"margin {ratio:.2f} != 3.7 to one")
    if bad:
        return CheckResult("table12_optimism_gaps", False, "; ".join(bad))
    return CheckResult("table12_optimism_gaps", True,
                       f"gaps, shares and the oracle decomposition all follow "
                       f"({smooth:.0f}% smoothing, {ratio:.1f}:1 margin)")


@check("table20_ablation_changes")
def _table20(store: ResultStore, strict: bool) -> CheckResult:
    """Every ablation change must equal the difference from the reference model."""
    ref = float(store.value_of("table20.input.raw_lifting.nrmse"))
    if abs(ref - 0.0497) > ATOL:
        return CheckResult("table20_ablation_changes", False,
                           f"reference NRMSE is {ref}, expected 0.0497")
    changes = {
        "input.icosahedral_resampling": 0.0072, "quadrature.uniform": 0.0031,
        "encoding.one_hot": 0.0044, "linear_channel.removed": 0.0017,
        "pooling.mean": 0.0022, "backbone.non_equivariant": 0.0059,
        "symmetry.product": 0.0026, "decoder.direct_mlp": -0.0006,
        "fw_atom.none": 0.0006, "data_term.mse_adc": 0.0037,
        "consistency.zero": 0.0008, "masking.a": 0.0024, "masking.ab": 0.0006,
        "supervision.distilled": -0.0006,
    }
    bad = []
    for k, claimed in changes.items():
        v = float(store.value_of(f"table20.{k}.nrmse"))
        got = v - ref
        if abs(got - claimed) > ATOL:
            bad.append(f"{k}: claims {claimed:+.4f}, computes {got:+.4f}")
    if bad:
        return CheckResult("table20_ablation_changes", False, "; ".join(bad))
    return CheckResult("table20_ablation_changes", True,
                       f"all {len(changes)} ablation changes follow from the reference")


# -- 3. theory ---------------------------------------------------------------

@check("thm6_crossing_points")
def _thm6_crossings(store: ResultStore, strict: bool) -> CheckResult:
    """The crossing points quoted in Section V and Fig. 5(b) must follow from (35)."""
    want = {0.05: 3.4, 0.01: 4.9, 0.001: 7.0}
    bad = []
    got = {}
    for eps, w in want.items():
        r = trivial_crossing_ratio(eps)
        got[eps] = round(r, 3)
        if abs(r - w) > 0.05:
            bad.append(f"eps={eps}: formula gives {r:.3f}, paper says {w}")
    if bad:
        return CheckResult("thm6_crossing_points", False, "; ".join(bad))
    return CheckResult("thm6_crossing_points", True,
                       f"3.4/4.9/7.0 reproduced as {got[0.05]}/{got[0.01]}/{got[0.001]}; "
                       f"this fixes the reading of (35)")


@check("thm6_bound_row")
def _thm6_row(store: ResultStore, strict: bool) -> CheckResult:
    """Table XIV's bound row must follow from equation (35).

    The bound is a theorem, not a measurement, so it has no error bars and
    nothing to average: it either follows from the formula or it does not.
    """
    printed = {1.5: 0.071, 2.0: 0.134, 3.0: 0.309, 4.0: 0.561}
    bad = []
    for ratio, p in printed.items():
        f = float(divergence_bound(ratio, 0.01, mask_trivial=False))
        if abs(f - p) > 0.002:
            bad.append(f"b*/bmax={ratio}: (35) gives {f:.3f}, Table XIV prints {p:.3f}")
    if bad:
        return CheckResult(
            "thm6_bound_row", False,
            "Table XIV's Theorem 6(ii) bound row does not follow from (35). "
            + "; ".join(bad)
            + ". The crossing points in Sec. V and Fig. 5(b) do follow from (35), "
              "so the formula is right and the row is typed rather than computed. "
              "The measured divergence stays inside the bound either way.",
        )
    return CheckResult("thm6_bound_row", True, "bound row follows from (35)")


@check("table17_wilson_intervals")
def _wilson(store: ResultStore, strict: bool) -> CheckResult:
    """The false-confident intervals must be the Wilson intervals of their counts."""
    want = {"FW": (0.010, 0.048), "MD": (0.019, 0.066),
            "muFA": (0.005, 0.033), "FOD": (0.029, 0.086)}
    bad = []
    for r, (lo_w, hi_w) in want.items():
        k = int(store.value_of(f"table17.{r}.false_confident_count"))
        n = int(store.value_of(f"table17.{r}.false_confident_total"))
        lo, hi = wilson_interval(k, n)
        if abs(lo - lo_w) > 0.002 or abs(hi - hi_w) > 0.002:
            bad.append(f"{r}: {k}/{n} gives ({lo:.3f}, {hi:.3f}), paper ({lo_w}, {hi_w})")
    if bad:
        return CheckResult("table17_wilson_intervals", False, "; ".join(bad))
    return CheckResult("table17_wilson_intervals", True,
                       "all 4 Wilson intervals reproduce from their counts")


@check("thm4_violation_rate_is_structural")
def _thm4(store: ResultStore, strict: bool) -> CheckResult:
    """EQUAL's violation rate must be recorded as a theorem, not a measurement.

    Theorem 4 holds for every value of Theta, so a zero here is an arithmetic
    consequence and not an empirical finding.  Recording it as MEASURED would
    invite a reader to treat it as something that might have come out otherwise.
    """
    v = store.get("table14.EQUAL.violation_rate_pct")
    if v.provenance is not Provenance.THEORETICAL:
        return CheckResult("thm4_violation_rate_is_structural", False,
                           f"recorded as {v.provenance.value}, expected theoretical")
    if float(v.value) != 0.0:
        return CheckResult("thm4_violation_rate_is_structural", False,
                           f"value is {v.value}, Theorem 4 forces 0")
    return CheckResult("thm4_violation_rate_is_structural", True,
                       "zero by construction, recorded as theoretical")


# -- 4. splits ---------------------------------------------------------------

@check("hcp_accounting")
def _hcp(store: ResultStore, strict: bool) -> CheckResult:
    """The HCP-YA eligibility chain must close arithmetically."""
    try:
        d = verify_hcp_accounting()
    except ValueError as e:
        return CheckResult("hcp_accounting", False, str(e))
    acc = HCP_YA_ACCOUNTING
    detail = (f"{acc.release_total} -> {acc.with_complete_dwi} -> {acc.eligible} -> "
              f"{acc.n_train}/{acc.n_val}/{acc.n_test}; {acc.n_retest_subjects} retest "
              f"subjects inside the test set giving {d['n_test_scans']} test scans")
    if not acc.verified_against_release:
        return CheckResult(
            "hcp_accounting", True,
            detail + ". NOT YET VERIFIED against the released quality-control "
                     "tables; the exclusion count remains the audit's placeholder.",
        )
    return CheckResult("hcp_accounting", True, detail)


@check("split_manifests")
def _splits(store: ResultStore, strict: bool) -> CheckResult:
    """Manifests, where present, must contain no cross-split subject."""
    from equal.data.splits import load_manifest

    d = ROOT / "results" / "splits"
    if not d.exists():
        return CheckResult(
            "split_manifests", True,
            "no manifests written yet; scripts/make_splits.py creates them and "
            "the overlap check runs at write and load time",
        )
    files = sorted(d.glob("*.json"))
    if not files:
        return CheckResult("split_manifests", True, "no manifests present")
    for f in files:
        try:
            load_manifest(f)
        except ValueError as e:
            return CheckResult("split_manifests", False, f"{f.name}: {e}")
    return CheckResult("split_manifests", True,
                       f"{len(files)} manifest(s) checked, no overlap")


# -- 5. scope of claims ------------------------------------------------------

@check("single_baseline_claims")
def _single_baseline(store: ResultStore, strict: bool) -> CheckResult:
    """A margin resting on one baseline must record that fact beside it.

    Audit Section 12: Contribution 4 describes the tensor-valued data as data
    "that no competing model can represent".  QTI represents it, and QTI is the
    comparator behind the 30.5 percent.  The figure is a comparison against one
    model-based fit, not evidence of superiority over competing methods.
    """
    bad = []
    for src in _SOURCES:
        n = int(store.value_of(f"table10.applicable_baselines.{src}"))
        if n > 1:
            continue
        comp = store.get(f"table10.best_baseline.{src}")
        if src == "tensor_valued":
            note = store.get("abstract.reduction_encoding_shape_pct").note.lower()
            if "qti" not in note or "not" not in note:
                bad.append(
                    f"{src}: only {n} applicable baseline ({comp.value}) but the "
                    f"abstract figure does not record that the margin is over it alone"
                )
    if bad:
        return CheckResult("single_baseline_claims", False, "; ".join(bad))
    return CheckResult(
        "single_baseline_claims", True,
        "the 30.5% margin records that QTI is its only comparator on that source",
    )


@check("theorem2_scope")
def _thm2_scope(store: ResultStore, strict: bool) -> CheckResult:
    """Exactly one of the four acquisition axes may be marked as covered by Thm 2."""
    covered = [a for a in ("new_directions", "unseen_b", "encoding_shape", "scanner_site")
               if bool(store.value_of(f"table11.{a}.theorem2_covers"))]
    if covered != ["new_directions"]:
        return CheckResult(
            "theorem2_scope", False,
            f"Theorem 2 is marked as covering {covered}; its hypothesis is that the "
            f"two acquisitions share their shells and differ only in their directions, "
            f"which only the direction axis meets",
        )
    return CheckResult("theorem2_scope", True,
                       "only the direction axis is marked as covered by Theorem 2")


# -- runner ------------------------------------------------------------------

def run(strict: bool = False, results_path: Path | None = None) -> int:
    path = results_path or (ROOT / "results" / "results.json")
    if not path.exists():
        print(f"audit: {path} not found. Run: python scripts/init_results.py")
        return 2
    store = ResultStore(path)

    print("=" * 78)
    print("EQUAL build audit")
    print(f"  results: {path.relative_to(ROOT) if path.is_relative_to(ROOT) else path}")
    print(f"  values : {len(store)}   provenance: {store.provenance_summary()}")
    print("=" * 78)

    results: list[CheckResult] = []
    for fn in _CHECKS:
        try:
            r = fn(store, strict)
        except Exception as e:                     # a broken check is a failed check
            r = CheckResult(fn._check_name, False, f"check raised {type(e).__name__}: {e}")
        if not r.passed and fn._advisory and not strict:
            r = CheckResult(r.name, r.passed, r.detail, advisory=True)
        results.append(r)

    width = max(len(r.name) for r in results)
    for r in results:
        print(f"  [{r.status}] {r.name:<{width}}  {r.detail}")

    failed = [r for r in results if not r.passed and not r.advisory]
    warned = [r for r in results if not r.passed and r.advisory]
    print("-" * 78)
    print(f"{len(results) - len(failed) - len(warned)} passed, "
          f"{len(failed)} failed, {len(warned)} advisory")
    if failed:
        print("\nFAILURES:")
        for r in failed:
            print(f"  * {r.name}: {r.detail}")
    print("=" * 78)
    return 1 if failed else 0


def main() -> int:
    ap = argparse.ArgumentParser(description="EQUAL build audit")
    ap.add_argument("--strict", action="store_true",
                    help="illustrative placeholders fail the build (use before submission)")
    ap.add_argument("--results", type=Path, default=None)
    ap.add_argument("--list", action="store_true", help="list check names and exit")
    a = ap.parse_args()
    if a.list:
        for fn in _CHECKS:
            print(f"{fn._check_name:34s} {'(advisory)' if fn._advisory else ''}")
        return 0
    return run(strict=a.strict, results_path=a.results)


if __name__ == "__main__":
    raise SystemExit(main())
